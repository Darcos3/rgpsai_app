"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_industrials_detail_detail_module_ts"],{

/***/ 5642:
/*!*************************************************!*\
  !*** ./src/app/components/components.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ComponentsModule": () => (/* binding */ ComponentsModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _components_menu_menu_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../components/menu/menu.component */ 5819);





let ComponentsModule = class ComponentsModule {
};
ComponentsModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [
            _components_menu_menu_component__WEBPACK_IMPORTED_MODULE_0__.MenuComponent,
        ],
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        ],
        exports: [
            _components_menu_menu_component__WEBPACK_IMPORTED_MODULE_0__.MenuComponent,
        ],
    })
], ComponentsModule);



/***/ }),

/***/ 5819:
/*!***************************************************!*\
  !*** ./src/app/components/menu/menu.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuComponent": () => (/* binding */ MenuComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _menu_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./menu.component.html?ngResource */ 2574);
/* harmony import */ var _menu_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./menu.component.scss?ngResource */ 1346);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 3819);






let MenuComponent = class MenuComponent {
    constructor(alertController, router) {
        this.alertController = alertController;
        this.router = router;
    }
    ngOnInit() { }
    closeView() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Confirmación',
                message: '¿Desea salir de esta vista?<br> Si lo hace perdera los avances que tenga en el formulario',
                backdropDismiss: false,
                buttons: [
                    {
                        text: 'No',
                        role: 'cancel',
                        handler: () => { }
                    },
                    {
                        text: 'Si',
                        handler: () => {
                            this.router.navigate(['registers']);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
MenuComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router }
];
MenuComponent.propDecorators = {
    TitleBar: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["TitleBar",] }],
    isMenuVisible: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["isMenuVisible",] }],
    isBackVisible: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["isBackVisible",] }],
    isFilterVisible: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["isFilterVisible",] }],
    isBackItemVisible: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["isBackItemVisible",] }],
    isCloseVisible: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["isCloseVisible",] }]
};
MenuComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-menu',
        template: _menu_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_menu_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], MenuComponent);



/***/ }),

/***/ 1257:
/*!*******************************************************************!*\
  !*** ./src/app/pages/industrials/detail/detail-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailPageRoutingModule": () => (/* binding */ DetailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _detail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detail.page */ 121);




const routes = [
    {
        path: '',
        component: _detail_page__WEBPACK_IMPORTED_MODULE_0__.DetailPage
    }
];
let DetailPageRoutingModule = class DetailPageRoutingModule {
};
DetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DetailPageRoutingModule);



/***/ }),

/***/ 259:
/*!***********************************************************!*\
  !*** ./src/app/pages/industrials/detail/detail.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailPageModule": () => (/* binding */ DetailPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _detail_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detail-routing.module */ 1257);
/* harmony import */ var _detail_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detail.page */ 121);
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../components/components.module */ 5642);








let DetailPageModule = class DetailPageModule {
};
DetailPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _detail_routing_module__WEBPACK_IMPORTED_MODULE_0__.DetailPageRoutingModule,
            _components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
        ],
        declarations: [_detail_page__WEBPACK_IMPORTED_MODULE_1__.DetailPage]
    })
], DetailPageModule);



/***/ }),

/***/ 121:
/*!*********************************************************!*\
  !*** ./src/app/pages/industrials/detail/detail.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailPage": () => (/* binding */ DetailPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detail.page.html?ngResource */ 9834);
/* harmony import */ var _detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detail.page.scss?ngResource */ 5118);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var src_app_config_events__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/config/events */ 6721);
/* harmony import */ var signature_pad__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! signature_pad */ 1032);
/* harmony import */ var _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/preferences */ 5191);









let DetailPage = class DetailPage {
    constructor(alertController, activatedRoute, router, events) {
        this.alertController = alertController;
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.events = events;
        this.dataStorage = [];
        this.id = this.activatedRoute.snapshot.paramMap.get('id');
        this.fotos_embarcacion = [];
        this.artes_de_pesca = [];
    }
    ;
    ngAfterViewInit() {
        this.signatureForm = new signature_pad__WEBPACK_IMPORTED_MODULE_3__["default"](this.signaturePad.nativeElement);
    }
    ngOnInit() {
        this.loadForm();
    }
    loadForm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            let dataRegisters = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.get({ key: 'dataRegistersIndustrial' });
            let response = JSON.parse(dataRegisters.value);
            if (response) {
                this.dataStorage = response;
                if (this.id != 0) {
                    let items = this.dataStorage.filter((item) => {
                        return item.id === this.id;
                    });
                    console.log('Registro: ', items);
                    items.forEach((data) => {
                        //tab 1
                        this.lugar = data.lugar;
                        this.fecha_expedicion = data.fecha_expedicion;
                        //tab 2
                        this.permisionario = data.permisionario;
                        this.nit = data.nit;
                        //tab 3
                        this.nombre_barco = data.nombre_barco;
                        this.numero_matricula = data.numero_matricula;
                        this.lugar_matricula = data.lugar_matricula;
                        this.fecha_matricula = data.fecha_matricula;
                        this.vencimiento_matricula = data.vencimiento_matricula;
                        //tab 4
                        this.bandera = data.bandera;
                        this.puerto_registro = data.puerto_registro;
                        this.otro_puerto_registro = data.otro_puerto_registro;
                        this.tipo_barco = data.tipo_barco;
                        this.otro_tipo_barco = data.otro_tipo_barco;
                        this.valor_embarcacion = data.valor_embarcacion;
                        this.venta_productos_a = data.venta_productos_a;
                        //tab 5
                        this.eslora = data.eslora;
                        this.manga = data.manga;
                        this.tonelaje = data.tonelaje;
                        this.tonelaje_registro_bruto = data.tonelaje_registro_bruto;
                        this.potencia_motor_ppal = data.potencia_motor_ppal;
                        this.unidad_potencia = data.unidad_potencia;
                        this.material_casco = data.material_casco;
                        this.numero_bodegas = data.numero_bodegas;
                        this.alto_bodegas = data.alto_bodegas;
                        this.largo_bodegas = data.largo_bodegas;
                        this.ancho_bodegas = data.ancho_bodegas;
                        this.capacidad_bodegas = data.capacidad_bodegas;
                        this.tipo_conservacion = data.tipo_conservacion;
                        this.nombre_admin_agencia = data.nombre_admin_agencia;
                        this.numero_tripulantes = data.numero_tripulantes;
                        this.numero_pescadores = data.numero_pescadores;
                        this.valor_arte_pesca = data.valor_arte_pesca;
                        this.zona_pesca = data.zona_pesca;
                        this.denominacion_arte_pesca = data.denominacion_arte_pesca;
                        this.otra_denominacion_arte_pesca = data.otra_denominacion_arte_pesca;
                        this.tipo_anzuelo = data.tipo_anzuelo;
                        this.tamano_anzuelo = data.tamano_anzuelo;
                        this.cantidad_anzuelos = data.cantidad_anzuelos;
                        this.longitud_linea_madre = data.longitud_linea_madre;
                        this.material_linea_madre = data.material_linea_madre;
                        this.material_bajantes = data.material_bajantes;
                        this.otro_material_bajantes = data.otro_material_bajantes;
                        this.cantidad_total_lineas = data.cantidad_total_lineas;
                        this.denominacion_alerta = data.denominacion_alerta;
                        this.otra_denominacion_del_arte = data.otra_denominacion_del_arte;
                        this.cantidad_trampas_nasas = data.cantidad_trampas_nasas;
                        this.material_ppal_trampas = data.material_ppal_trampas;
                        this.otro_material_ppal = data.otro_material_ppal;
                        this.tipo_artefactos = data.tipo_artefactos;
                        this.otro_tipo_artefacto = data.otro_tipo_artefacto;
                        this.cantidad_artefactos = data.cantidad_artefactos;
                        this.material_artefacto = data.material_artefacto;
                        this.otro_material_artefacto = data.otro_material_artefacto;
                        this.uso_dispositivos = data.uso_dispositivos;
                        this.tipo_fad_usados = data.tipo_fad_usados;
                        this.otro_tipo_fad_usados = data.otro_tipo_fad_usados;
                        this.cantidad_fad_usados = data.cantidad_fad_usados;
                        this.componentes_fad = data.componentes_fad;
                        //tab6
                        this.cartas_navegacion = data.cartas_navegacion;
                        this.compas_magnetico = data.compas_magnetico;
                        this.gps = data.gps;
                        this.loran = data.loran;
                        this.radar = data.radar;
                        this.ecosonda = data.ecosonda;
                        this.radios_comunicacion = data.radios_comunicacion;
                        //tab 7
                        this.firma_representante = data.firma_representante;
                        this.fotos_embarcacion = data.fotos_embarcacion;
                        this.observations = data.observations;
                        this.status = data.status;
                        this.signature = data.signature;
                        //new
                        this.calado = data.calado;
                        this.otra_unidad_potencia = data.otra_unidad_potencia;
                        this.otro_material_casco = data.otro_material_casco;
                        this.otro_tipo_conservacion = data.otro_tipo_conservacion;
                        this.radicado = data.radicado;
                        this.codigo_verificacion = data.codigo_verificacion;
                        this.nombre_propietario = data.nombre_propietario;
                        this.tipo_identificacion = data.tipo_identificacion;
                        this.otro_tipo_identificacion = data.otro_tipo_identificacion;
                        this.numero_identificacion = data.numero_identificacion;
                        this.nombre_representante = data.nombre_representante;
                        this.tipo_identificacion_representante = data.tipo_identificacion_representante;
                        this.otro_tipo_identificacion_representante = data.otro_tipo_identificacion_representante;
                        this.numero_identificacion_representante = data.numero_identificacion_representante;
                        this.cargo_representante = data.cargo_representante;
                        this.artes_de_pesca = data.artes_de_pesca;
                        this.otro_arte_pesca = data.otro_arte_pesca;
                        this.puerto_desembarque = data.puerto_desembarque;
                        this.otro_puerto_desembarque = data.otro_puerto_desembarque;
                    });
                }
            }
        });
    }
    SignatureDoc() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            this.savePad();
            if (!this.signature) {
                this.presentMessage('Advertencia', 'Debes firmar para poder continuar.');
                return;
            }
            let items = this.dataStorage.filter((item) => {
                return item.id === this.id;
            });
            items.forEach((data) => {
                data.firma_representante = this.signature;
                data.signature = this.signature;
                data.status = 2; //signature
            });
            yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.set({
                key: 'dataRegistersIndustrial',
                value: JSON.stringify(this.dataStorage),
            }).then(() => {
                this.AlertStore();
            });
            this.clearPad();
        });
    }
    //uplad register server
    AlertStore() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Confirmación',
                message: 'Documento firmado exitosamente',
                backdropDismiss: false,
                buttons: [
                    {
                        text: 'Aceptar',
                        handler: () => {
                            this.events.publish('updateRegisters', []);
                            this.router.navigate(["registers"]);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    //store signature
    savePad() {
        const base64Data = this.signatureForm.toDataURL();
        this.signature = this.signatureForm['_isEmpty'] == true ? null : base64Data;
        //console.log(this.signatureImgOwner);
    }
    //clean pad signature
    clearPad() {
        this.signatureForm.clear();
    }
    //alert with warning
    presentMessage(title, message, redirect = false) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: title,
                message: message,
                backdropDismiss: false,
                buttons: [
                    {
                        text: 'OK',
                        handler: () => redirect ? this.router.navigate(['registers']) : null
                    }
                ]
            });
            yield alert.present();
        });
    }
};
DetailPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: src_app_config_events__WEBPACK_IMPORTED_MODULE_2__.Events }
];
DetailPage.propDecorators = {
    signaturePad: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild, args: ['signaturePad',] }]
};
DetailPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-detail',
        template: _detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], DetailPage);



/***/ }),

/***/ 1346:
/*!****************************************************************!*\
  !*** ./src/app/components/menu/menu.component.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "ion-header ion-toolbar {\n  --background: #2f6da8; /* Old browsers */\n  --background: -moz-linear-gradient(left, #2f6da8 0%, #3192c8 76%, #73ad7d 100%); /* FF3.6-15 */\n  --background: -webkit-linear-gradient(left, #2f6da8 0%,#3192c8 76%,#73ad7d 100%); /* Chrome10-25,Safari5.1-6 */\n  --background: linear-gradient(to right, #2f6da8 0%,#3192c8 76%,#73ad7d 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  padding-top: 30px;\n  padding-bottom: 10px;\n}\nion-header ion-toolbar ion-title {\n  font-family: \"Poppins\", sans-serif;\n  color: #ffffff;\n  text-align: center;\n}\nion-header ion-toolbar ion-menu-button {\n  --color: #FFFFFF;\n}\nion-header ion-toolbar ion-back-button {\n  --color: #FFFFFF;\n}\nion-header ion-toolbar img {\n  width: 25px;\n  margin-right: 10px;\n}\nion-header ion-toolbar ion-icon {\n  color: #ffffff;\n  font-size: 24px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lbnUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDSSxxQkFBQSxFQUFBLGlCQUFBO0VBQ0EsK0VBQUEsRUFBQSxhQUFBO0VBQ0EsZ0ZBQUEsRUFBQSw0QkFBQTtFQUNBLDRFQUFBLEVBQUEscURBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0FBQVI7QUFDUTtFQUNJLGtDQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBQ1o7QUFDUTtFQUNJLGdCQUFBO0FBQ1o7QUFDUTtFQUNJLGdCQUFBO0FBQ1o7QUFDUTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtBQUNaO0FBQ1E7RUFDSSxjQUFBO0VBQ0EsZUFBQTtBQUNaIiwiZmlsZSI6Im1lbnUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVye1xyXG4gICAgaW9uLXRvb2xiYXJ7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjMmY2ZGE4OyAvKiBPbGQgYnJvd3NlcnMgKi9cclxuICAgICAgICAtLWJhY2tncm91bmQ6IC1tb3otbGluZWFyLWdyYWRpZW50KGxlZnQsICMyZjZkYTggMCUsICMzMTkyYzggNzYlLCAjNzNhZDdkIDEwMCUpOyAvKiBGRjMuNi0xNSAqL1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQobGVmdCwgIzJmNmRhOCAwJSwjMzE5MmM4IDc2JSwjNzNhZDdkIDEwMCUpOyAvKiBDaHJvbWUxMC0yNSxTYWZhcmk1LjEtNiAqL1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjMmY2ZGE4IDAlLCMzMTkyYzggNzYlLCM3M2FkN2QgMTAwJSk7IC8qIFczQywgSUUxMCssIEZGMTYrLCBDaHJvbWUyNissIE9wZXJhMTIrLCBTYWZhcmk3KyAqL1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAzMHB4O1xyXG4gICAgICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gICAgICAgIGlvbi10aXRsZXtcclxuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgICAgICAgICAgY29sb3I6ICNmZmZmZmY7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaW9uLW1lbnUtYnV0dG9ue1xyXG4gICAgICAgICAgICAtLWNvbG9yOiAjRkZGRkZGO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpb24tYmFjay1idXR0b257XHJcbiAgICAgICAgICAgIC0tY29sb3I6ICNGRkZGRkY7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGltZ3tcclxuICAgICAgICAgICAgd2lkdGg6IDI1cHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaW9uLWljb257XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il19 */";

/***/ }),

/***/ 5118:
/*!**********************************************************************!*\
  !*** ./src/app/pages/industrials/detail/detail.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "@charset \"UTF-8\";\nion-content {\n  --background: #FAFAFA;\n  background: #FAFAFA;\n}\nion-content ion-grid.headerGrid {\n  position: fixed;\n  width: 100%;\n  z-index: 99999;\n}\nion-content ion-grid.headerGrid ion-row {\n  padding: 20px;\n  background: #fff;\n  border-bottom: 2px solid  #e6e6e6;\n}\nion-content ion-grid.headerGrid ion-row ion-col ion-text {\n  font-family: \"Poppins\", sans-serif;\n}\nion-content ion-grid.headerGrid ion-row ion-col ion-text.active {\n  color: #000043;\n  padding-bottom: 5px;\n  border-bottom: 3px solid #FED610;\n}\nion-content ion-grid.headerGrid ion-row ion-col ion-text.inactive {\n  color: #DBDBDB;\n  border-bottom: 0;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid.headerGrid ion-row ion-col ion-text {\n    font-size: 14px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid.headerGrid ion-row ion-col ion-text {\n    font-size: 16px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid.headerGrid ion-row ion-col ion-text {\n    font-size: 20px;\n  }\n}\nion-content ion-grid ion-row.marginInitial {\n  margin-top: 80px;\n}\nion-content ion-grid ion-row.marginTop {\n  margin-top: 10px;\n}\nion-content ion-grid ion-row ion-col ion-button {\n  font-family: \"Poppins\", sans-serif;\n  --border-radius: 50px;\n  --background: #2f6da8; /* Old browsers */\n  --background: -moz-linear-gradient(left, #2f6da8 0%, #3192c8 76%, #73ad7d 100%); /* FF3.6-15 */\n  --background: -webkit-linear-gradient(left, #2f6da8 0%,#3192c8 76%,#73ad7d 100%); /* Chrome10-25,Safari5.1-6 */\n  --background: linear-gradient(to right, #2f6da8 0%,#3192c8 76%,#73ad7d 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  --background-activated: #006fa6;\n  --background-focused: #006fa6;\n  --background-hover: #006fa6;\n  min-width: 80%;\n  font-size: 16px;\n}\nion-content ion-grid ion-row ion-col ion-card.specialCard {\n  padding-bottom: 30px;\n}\nion-content ion-grid ion-row ion-col ion-card img.imgAdd {\n  max-width: 100%;\n  max-height: 100px;\n}\nion-content ion-grid ion-row ion-col ion-card img.imgCircle {\n  margin: 20px 0 0 10px;\n  border-radius: 50%;\n  max-width: 90%;\n  border: 2px solid #FED610;\n}\nion-content ion-grid ion-row ion-col ion-card img.imgIcon {\n  width: 15px;\n}\nion-content ion-grid ion-row ion-col ion-card img.imgButton {\n  width: 30px;\n}\nion-content ion-grid ion-row ion-col ion-card ion-item {\n  margin: 0;\n  padding: 0;\n  --padding-start: 0;\n  --padding-end: 0;\n  margin: 0;\n}\nion-content ion-grid ion-row ion-col ion-card ion-text {\n  font-family: \"Poppins\", sans-serif;\n  margin: 0;\n}\nion-content ion-grid ion-row ion-col ion-card ion-text h1 {\n  margin-bottom: 0;\n  color: #414141;\n  font-weight: lighter;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h1 {\n    font-size: 18px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h1 {\n    font-size: 20px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h1 {\n    font-size: 25px;\n  }\n}\nion-content ion-grid ion-row ion-col ion-card ion-text h4 {\n  margin: 0 0 0 10px;\n  color: #414141;\n  font-weight: lighter;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h4 {\n    font-size: 13px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h4 {\n    font-size: 14px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h4 {\n    font-size: 18px;\n  }\n}\nion-content ion-grid ion-row ion-col ion-card ion-text h4 span {\n  font-weight: normal;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h4 span {\n    font-size: 16px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h4 span {\n    font-size: 17px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h4 span {\n    font-size: 21px;\n  }\n}\nion-content ion-grid ion-row ion-col ion-card ion-text h4 span.pending {\n  color: red;\n}\nion-content ion-grid ion-row ion-col ion-card ion-text h4 span.firmed {\n  color: #994F00;\n}\nion-content ion-grid ion-row ion-col ion-card ion-text h4 span.upload {\n  color: #168500;\n}\nion-content ion-grid ion-row ion-col ion-card ion-text p {\n  margin: 5px 0 0;\n  color: #414141;\n  font-weight: normal;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text p {\n    font-size: 11px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text p {\n    font-size: 12px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text p {\n    font-size: 15px;\n  }\n}\nion-content ion-grid ion-row ion-col ion-card ion-list {\n  padding: 0 0 0 10px;\n}\nion-content ion-grid ion-row ion-col ion-label.firma {\n  font-family: \"Poppins\", sans-serif;\n  margin-bottom: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCO0FBQWhCO0VBQ0kscUJBQUE7RUFDQSxtQkFBQTtBQUVKO0FBQVE7RUFDSSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7QUFFWjtBQURZO0VBQ0ksYUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUNBQUE7QUFHaEI7QUFEb0I7RUFDSSxrQ0FBQTtBQUd4QjtBQUZ3QjtFQUNJLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGdDQUFBO0FBSTVCO0FBRndCO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0FBSTVCO0FBRndCO0VBWEo7SUFZUSxlQUFBO0VBSzFCO0FBQ0Y7QUFKd0I7RUFkSjtJQWVRLGVBQUE7RUFPMUI7QUFDRjtBQU53QjtFQWpCSjtJQWtCUSxlQUFBO0VBUzFCO0FBQ0Y7QUFIWTtFQUNJLGdCQUFBO0FBS2hCO0FBSFk7RUFDSSxnQkFBQTtBQUtoQjtBQUZnQjtFQUNJLGtDQUFBO0VBQ0EscUJBQUE7RUFDQSxxQkFBQSxFQUFBLGlCQUFBO0VBQ0EsK0VBQUEsRUFBQSxhQUFBO0VBQ0EsZ0ZBQUEsRUFBQSw0QkFBQTtFQUNBLDRFQUFBLEVBQUEscURBQUE7RUFDQSwrQkFBQTtFQUNBLDZCQUFBO0VBQ0EsMkJBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQUlwQjtBQURvQjtFQUNJLG9CQUFBO0FBR3hCO0FBQXdCO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0FBRTVCO0FBQXdCO0VBQ0kscUJBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSx5QkFBQTtBQUU1QjtBQUF3QjtFQUNJLFdBQUE7QUFFNUI7QUFBd0I7RUFDSSxXQUFBO0FBRTVCO0FBQ29CO0VBQ0ksU0FBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsU0FBQTtBQUN4QjtBQUNvQjtFQUNJLGtDQUFBO0VBQ0EsU0FBQTtBQUN4QjtBQUF3QjtFQUNJLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLG9CQUFBO0FBRTVCO0FBRDRCO0VBSko7SUFLUSxlQUFBO0VBSTlCO0FBQ0Y7QUFINEI7RUFQSjtJQVFRLGVBQUE7RUFNOUI7QUFDRjtBQUw0QjtFQVZKO0lBV1EsZUFBQTtFQVE5QjtBQUNGO0FBTndCO0VBQ0ksa0JBQUE7RUFDQSxjQUFBO0VBQ0Esb0JBQUE7QUFRNUI7QUFQNEI7RUFKSjtJQUtRLGVBQUE7RUFVOUI7QUFDRjtBQVQ0QjtFQVBKO0lBUVEsZUFBQTtFQVk5QjtBQUNGO0FBWDRCO0VBVko7SUFXUSxlQUFBO0VBYzlCO0FBQ0Y7QUFiNEI7RUFDSSxtQkFBQTtBQWVoQztBQWRnQztFQUZKO0lBR1EsZUFBQTtFQWlCbEM7QUFDRjtBQWhCZ0M7RUFMSjtJQU1RLGVBQUE7RUFtQmxDO0FBQ0Y7QUFsQmdDO0VBUko7SUFTUSxlQUFBO0VBcUJsQztBQUNGO0FBcEJnQztFQUNJLFVBQUE7QUFzQnBDO0FBcEJnQztFQUNJLGNBQUE7QUFzQnBDO0FBcEJnQztFQUNJLGNBQUE7QUFzQnBDO0FBbEJ3QjtFQUNJLGVBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7QUFvQjVCO0FBbkI0QjtFQUpKO0lBS1EsZUFBQTtFQXNCOUI7QUFDRjtBQXJCNEI7RUFQSjtJQVFRLGVBQUE7RUF3QjlCO0FBQ0Y7QUF2QjRCO0VBVko7SUFXUSxlQUFBO0VBMEI5QjtBQUNGO0FBdkJvQjtFQUNJLG1CQUFBO0FBeUJ4QjtBQXRCZ0I7RUFDSSxrQ0FBQTtFQUNBLG1CQUFBO0FBd0JwQiIsImZpbGUiOiJkZXRhaWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNGQUZBRkE7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRkFGQUZBO1xyXG4gICAgaW9uLWdyaWR7XHJcbiAgICAgICAgJi5oZWFkZXJHcmlke1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICB6LWluZGV4OiA5OTk5OTtcclxuICAgICAgICAgICAgaW9uLXJvd3tcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDIwcHg7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkwqAjZTZlNmU2O1xyXG4gICAgICAgICAgICAgICAgaW9uLWNvbHtcclxuICAgICAgICAgICAgICAgICAgICBpb24tdGV4dHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgJi5hY3RpdmV7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzAwMDA0MztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiA1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tOiAzcHggc29saWQgI0ZFRDYxMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAmLmluYWN0aXZle1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICNEQkRCREI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAzMTlweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAzNzRweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiA0MTVweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSAgIFxyXG4gICAgICAgIGlvbi1yb3d7XHJcbiAgICAgICAgICAgICYubWFyZ2luSW5pdGlhbHtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDgwcHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgJi5tYXJnaW5Ub3B7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlvbi1jb2x7XHJcbiAgICAgICAgICAgICAgICBpb24tYnV0dG9ue1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICAgICAgICAgICAgLS1ib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZDogIzJmNmRhODsgLyogT2xkIGJyb3dzZXJzICovXHJcbiAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOiAtbW96LWxpbmVhci1ncmFkaWVudChsZWZ0LCAjMmY2ZGE4IDAlLCAjMzE5MmM4IDc2JSwgIzczYWQ3ZCAxMDAlKTsgLyogRkYzLjYtMTUgKi9cclxuICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KGxlZnQsICMyZjZkYTggMCUsIzMxOTJjOCA3NiUsIzczYWQ3ZCAxMDAlKTsgLyogQ2hyb21lMTAtMjUsU2FmYXJpNS4xLTYgKi9cclxuICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzJmNmRhOCAwJSwjMzE5MmM4IDc2JSwjNzNhZDdkIDEwMCUpOyAvKiBXM0MsIElFMTArLCBGRjE2KywgQ2hyb21lMjYrLCBPcGVyYTEyKywgU2FmYXJpNysgKi9cclxuICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAgIzAwNmZhNjtcclxuICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQtZm9jdXNlZDogIzAwNmZhNjtcclxuICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQtaG92ZXI6ICMwMDZmYTY7XHJcbiAgICAgICAgICAgICAgICAgICAgbWluLXdpZHRoOiA4MCU7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaW9uLWNhcmR7XHJcbiAgICAgICAgICAgICAgICAgICAgJi5zcGVjaWFsQ2FyZHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDMwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGltZ3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgJi5pbWdBZGQge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4LXdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4LWhlaWdodDogMTAwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgJi5pbWdDaXJjbGV7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDIwcHggMCAwIDEwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXgtd2lkdGg6IDkwJTsgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAycHggc29saWQgI0ZFRDYxMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAmLmltZ0ljb257XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogMTVweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAmLmltZ0J1dHRvbntcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlvbi1pdGVte1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0tcGFkZGluZy1zdGFydFx0OiAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAtLXBhZGRpbmctZW5kOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlvbi10ZXh0e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGgxe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjNDE0MTQxO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGxpZ2h0ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogMzE5cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogMzc0cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogNDE1cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDI1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgaDR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDAgMCAwIDEwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzQxNDE0MTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBsaWdodGVyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDMxOXB4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDM3NHB4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDQxNXB4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3BhbntcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogbm9ybWFsO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAzMTlweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAzNzRweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE3cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiA0MTVweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDIxcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICYucGVuZGluZ3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IHJlZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJi5maXJtZWR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjOTk0RjAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAmLnVwbG9hZHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICMxNjg1MDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9ICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgcHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogNXB4IDAgMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjNDE0MTQxO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAzMTlweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAzNzRweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiA0MTVweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaW9uLWxpc3R7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDAgMCAwIDEwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaW9uLWxhYmVsLmZpcm1he1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMzBweDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufSJdfQ== */";

/***/ }),

/***/ 2574:
/*!****************************************************************!*\
  !*** ./src/app/components/menu/menu.component.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\r\n    <ion-toolbar>\r\n        <img src=\"../../../assets/resources/ico-filter.png\" slot=\"end\" *ngIf=\"isFilterVisible=='true'\"> \r\n        <ion-buttons slot=\"start\" *ngIf=\"isBackVisible=='true'\">\r\n            <ion-back-button text=\"\" defaultHref=\"registers\"></ion-back-button>\r\n        </ion-buttons>\r\n        <ion-buttons slot=\"start\" *ngIf=\"isCloseVisible=='true'\">\r\n            <ion-icon name=\"close\" (click)=\"closeView()\"></ion-icon>\r\n        </ion-buttons>\r\n        <ion-buttons slot=\"start\" *ngIf=\"isBackItemVisible=='true'\">\r\n            <ion-back-button text=\"\" defaultHref=\"/\"></ion-back-button>\r\n        </ion-buttons>\r\n        <ion-buttons slot=\"end\" *ngIf=\"isMenuVisible=='true'\">\r\n            <ion-menu-button></ion-menu-button>\r\n        </ion-buttons>\r\n        <ion-title>\r\n            {{ TitleBar }}\r\n        </ion-title>\r\n    </ion-toolbar>\r\n</ion-header>";

/***/ }),

/***/ 9834:
/*!**********************************************************************!*\
  !*** ./src/app/pages/industrials/detail/detail.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<app-menu TitleBar=\"Detalle de Inspección Industrial\" isMenuVisible=\"false\" isBackVisible=\"true\"></app-menu>\r\n\r\n<ion-content>\r\n    <!-- first tab -->\r\n    <ion-grid>\r\n        <ion-row>\r\n            <ion-col>\r\n                <ion-card>\r\n                    <ion-row class=\"justify-content-center align-items-center\">\r\n                        <ion-col size=\"9\">\r\n                            <ion-row>\r\n                                <ion-col>\r\n                                    <ion-text>\r\n                                        <h1>\r\n                                            {{ nombre_barco ? nombre_barco : 'Indefinido' }}\r\n                                        </h1>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                            </ion-row>\r\n                            <ion-row>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <img src=\"../../../assets/images/user.png\" class=\"imgIcon\">\r\n                                        <ion-text>\r\n                                            <h4><b>Administrador</b></h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                    <ion-text>\r\n                                        <h4>{{ nombre_admin_agencia ? nombre_admin_agencia : 'Indefinido' }}\r\n                                        </h4>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <img src=\"../../../assets/images/build.png\" class=\"imgIcon\">\r\n                                        <ion-text>\r\n                                            <h4><b>Permisionario</b></h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                    <ion-text>\r\n                                        <h4>{{ permisionario ? permisionario : 'Indefinido' }}\r\n                                        </h4>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <img src=\"../../../assets/images/map.png\" class=\"imgIcon\">\r\n                                        <ion-text>\r\n                                            <h4><b>Lugar Registro</b></h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                    <ion-text>\r\n                                        <h4>{{ lugar_matricula ? lugar_matricula : 'Indefinido' }}\r\n                                        </h4>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <img src=\"../../../assets/images/calendar.png\" class=\"imgIcon\">\r\n                                        <ion-text>\r\n                                            <h4><b>Solicitud de Inspección</b></h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                    <ion-text>\r\n                                        <h4>{{ fecha_matricula ? fecha_matricula.substr(0, 10) : 'Indefinido' }}\r\n                                        </h4>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <ion-text>\r\n                                            <h4>\r\n                                                <b>Estado: </b>\r\n                                                <span\r\n                                                    [ngClass]=\"status == 1 ? 'pending' : status == 2 ? 'firmed' : 'upload'\">\r\n                                                    {{ status == 1 ? ' Pendiente' : status == 2 ? ' Firmado' : ' Guardado' }}\r\n                                                </span>\r\n                                            </h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                </ion-col>\r\n                            </ion-row>\r\n                        </ion-col>\r\n                        <ion-col size=\"3\">\r\n                            <img src=\"../../../assets/images/barco.png\" class=\"imgCircle\">\r\n                        </ion-col>\r\n                        <ion-col size=\"12\">\r\n                            <!-- Notes in a List -->\r\n                            <ion-list>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Lugar\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ lugar ? lugar.name : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Fecha de expedición\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ fecha_expedicion ? fecha_expedicion.substr(0, 10) : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Radicado\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ radicado ? radicado : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Permisionario\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ permisionario }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Número de Nit\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ nit }} - {{ codigo_verificacion }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Nombre Barco\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ nombre_barco ? nombre_barco : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Matrícula Barco\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ numero_matricula ? numero_matricula : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Lugar Expedición Matrícula\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ lugar_matricula ? lugar_matricula : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Fecha Expedición Matrícula\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ fecha_matricula ? fecha_matricula.substr(0, 10) : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Fecha Vencimiento Matrícula\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ vencimiento_matricula ? vencimiento_matricula.substr(0, 10) : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Bandera\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ bandera ? bandera.name : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Puerto de registro\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ puerto_registro ? puerto_registro : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item *ngIf=\"puerto_registro && puerto_registro.codigo == 98\">\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Otro Puerto de Registro?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ otro_puerto_registro ? otro_puerto_registro : 'N/A' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Puerto de desembarque\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ puerto_desembarque ? puerto_desembarque.nombre : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item *ngIf=\"puerto_desembarque && puerto_desembarque.codigo == 98\">\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Otro Puerto de desembarque?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ otro_puerto_desembarque ? otro_puerto_desembarque : 'N/A' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Tipo de Barco\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ tipo_barco ? tipo_barco : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item *ngIf=\"tipo_barco && tipo_barco.index == 98\">\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Otro Tipo de Barco?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ otro_tipo_barco ? otro_tipo_barco : 'N/A' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Valor Embarcación\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ valor_embarcacion ? valor_embarcacion : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Venta de productos a\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ venta_productos_a ? venta_productos_a : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Calado (m)\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ calado ? calado : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Manga (m)\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ manga ? manga : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Eslora (LOA)m\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ eslora ? eslora : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Tonelaje R. Neto (TRN)\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ tonelaje ? tonelaje : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Tonelaje Registro Bruto (TRB)\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ tonelaje_registro_bruto ? tonelaje_registro_bruto : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Potencia Motor Ppal\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ potencia_motor_ppal ? potencia_motor_ppal : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Unidad de Potencia\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ unidad_potencia ? unidad_potencia : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item *ngIf=\"unidad_potencia == 3\">\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Otra unidad de potencia\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ otra_unidad_potencia ? otra_unidad_potencia : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Material Casco\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ material_casco ? material_casco : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item *ngIf=\"material_casco == 98\">\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Otro material casco\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ otro_material_casco ? otro_material_casco : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Número de Bodegas\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ numero_bodegas ? numero_bodegas : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Alto de Bodegas (m)\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ alto_bodegas ? alto_bodegas : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Largo de Bodegas (m)\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ largo_bodegas ? largo_bodegas : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Ancho de Bodegas (m)\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ ancho_bodegas ? ancho_bodegas : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Capacidad de la Bodega (m3)\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ capacidad_bodegas ? capacidad_bodegas : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Tipo de conservación\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ tipo_conservacion ? tipo_conservacion.name : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item *ngIf=\"tipo_conservacion == 98\">\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Otro tipo de conservación\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ otro_tipo_conservacion ? otro_tipo_conservacion : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Nombre Propietario\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ nombre_propietario ? nombre_propietario : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Tipo de documento\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ tipo_identificacion ? (tipo_identificacion == 1 ? 'C.C' :  tipo_identificacion == 2 ? 'C.E' : 'Otro') : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item *ngIf=\"tipo_identificacion && tipo_identificacion == 3\">\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Otro tipo de documento\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ otro_tipo_identificacion ? otro_tipo_identificacion : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Número de documento\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ numero_identificacion ? numero_identificacion : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Nombre Admin Agencia\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ nombre_admin_agencia ? nombre_admin_agencia : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Número de Tripulantes\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ numero_tripulantes ? numero_tripulantes : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Número de Pescadores\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ numero_pescadores ? numero_pescadores : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Artes de pesca\r\n                                    </ion-label>\r\n                                </ion-item>\r\n                                <ion-item lines=\"none\">\r\n                                    <ion-note slot=\"start\">\r\n\r\n                                        {{ artes_de_pesca && artes_de_pesca.includes('1') ? 'Sedal o de Anzuelo | ' : '' }}\r\n                                        {{ artes_de_pesca && artes_de_pesca.includes('2') ? 'Nasas |' : '' }}\r\n                                        {{ artes_de_pesca && artes_de_pesca.includes('3') ? 'Buceo | ' : '' }}\r\n                                        {{ artes_de_pesca && artes_de_pesca.includes('98') ? 'Otro' : '' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item *ngIf=\"artes_de_pesca && artes_de_pesca.includes('4')\">\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Otro Arte de pesca\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ otro_arte_pesca ? otro_arte_pesca : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Valor Arte de Pesca\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ valor_arte_pesca ? valor_arte_pesca : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Zona de Pesca\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ zona_pesca ? zona_pesca : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Denominación Arte de Pesca\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ denominacion_arte_pesca ? denominacion_arte_pesca.name : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item *ngIf=\"denominacion_arte_pesca && denominacion_arte_pesca.id == 98\">\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Otra Denominación Arte de Pesca?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ otra_denominacion_arte_pesca ? otra_denominacion_arte_pesca : 'N/A' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Tipo de Anzuelo\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ tipo_anzuelo ? tipo_anzuelo.name : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Tamaño de Anzuelo\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ tamano_anzuelo ? tamano_anzuelo : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Cantidad de Anzuelos\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ cantidad_anzuelos ? cantidad_anzuelos : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Longitud Línea Madre\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ longitud_linea_madre ? longitud_linea_madre : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Material Línea Madre\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ material_linea_madre ? material_linea_madre.name : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Material Bajante\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ material_bajantes ? material_bajantes.name : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item *ngIf=\"material_bajantes && material_bajantes.id == 4\">\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Otro Material Bajante?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ otro_material_bajantes ? otro_material_bajantes : 'N/A' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Cantidad Líneas Madre\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ cantidad_total_lineas ? cantidad_total_lineas : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Denominación del arte de pesca tipo Trampas o nasas\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ denominacion_alerta ? denominacion_alerta.name : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item *ngIf=\"denominacion_alerta && denominacion_alerta.id == 4\">\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Otra Denominación del arte de pesca tipo Trampas o nasas?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n                                        {{ otra_denominacion_del_arte }}\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Cantidad de Trampas O Nasas\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ cantidad_trampas_nasas ? cantidad_trampas_nasas : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Material Ppal Trampas\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ material_ppal_trampas ? material_ppal_trampas.name : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item *ngIf=\"material_ppal_trampas && material_ppal_trampas.id == 8\">\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Otro Material Ppal Trampas?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ otro_material_ppal ? otro_material_ppal : 'N/A' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Tipos de Artefacto\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ tipo_artefactos ? tipo_artefactos.name : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item *ngIf=\"tipo_artefactos && tipo_artefactos.id == 7\">\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Otro Tipo de Artefacto?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ otro_tipo_artefacto ? otro_tipo_artefacto : 'N/A' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Cantidad de Artefactos\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ cantidad_artefactos ? cantidad_artefactos : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Material de Artefactos\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ material_artefacto ? material_artefacto.name : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item *ngIf=\"material_artefacto && material_artefacto.id == 4\">\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Otro Material de Artefacto?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ otro_material_artefacto ? otro_material_artefacto : 'N/A' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Uso de Dispositivos\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ uso_dispositivos ? uso_dispositivos.name : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Tipo de FADS Usados\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ tipo_fad_usados ? tipo_fad_usados.name : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item *ngIf=\"tipo_fad_usados && tipo_fad_usados.id == 6\">\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Otro Tipo de FADS?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ otro_tipo_fad_usados ? otro_tipo_fad_usados : 'N/A' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Cantidad de FADS Usados\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ cantidad_fad_usados ? cantidad_fad_usados : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Componentes de FADS\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ componentes_fad ? componentes_fad : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Cartas de Navegación?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ cartas_navegacion ? cartas_navegacion : 'Indefinido' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Compas Magnético?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ compas_magnetico ? compas_magnetico : 'N/A' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Gps?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ gps ? gps : 'N/A' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Loran?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ loran ? loran : 'N/A' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Radar?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ radar ? radar : 'N/A' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Ecosonda?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ ecosonda ? ecosonda : 'N/A' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        ¿Radios de Comunicación?\r\n                                    </ion-label>\r\n                                    <ion-note slot=\"end\">\r\n\r\n                                        {{ radios_comunicacion ? radios_comunicacion : 'N/A' }}\r\n\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                                <ion-item lines=\"none\">\r\n                                    <ion-label class=\"ion-text-wrap\">\r\n                                        Observaciones\r\n                                    </ion-label>\r\n                                </ion-item>\r\n                                <ion-item>\r\n                                    <ion-note>\r\n                                        {{ observations ? observations : 'Indefinido' }}\r\n                                    </ion-note>\r\n                                </ion-item>\r\n                            </ion-list>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row *ngIf=\"fotos_embarcacion.length>0\" class=\"marginTop\" align=\"center\">\r\n                        <ion-col size=\"4\" *ngFor=\" let image of fotos_embarcacion\">\r\n                            <img src=\"{{ image.image }}\" class=\"imgAdd\">\r\n                        </ion-col>\r\n                    </ion-row>\r\n                </ion-card>\r\n            </ion-col>\r\n            <ion-col size=\"12\" align=\"center\">\r\n                <ion-label class=\"firma\">Firma del documento</ion-label><br>\r\n                <ion-item *ngIf=\"!signature || status == 1\">\r\n                    <!---\r\n                        <ion-signaturepad [(ngModel)]=\"signature\" canvasWidth=\"300\" canvasHeight=\"300\" backgroundColor=\"#ffffff\">\r\n                        </ion-signaturepad>\r\n                    -->\r\n                    <canvas #signaturePad height=\"300\" backgroundColor=\"#ffffff\"></canvas>\r\n                </ion-item>\r\n                <img src=\"{{ signature }}\" *ngIf=\"signature && status != 1\">\r\n                <ion-item>\r\n                    {{ nombre_representante ? nombre_representante : 'Indefinido' }}\r\n                </ion-item>\r\n                <ion-item *ngIf=\"tipo_identificacion_representante!=3\">\r\n                    {{ tipo_identificacion_representante==1 ? 'CC' : tipo_identificacion_representante==2 ? 'CE' : tipo_identificacion_representante==3 ? 'Otro' : 'Indefinido' }}\r\n                </ion-item>\r\n                <ion-item *ngIf=\"tipo_identificacion_representante==3\">\r\n                    {{ otro_tipo_identificacion_representante ? otro_tipo_identificacion_representante : 'Indefinido' }}\r\n                </ion-item>\r\n                <ion-item>\r\n                    {{ numero_identificacion_representante ? numero_identificacion_representante : 'Indefinido' }}\r\n                </ion-item>\r\n                <ion-item>\r\n                    {{ cargo_representante ? cargo_representante : 'Indefinido' }}\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n        </ion-row>\r\n    </ion-grid>\r\n    <ion-grid>\r\n        <ion-row>\r\n            <ion-col align=\"center\">\r\n                <ion-button [disabled]=\"status != 1\" (click)=\"SignatureDoc()\">\r\n                    Finalizar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_industrials_detail_detail_module_ts.js.map