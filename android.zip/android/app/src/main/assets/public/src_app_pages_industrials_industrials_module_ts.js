"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_industrials_industrials_module_ts"],{

/***/ 6205:
/*!*****************************************************************!*\
  !*** ./src/app/pages/industrials/industrials-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IndustrialsPageRoutingModule": () => (/* binding */ IndustrialsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _industrials_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./industrials.page */ 2214);




const routes = [
    {
        path: '',
        component: _industrials_page__WEBPACK_IMPORTED_MODULE_0__.IndustrialsPage
    }
];
let IndustrialsPageRoutingModule = class IndustrialsPageRoutingModule {
};
IndustrialsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], IndustrialsPageRoutingModule);



/***/ }),

/***/ 5238:
/*!*********************************************************!*\
  !*** ./src/app/pages/industrials/industrials.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IndustrialsPageModule": () => (/* binding */ IndustrialsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _industrials_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./industrials-routing.module */ 6205);
/* harmony import */ var _industrials_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./industrials.page */ 2214);
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/components.module */ 5642);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ionic-selectable */ 5073);









let IndustrialsPageModule = class IndustrialsPageModule {
};
IndustrialsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _industrials_routing_module__WEBPACK_IMPORTED_MODULE_0__.IndustrialsPageRoutingModule,
            _components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
            ionic_selectable__WEBPACK_IMPORTED_MODULE_8__.IonicSelectableModule
        ],
        declarations: [_industrials_page__WEBPACK_IMPORTED_MODULE_1__.IndustrialsPage]
    })
], IndustrialsPageModule);



/***/ }),

/***/ 2214:
/*!*******************************************************!*\
  !*** ./src/app/pages/industrials/industrials.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IndustrialsPage": () => (/* binding */ IndustrialsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _industrials_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./industrials.page.html?ngResource */ 8944);
/* harmony import */ var _industrials_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./industrials.page.scss?ngResource */ 5217);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _config_data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../config/data */ 2995);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var src_app_config_events__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/config/events */ 6721);
/* harmony import */ var _capacitor_network__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/network */ 4984);
/* harmony import */ var _capacitor_preferences__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/preferences */ 5191);
/* harmony import */ var _capacitor_camera__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @capacitor/camera */ 4241);
/* harmony import */ var src_app_services_api_rest_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/api-rest.service */ 6363);












let IndustrialsPage = class IndustrialsPage {
    constructor(actionSheetController, loadingController, alertController, activatedRoute, api, router, events) {
        this.actionSheetController = actionSheetController;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.activatedRoute = activatedRoute;
        this.api = api;
        this.router = router;
        this.events = events;
        this.dataStorage = [];
        //############################### VARS
        //is new or old register
        this.id = this.activatedRoute.snapshot.paramMap.get('id');
        //tabs
        this.actualTab = this.id == 0 ? 0 : 1;
        this.counter = this.id == 0 ? 0 : 1;
        this.tab0 = 0;
        this.tab1 = 0;
        this.tab2 = 0;
        this.tab3 = 0;
        this.tab4 = 0;
        this.tab5 = 0;
        this.tab6 = 0;
        this.tab7 = 0;
        this.matricula_search = '';
        this.fotos_embarcacion = [];
        this.artes_de_pesca = [];
        //open gallery and take a photo
        this.uPloadNewPhoto = () => (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_6__.Camera.checkPermissions();
            const image = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_6__.Camera.getPhoto({
                quality: 95,
                allowEditing: false,
                resultType: _capacitor_camera__WEBPACK_IMPORTED_MODULE_6__.CameraResultType.Base64,
                //width: 512,
                //height: 512,
                correctOrientation: true,
                promptLabelPhoto: 'Biblioteca de imágenes',
                promptLabelPicture: 'Tomar una foto',
                promptLabelHeader: 'Embarcación Imágenes',
                promptLabelCancel: 'Cancelar'
            });
            var imageUrl = image.base64String;
            this.fotos_embarcacion.push({ image: 'data:image/jpeg;base64,' + imageUrl });
        });
        //delete images
        this.deleteImages = (index) => {
            console.log('index: ', index);
            this.fotos_embarcacion.splice(index, 1);
        };
    }
    ngOnInit() {
        this.validateSession();
        this.lugares = _config_data__WEBPACK_IMPORTED_MODULE_2__.RequestPlaces;
        this.countries = _config_data__WEBPACK_IMPORTED_MODULE_2__.Countries;
        const newLocal = this;
        //this.portsRegister = RegistersPorts;
        newLocal.shipTypes = _config_data__WEBPACK_IMPORTED_MODULE_2__.ShipType;
        console.log("tipo barcos ", newLocal.shipTypes);
        this.unityPotences = _config_data__WEBPACK_IMPORTED_MODULE_2__.UnityPotence;
        console.log(this.unityPotences);
        this.materialsCasco = _config_data__WEBPACK_IMPORTED_MODULE_2__.MaterialCasco;
        console.log("mc ", this.materialsCasco);
        this.conservationFish = _config_data__WEBPACK_IMPORTED_MODULE_2__.ConservationFishType;
        this.denominacionesAnzuelo = _config_data__WEBPACK_IMPORTED_MODULE_2__.DenominacionAnzuelo;
        this.tiposAnzuelos = _config_data__WEBPACK_IMPORTED_MODULE_2__.TipoAnzuelo;
        this.materialesLineaMadre = _config_data__WEBPACK_IMPORTED_MODULE_2__.MaterialLineaMadre;
        this.mateterialesBajantes = _config_data__WEBPACK_IMPORTED_MODULE_2__.MaterialBajantes;
        this.denomincacionArtesPesca = _config_data__WEBPACK_IMPORTED_MODULE_2__.DenominacionArtesPesca;
        this.materialPpalTrampa = _config_data__WEBPACK_IMPORTED_MODULE_2__.MaterialPpalTrampa;
        this.tiposDeArtefacto = _config_data__WEBPACK_IMPORTED_MODULE_2__.TipoArtefactos;
        this.materialesArtefacto = _config_data__WEBPACK_IMPORTED_MODULE_2__.MaterialArtefacto;
        this.booleans = _config_data__WEBPACK_IMPORTED_MODULE_2__.Booleans;
        console.log("cn ", this.booleans);
        this.tiposFads = _config_data__WEBPACK_IMPORTED_MODULE_2__.TipoFads;
        //this.dembarquePorts = DembarquePorts;
        // if(this.id != 0){
        this.loadData();
        // }
    }
    validateSession() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            let dataSession = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_5__.Preferences.get({ key: 'sessionPersistence' });
            let session = JSON.parse(dataSession.value);
            if (session) {
                if (session.userID) {
                    this.userID = session.userID;
                }
                if (session.userToken) {
                    this.userToken = session.userToken;
                }
            }
            else {
                this.router.navigate(['login']);
            }
            let dataRegisters = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_5__.Preferences.get({ key: 'dataRegistersIndustrial' });
            let sessionRegisters = JSON.parse(dataRegisters.value);
            if (this.id == 0 && sessionRegisters && sessionRegisters.length >= 10) {
                this.presentMessage('Advertencia', 'No podrás registrar más inspecciones a menos que subas una de las que tienes en el listado, solo se permite tenér un máximo de 10 registros por listado.', true);
            }
            this.dataStorage = sessionRegisters ? sessionRegisters : [];
            //dropdowns
            let ddPOL = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_5__.Preferences.get({ key: 'sessionSelectFishing' });
            let sDpol = JSON.parse(ddPOL.value);
            let ddSf = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_5__.Preferences.get({ key: 'sessionSelectLanding' });
            let sSf = JSON.parse(ddSf.value);
            let ddP = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_5__.Preferences.get({ key: 'sessionSelectPorts' });
            let sP = JSON.parse(ddP.value);
            this.artesPesca = sDpol.data;
            this.dembarquePorts = sSf.data;
            this.portsRegister = sP.data;
            console.log("puertos Registro: ", this.portsRegister);
        });
    }
    //load data persistence
    loadData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            let dataRegister = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_5__.Preferences.get({ key: 'dataRegistersIndustrial' });
            let response = JSON.parse(dataRegister.value);
            this.dataStorage = response;
            let items = this.dataStorage.filter((item) => {
                return item.id === this.id;
            });
            console.log('Registro: ', items);
            items.forEach((data) => {
                //tab 1
                this.lugar = data.lugar;
                this.fecha_expedicion = data.fecha_expedicion;
                //tab 2
                this.permisionario = data.permisionario;
                this.nit = data.nit;
                //tab 3
                this.nombre_barco = data.nombre_barco;
                this.numero_matricula = data.numero_matricula;
                this.lugar_matricula = data.lugar_matricula;
                this.fecha_matricula = data.fecha_matricula;
                this.vencimiento_matricula = data.vencimiento_matricula;
                //tab 4
                this.bandera = data.bandera;
                this.puerto_registro = data.puerto_registro;
                this.otro_puerto_registro = data.otro_puerto_registro;
                this.tipo_barco = data.tipo_barco;
                this.otro_tipo_barco = data.otro_tipo_barco;
                this.valor_embarcacion = data.valor_embarcacion;
                this.venta_productos_a = data.venta_productos_a;
                //tab 5
                this.eslora = data.eslora;
                this.manga = data.manga;
                this.tonelaje = data.tonelaje;
                this.tonelaje_registro_bruto = data.tonelaje_registro_bruto;
                this.potencia_motor_ppal = data.potencia_motor_ppal;
                this.unidad_potencia = data.unidad_potencia;
                this.material_casco = data.material_casco;
                this.numero_bodegas = data.numero_bodegas;
                this.alto_bodegas = data.alto_bodegas;
                this.largo_bodegas = data.largo_bodegas;
                this.ancho_bodegas = data.ancho_bodegas;
                this.capacidad_bodegas = data.capacidad_bodegas;
                this.tipo_conservacion = data.tipo_conservacion;
                this.nombre_admin_agencia = data.nombre_admin_agencia;
                this.numero_tripulantes = data.numero_tripulantes;
                this.numero_pescadores = data.numero_pescadores;
                this.valor_arte_pesca = data.valor_arte_pesca;
                this.zona_pesca = data.zona_pesca;
                this.denominacion_arte_pesca = data.denominacion_arte_pesca;
                this.otra_denominacion_arte_pesca = data.otra_denominacion_arte_pesca;
                this.tipo_anzuelo = data.tipo_anzuelo;
                this.tamano_anzuelo = data.tamano_anzuelo;
                this.cantidad_anzuelos = data.cantidad_anzuelos;
                this.longitud_linea_madre = data.longitud_linea_madre;
                this.material_linea_madre = data.material_linea_madre;
                this.material_bajantes = data.material_bajantes;
                this.otro_material_bajantes = data.otro_material_bajantes;
                this.cantidad_total_lineas = data.cantidad_total_lineas;
                this.denominacion_alerta = data.denominacion_alerta;
                this.otra_denominacion_del_arte = data.otra_denominacion_del_arte;
                this.cantidad_trampas_nasas = data.cantidad_trampas_nasas;
                this.material_ppal_trampas = data.material_ppal_trampas;
                this.otro_material_ppal = data.otro_material_ppal;
                this.tipo_artefactos = data.tipo_artefactos;
                this.otro_tipo_artefacto = data.otro_tipo_artefacto;
                this.cantidad_artefactos = data.cantidad_artefactos;
                this.material_artefacto = data.material_artefacto;
                this.otro_material_artefacto = data.otro_material_artefacto;
                this.uso_dispositivos = data.uso_dispositivos;
                this.tipo_fad_usados = data.tipo_fad_usados;
                this.otro_tipo_fad_usados = data.otro_tipo_fad_usados;
                this.cantidad_fad_usados = data.cantidad_fad_usados;
                this.componentes_fad = data.componentes_fad;
                //tab6
                this.cartas_navegacion = data.cartas_navegacion;
                this.compas_magnetico = data.compas_magnetico;
                this.gps = data.gps;
                this.loran = data.loran;
                this.radar = data.radar;
                this.ecosonda = data.ecosonda;
                this.radios_comunicacion = data.radios_comunicacion;
                //tab 7
                this.firma_representante = data.firma_representante;
                this.fotos_embarcacion = data.fotos_embarcacion;
                this.observations = data.observations;
                //nuevos
                this.calado = data.calado;
                this.otro_material_casco = data.otro_material_casco;
                this.otra_unidad_potencia = data.otra_unidad_potencia;
                this.otro_tipo_conservacion = data.otro_tipo_conservacion;
                this.radicado = data.radicado;
                this.codigo_verificacion = data.codigo_verificacion;
                this.nombre_propietario = data.nombre_propietario;
                this.tipo_identificacion = data.tipo_identificacion;
                this.otro_tipo_identificacion = data.otro_tipo_identificacion;
                this.numero_identificacion = data.numero_identificacion;
                this.nombre_representante = data.nombre_representante;
                this.tipo_identificacion_representante = data.tipo_identificacion_representante;
                this.otro_tipo_identificacion_representante = data.otro_tipo_identificacion_representante;
                this.numero_identificacion_representante = data.numero_identificacion_representante;
                this.cargo_representante = data.cargo_representante;
                this.artes_de_pesca = data.artes_de_pesca;
                this.otro_arte_pesca = data.otro_arte_pesca;
                this.puerto_desembarque = data.puerto_desembarque;
                this.otro_puerto_desembarque = data.otro_puerto_desembarque;
            });
        });
    }
    antTab() {
        this.counter--;
        if (this.counter == 0) {
            this.actualTab = 0;
            this.tab0 = 0;
            this.tab1 = 0;
            this.tab2 = 0;
            this.tab3 = 0;
            this.tab4 = 0;
            this.tab5 = 0;
            this.tab6 = 0;
        }
        else if (this.counter == 1) {
            this.actualTab = 1;
            this.tab0 = 1;
            this.tab1 = 0;
            this.tab2 = 0;
            this.tab3 = 0;
            this.tab4 = 0;
            this.tab5 = 0;
            this.tab6 = 0;
        }
        else if (this.counter == 2) {
            this.actualTab = 2;
            this.tab0 = 1;
            this.tab1 = 1;
            this.tab2 = 0;
            this.tab3 = 0;
            this.tab4 = 0;
            this.tab5 = 0;
            this.tab6 = 0;
        }
        else if (this.counter == 3) {
            this.actualTab = 3;
            this.tab0 = 1;
            this.tab1 = 1;
            this.tab2 = 1;
            this.tab3 = 0;
            this.tab4 = 0;
            this.tab5 = 0;
            this.tab6 = 0;
        }
        else if (this.counter == 4) {
            this.actualTab = 4;
            this.tab0 = 1;
            this.tab1 = 1;
            this.tab2 = 1;
            this.tab3 = 1;
            this.tab4 = 0;
            this.tab5 = 0;
            this.tab6 = 0;
        }
        else if (this.counter == 5) {
            this.actualTab = 5;
            this.tab0 = 1;
            this.tab1 = 1;
            this.tab2 = 1;
            this.tab3 = 1;
            this.tab4 = 1;
            this.tab5 = 0;
            this.tab6 = 0;
        }
        else if (this.counter == 6) {
            this.actualTab = 6;
            this.tab0 = 1;
            this.tab1 = 1;
            this.tab2 = 1;
            this.tab3 = 1;
            this.tab4 = 1;
            this.tab5 = 1;
            this.tab6 = 0;
        }
        console.log('Data...', this.actualTab);
    }
    nextTab() {
        if (this.counter == 0) {
            this.actualTab = 1;
            this.tab0 = 1;
        }
        else if (this.counter == 1) {
            this.actualTab = 2;
            this.tab1 = 1;
        }
        else if (this.counter == 2) {
            this.actualTab = 3;
            this.tab2 = 1;
        }
        else if (this.counter == 3) {
            this.actualTab = 4;
            this.tab3 = 1;
        }
        else if (this.counter == 4) {
            this.actualTab = 5;
            this.tab4 = 1;
        }
        else if (this.counter == 5) {
            this.actualTab = 6;
            this.tab5 = 1;
        }
        else if (this.counter == 6) {
            this.actualTab = 7;
            this.tab6 = 1;
        }
        this.counter++;
    }
    //storage in local
    saveInLocal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            if (this.id == 0) {
                let object = Object();
                object.id = Math.random().toString(36).substr(2, 9);
                //tab 1
                object.creation_date = Date.now();
                object.lugar = this.lugar;
                object.fecha_expedicion = this.fecha_expedicion;
                //tab 2
                object.permisionario = this.permisionario;
                object.nit = this.nit;
                //tab 3
                object.nombre_barco = this.nombre_barco;
                object.numero_matricula = this.numero_matricula ? this.numero_matricula.toUpperCase() : null;
                object.lugar_matricula = this.lugar_matricula;
                object.fecha_matricula = this.fecha_matricula;
                object.vencimiento_matricula = this.vencimiento_matricula;
                //tab 4
                object.bandera = this.bandera;
                object.puerto_registro = this.puerto_registro;
                object.otro_puerto_registro = this.otro_puerto_registro;
                object.tipo_barco = this.tipo_barco;
                object.otro_tipo_barco = this.otro_tipo_barco;
                object.valor_embarcacion = this.valor_embarcacion;
                object.venta_productos_a = this.venta_productos_a;
                //tab 5
                object.eslora = this.eslora;
                object.manga = this.manga;
                object.tonelaje = this.tonelaje;
                object.tonelaje_registro_bruto = this.tonelaje_registro_bruto;
                object.potencia_motor_ppal = this.potencia_motor_ppal;
                object.unidad_potencia = this.unidad_potencia;
                object.material_casco = this.material_casco;
                object.numero_bodegas = this.numero_bodegas;
                object.alto_bodegas = this.alto_bodegas;
                object.largo_bodegas = this.largo_bodegas;
                object.ancho_bodegas = this.ancho_bodegas;
                object.capacidad_bodegas = this.capacidad_bodegas;
                object.tipo_conservacion = this.tipo_conservacion;
                object.nombre_admin_agencia = this.nombre_admin_agencia;
                object.numero_tripulantes = this.numero_tripulantes;
                object.numero_pescadores = this.numero_pescadores;
                object.valor_arte_pesca = this.valor_arte_pesca;
                object.zona_pesca = this.zona_pesca;
                object.denominacion_arte_pesca = this.denominacion_arte_pesca;
                object.otra_denominacion_arte_pesca = this.otra_denominacion_arte_pesca;
                object.tipo_anzuelo = this.tipo_anzuelo;
                object.tamano_anzuelo = this.tamano_anzuelo;
                object.cantidad_anzuelos = this.cantidad_anzuelos;
                object.longitud_linea_madre = this.longitud_linea_madre;
                object.material_linea_madre = this.material_linea_madre;
                object.material_bajantes = this.material_bajantes;
                object.otro_material_bajantes = this.otro_material_bajantes;
                object.cantidad_total_lineas = this.cantidad_total_lineas;
                object.denominacion_alerta = this.denominacion_alerta;
                object.otra_denominacion_del_arte = this.otra_denominacion_del_arte;
                object.cantidad_trampas_nasas = this.cantidad_trampas_nasas;
                object.material_ppal_trampas = this.material_ppal_trampas;
                object.otro_material_ppal = this.otro_material_ppal;
                object.tipo_artefactos = this.tipo_artefactos;
                object.otro_tipo_artefacto = this.otro_tipo_artefacto;
                object.cantidad_artefactos = this.cantidad_artefactos;
                object.material_artefacto = this.material_artefacto;
                object.otro_material_artefacto = this.otro_material_artefacto;
                object.uso_dispositivos = this.uso_dispositivos;
                object.tipo_fad_usados = this.tipo_fad_usados;
                object.otro_tipo_fad_usados = this.otro_tipo_fad_usados;
                object.cantidad_fad_usados = this.cantidad_fad_usados;
                object.componentes_fad = this.componentes_fad;
                //tab6
                object.cartas_navegacion = this.cartas_navegacion;
                object.compas_magnetico = this.compas_magnetico;
                object.gps = this.gps;
                object.loran = this.loran;
                object.radar = this.radar;
                object.ecosonda = this.ecosonda;
                object.radios_comunicacion = this.radios_comunicacion;
                //tab 7
                object.firma_representante = this.firma_representante;
                object.fotos_embarcacion = this.fotos_embarcacion;
                object.observations = this.observations;
                object.status = 1;
                //news
                object.calado = this.calado;
                object.otro_material_casco = this.otro_material_casco;
                object.otra_unidad_potencia = this.otra_unidad_potencia;
                object.otro_tipo_conservacion = this.otro_tipo_conservacion;
                object.radicado = this.radicado;
                object.codigo_verificacion = this.codigo_verificacion;
                object.nombre_propietario = this.nombre_propietario;
                object.tipo_identificacion = this.tipo_identificacion;
                object.otro_tipo_identificacion = this.otro_tipo_identificacion;
                object.numero_identificacion = this.numero_identificacion;
                object.nombre_representante = this.nombre_representante;
                object.tipo_identificacion_representante = this.tipo_identificacion_representante;
                object.otro_tipo_identificacion_representante = this.otro_tipo_identificacion_representante;
                object.numero_identificacion_representante = this.numero_identificacion_representante;
                object.cargo_representante = this.cargo_representante;
                object.artes_de_pesca = this.artes_de_pesca;
                object.otro_arte_pesca = this.otro_arte_pesca;
                object.puerto_desembarque = this.puerto_desembarque;
                object.otro_puerto_desembarque = this.otro_puerto_desembarque;
                this.dataStorage.push(object);
            }
            else {
                let items = this.dataStorage.filter((item) => {
                    return item.id === this.id;
                });
                items.forEach((data) => {
                    //tab 1
                    data.lugar = this.lugar;
                    data.fecha_expedicion = this.fecha_expedicion;
                    //tab 2
                    data.permisionario = this.permisionario;
                    data.nit = this.nit;
                    //tab 3
                    data.nombre_barco = this.nombre_barco;
                    data.numero_matricula = this.numero_matricula ? this.numero_matricula.toUpperCase() : null;
                    data.lugar_matricula = this.lugar_matricula;
                    data.fecha_matricula = this.fecha_matricula;
                    data.vencimiento_matricula = this.vencimiento_matricula;
                    //tab 4
                    data.bandera = this.bandera;
                    data.puerto_registro = this.puerto_registro;
                    data.otro_puerto_registro = this.otro_puerto_registro;
                    data.tipo_barco = this.tipo_barco;
                    data.otro_tipo_barco = this.otro_tipo_barco;
                    data.valor_embarcacion = this.valor_embarcacion;
                    data.venta_productos_a = this.venta_productos_a;
                    //tab 5
                    data.eslora = this.eslora;
                    data.manga = this.manga;
                    data.tonelaje = this.tonelaje;
                    data.tonelaje_registro_bruto = this.tonelaje_registro_bruto;
                    data.potencia_motor_ppal = this.potencia_motor_ppal;
                    data.unidad_potencia = this.unidad_potencia;
                    data.material_casco = this.material_casco;
                    data.numero_bodegas = this.numero_bodegas;
                    data.alto_bodegas = this.alto_bodegas;
                    data.largo_bodegas = this.largo_bodegas;
                    data.ancho_bodegas = this.ancho_bodegas;
                    data.capacidad_bodegas = this.capacidad_bodegas;
                    data.tipo_conservacion = this.tipo_conservacion;
                    data.nombre_admin_agencia = this.nombre_admin_agencia;
                    data.numero_tripulantes = this.numero_tripulantes;
                    data.numero_pescadores = this.numero_pescadores;
                    data.valor_arte_pesca = this.valor_arte_pesca;
                    data.zona_pesca = this.zona_pesca;
                    data.denominacion_arte_pesca = this.denominacion_arte_pesca;
                    data.otra_denominacion_arte_pesca = this.otra_denominacion_arte_pesca;
                    data.tipo_anzuelo = this.tipo_anzuelo;
                    data.tamano_anzuelo = this.tamano_anzuelo;
                    data.cantidad_anzuelos = this.cantidad_anzuelos;
                    data.longitud_linea_madre = this.longitud_linea_madre;
                    data.material_linea_madre = this.material_linea_madre;
                    data.material_bajantes = this.material_bajantes;
                    data.otro_material_bajantes = this.otro_material_bajantes;
                    data.cantidad_total_lineas = this.cantidad_total_lineas;
                    data.denominacion_alerta = this.denominacion_alerta;
                    data.otra_denominacion_del_arte = this.otra_denominacion_del_arte;
                    data.cantidad_trampas_nasas = this.cantidad_trampas_nasas;
                    data.material_ppal_trampas = this.material_ppal_trampas;
                    data.otro_material_ppal = this.otro_material_ppal;
                    data.tipo_artefactos = this.tipo_artefactos;
                    data.otro_tipo_artefacto = this.otro_tipo_artefacto;
                    data.cantidad_artefactos = this.cantidad_artefactos;
                    data.material_artefacto = this.material_artefacto;
                    data.otro_material_artefacto = this.otro_material_artefacto;
                    data.uso_dispositivos = this.uso_dispositivos;
                    data.tipo_fad_usados = this.tipo_fad_usados;
                    data.otro_tipo_fad_usados = this.otro_tipo_fad_usados;
                    data.cantidad_fad_usados = this.cantidad_fad_usados;
                    data.componentes_fad = this.componentes_fad;
                    //tab6
                    data.cartas_navegacion = this.cartas_navegacion;
                    data.compas_magnetico = this.compas_magnetico;
                    data.gps = this.gps;
                    data.loran = this.loran;
                    data.radar = this.radar;
                    data.ecosonda = this.ecosonda;
                    data.radios_comunicacion = this.radios_comunicacion;
                    //tab 7
                    data.firma_representante = this.firma_representante;
                    data.fotos_embarcacion = this.fotos_embarcacion;
                    data.observations = this.observations;
                    data.status = 1;
                    //news
                    data.calado = this.calado;
                    data.otro_material_casco = this.otro_material_casco;
                    data.otra_unidad_potencia = this.otra_unidad_potencia;
                    data.otro_tipo_conservacion = this.otro_tipo_conservacion;
                    data.radicado = this.radicado;
                    data.codigo_verificacion = this.codigo_verificacion;
                    data.nombre_propietario = this.nombre_propietario;
                    data.tipo_identificacion = this.tipo_identificacion;
                    data.otro_tipo_identificacion = this.otro_tipo_identificacion;
                    data.numero_identificacion = this.numero_identificacion;
                    data.nombre_representante = this.nombre_representante;
                    data.tipo_identificacion_representante = this.tipo_identificacion_representante;
                    data.otro_tipo_identificacion_representante = this.otro_tipo_identificacion_representante;
                    data.numero_identificacion_representante = this.numero_identificacion_representante;
                    data.cargo_representante = this.cargo_representante;
                    data.artes_de_pesca = this.artes_de_pesca;
                    data.otro_arte_pesca = this.otro_arte_pesca;
                    data.puerto_desembarque = this.puerto_desembarque;
                    data.otro_puerto_desembarque = this.otro_puerto_desembarque;
                });
            }
            yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_5__.Preferences.set({
                key: 'dataRegistersIndustrial',
                value: JSON.stringify(this.dataStorage),
            }).then(() => {
                this.AlertStore();
            });
        });
    }
    //uplad register server
    AlertStore() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Confirmación',
                message: 'Datos almacenados exitosamente',
                buttons: [
                    {
                        text: 'Aceptar',
                        handler: () => {
                            this.actualTab = 0;
                            this.counter = 0;
                            this.searchBoat = false;
                            this.matricula_search = null;
                            this.events.publish('updateRegisters', []);
                            this.router.navigate(["registers"]);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    //validate fields
    inputValidator(event) {
        //console.log(event.target.value);
        const pattern = /^[a-zA-Z0-9]*$/;
        //let inputChar = String.fromCharCode(event.charCode)
        if (!pattern.test(event.target.value)) {
            event.target.value = event.target.value.replace(/[^a-zA-Z0-9]/g, "");
            // invalid character, prevent input
        }
    }
    //validate fields
    numberValidator(event) {
        //console.log(event.target.value);
        const pattern = /^[0-9 -]*$/;
        //let inputChar = String.fromCharCode(event.charCode)
        if (!pattern.test(event.target.value)) {
            event.target.value = event.target.value.replace(/[^0-9 -]/g, "");
            // invalid character, prevent input
        }
    }
    //calculate size storage
    calculateSize() {
        var largo = this.largo_bodegas || 0;
        var alto = this.alto_bodegas || 0;
        var ancho = this.ancho_bodegas || 0;
        this.capacidad_bodegas = Number(largo * alto * ancho);
    }
    //search validate
    validateSearch() {
        if (this.matricula_search.length < 4) {
            this.presentMessage('Advertencia', 'Debe envíar un número de matricula mayor o igual a 5 carácteres.');
            return;
        }
        const logCurrentNetworkStatus = () => (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const status = yield _capacitor_network__WEBPACK_IMPORTED_MODULE_4__.Network.getStatus();
            //console.log(status);
            if (status.connected === true) {
                this.searchVessel();
            }
            else {
                this.searchBoat = true;
                this.presentMessage('Advertencia', 'No es posible realizar la búsqueda, conéctese a internet o realice un nuevo registro');
            }
        });
        logCurrentNetworkStatus();
    }
    //search vessel
    searchVessel() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Cargando...',
                spinner: 'crescent',
                showBackdrop: true,
            });
            yield loading.present();
            console.log(this.matricula_search);
            this.api.searchVessel("Bearer " + this.userToken, this.matricula_search + "/ind").subscribe(response => {
                loading.dismiss();
                console.log("Response: ", response);
                if (response[0].data[0].type_boat == 'IND') {
                    this.searchBoat = true;
                    if (response[0] && response[0].data && response[0].data[0]) {
                        let imagesArray = []; //images
                        if (response[0].data[0].images && response[0].data[0].images.length > 0) {
                            response[0].data[0].images.map(data => {
                                imagesArray.push({
                                    image: data.nombre,
                                });
                            });
                        }
                        //tab 1
                        this.lugar = response[0].data[0].lugar;
                        console.log(this.lugar);
                        this.fecha_expedicion = response[0].data[0].fecha_expedicion;
                        //tab 2
                        // this.permisionario = response[0].data[0].nombre_propietario;
                        this.permisionario = response[0].data[0].permisionario;
                        this.nit = response[0].data[0].nit;
                        //tab 3
                        this.nombre_barco = response[0].data[0].nombre_barco;
                        this.numero_matricula = response[0].data[0].numero_matricula;
                        this.lugar_matricula = response[0].data[0].lugar_matricula;
                        this.fecha_matricula = response[0].data[0].fecha_matricula;
                        this.vencimiento_matricula = response[0].data[0].vencimiento_matricula;
                        //tab 4
                        this.bandera = response[0].data[0].bandera;
                        this.puerto_registro = response[0].data[0].puerto_registro;
                        // this.otro_puerto_registro = response[0].data[0].otro_puerto_registro;
                        this.otro_puerto_registro = this.portsRegister[17].nombre;
                        this.tipo_barco = response[0].data[0].tipo_barco;
                        this.otro_tipo_barco = response[0].data[0].otro_tipo_barco;
                        this.valor_embarcacion = response[0].data[0].valor_embarcacion;
                        this.venta_productos_a = response[0].data[0].venta_productos_a;
                        //tab 5
                        this.calado = response[0].data[0].calado;
                        this.eslora = response[0].data[0].eslora;
                        this.manga = response[0].data[0].manga;
                        this.tonelaje = response[0].data[0].tonelaje;
                        this.tonelaje_registro_bruto = response[0].data[0].tonelaje_registro_bruto;
                        this.potencia_motor_ppal = response[0].data[0].potencia_motor_ppal;
                        this.unidad_potencia = response[0].data[0].unidad_potencia;
                        this.material_casco = response[0].data[0].material_casco;
                        this.numero_bodegas = response[0].data[0].numero_bodegas;
                        this.alto_bodegas = response[0].data[0].alto_bodegas;
                        this.largo_bodegas = response[0].data[0].largo_bodegas;
                        this.ancho_bodegas = response[0].data[0].ancho_bodegas;
                        this.capacidad_bodegas = response[0].data[0].capacidad_bodegas;
                        this.tipo_conservacion = response[0].data[0].tipo_conservacion;
                        this.nombre_admin_agencia = response[0].data[0].nombre_admin_agencia;
                        this.numero_tripulantes = response[0].data[0].numero_tripulantes;
                        this.numero_pescadores = response[0].data[0].numero_pescadores;
                        this.valor_arte_pesca = response[0].data[0].valor_arte_pesca;
                        this.zona_pesca = response[0].data[0].zona_pesca;
                        this.denominacion_arte_pesca = response[0].data[0].denominacion_arte_pesca;
                        this.otra_denominacion_arte_pesca = response[0].data[0].otra_denominacion_arte_pesca;
                        this.tipo_anzuelo = response[0].data[0].tipo_anzuelo;
                        this.tamano_anzuelo = response[0].data[0].tamano_anzuelo;
                        this.cantidad_anzuelos = response[0].data[0].cantidad_anzuelos;
                        this.longitud_linea_madre = response[0].data[0].longitud_linea_madre;
                        this.material_linea_madre = response[0].data[0].material_linea_madre;
                        this.material_bajantes = response[0].data[0].material_bajantes;
                        this.otro_material_bajantes = response[0].data[0].otro_material_bajantes;
                        this.cantidad_total_lineas = response[0].data[0].cantidad_total_lineas;
                        this.denominacion_alerta = response[0].data[0].denominacion_alerta;
                        this.otra_denominacion_del_arte = response[0].data[0].otra_denominacion_del_arte;
                        this.cantidad_trampas_nasas = response[0].data[0].cantidad_trampas_nasas;
                        this.material_ppal_trampas = response[0].data[0].material_ppal_trampas;
                        this.otro_material_ppal = response[0].data[0].otro_material_ppal;
                        this.tipo_artefactos = response[0].data[0].tipo_artefactos;
                        this.otro_tipo_artefacto = response[0].data[0].otro_tipo_artefacto;
                        this.cantidad_artefactos = response[0].data[0].cantidad_artefactos;
                        this.material_artefacto = response[0].data[0].material_artefacto;
                        this.otro_material_artefacto = response[0].data[0].otro_material_artefacto;
                        this.uso_dispositivos = response[0].data[0].uso_dispositivos;
                        this.tipo_fad_usados = response[0].data[0].tipo_fad_usados;
                        this.otro_tipo_fad_usados = response[0].data[0].otro_tipo_fad_usados;
                        this.cantidad_fad_usados = response[0].data[0].cantidad_fad_usados;
                        this.componentes_fad = response[0].data[0].componentes_fad;
                        //tab6
                        this.cartas_navegacion = response[0].data[0].cartas_navegacion;
                        this.compas_magnetico = response[0].data[0].compas_magnetico;
                        this.gps = response[0].data[0].gps;
                        this.loran = response[0].data[0].loran;
                        this.radar = response[0].data[0].radar;
                        this.ecosonda = response[0].data[0].ecosonda;
                        this.radios_comunicacion = response[0].data[0].radios_comunicacion;
                        //tab 7
                        this.firma_representante = response[0].data[0].firma_representante;
                        this.fotos_embarcacion = imagesArray;
                        this.observations = response[0].data[0].observations;
                        //new
                        this.nombre_propietario = response[0].data[0].nombre_propietario;
                        this.tipo_identificacion = response[0].data[0].tipo_identificacion;
                        this.otro_tipo_identificacion = response[0].data[0].otro_tipo_identificacion;
                        this.numero_identificacion = response[0].data[0].numero_identificacion;
                        //nuevos
                        this.calado = response[0].data[0].calado;
                        this.otro_material_casco = response[0].data[0].otro_material_casco;
                        this.otra_unidad_potencia = response[0].data[0].otra_unidad_potencia;
                        this.otro_tipo_conservacion = response[0].data[0].otro_tipo_conservacion;
                        this.radicado = response[0].data[0].radicado;
                        this.codigo_verificacion = response[0].data[0].codigo_verificacion;
                        this.nombre_representante = response[0].data[0].nombre_representante;
                        this.tipo_identificacion_representante = response[0].data[0].tipo_identificacion_representante;
                        this.otro_tipo_identificacion_representante = response[0].data[0].otro_tipo_identificacion_representante;
                        this.numero_identificacion_representante = response[0].data[0].numero_identificacion_representante;
                        this.cargo_representante = response[0].data[0].cargo_representante;
                        this.artes_de_pesca = response[0].data[0].fishing_arts;
                        this.otro_arte_pesca = response[0].data[0].otro_arte_pesca;
                        this.puerto_desembarque = response[0].data[0].puerto_desembarque;
                        this.otro_puerto_desembarque = response[0].data[0].otro_puerto_desembarque;
                        this.presentMessage('Resultado exitoso', 'REGISTRO ENCONTRADO');
                    }
                }
                else {
                    this.searchBoat = false;
                    this.presentMessage('Advertencia', 'REGISTRO NO ENCONTRADO');
                }
            }, err => {
                loading.dismiss();
                this.presentMessage('Advertencia', 'No podemos establecer conexión con el servidor, por favor cierre y vuelva a iniciar sesión e intente de nuevo');
            });
        });
    }
    //alert with warning
    presentMessage(title, message, redirect = false) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: title,
                message: message,
                backdropDismiss: false,
                buttons: [
                    {
                        text: 'OK',
                        handler: () => redirect ? this.router.navigate(['registers']) : null
                    }
                ]
            });
            yield alert.present();
        });
    }
};
IndustrialsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ActionSheetController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute },
    { type: src_app_services_api_rest_service__WEBPACK_IMPORTED_MODULE_7__.ApiRestService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router },
    { type: src_app_config_events__WEBPACK_IMPORTED_MODULE_3__.Events }
];
IndustrialsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-industrials',
        template: _industrials_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_industrials_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], IndustrialsPage);



/***/ }),

/***/ 5217:
/*!********************************************************************!*\
  !*** ./src/app/pages/industrials/industrials.page.scss?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --background: #fafafa;\n}\nion-content ion-grid.headerGrid {\n  background: #fafafa;\n  position: fixed;\n  width: 100%;\n  z-index: 99999;\n}\nion-content ion-grid.headerGrid ion-row {\n  padding: 30px;\n  text-align: center;\n}\nion-content ion-grid.headerGrid ion-row ion-col ion-icon {\n  color: #bad320;\n}\nion-content ion-grid.headerGrid ion-row ion-col ion-icon.active {\n  border-radius: 50%;\n  background: #bad320;\n  color: #fff;\n}\nion-content ion-grid.headerGrid ion-row ion-col ion-icon.inactive {\n  color: #bad320;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid.headerGrid ion-row ion-col ion-icon {\n    font-size: 20px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid.headerGrid ion-row ion-col ion-icon {\n    font-size: 25px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid.headerGrid ion-row ion-col ion-icon {\n    font-size: 35px;\n  }\n}\n@media (min-width: 319px) {\n  ion-content ion-grid.marginInitial {\n    margin-top: 70px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid.marginInitial {\n    margin-top: 80px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid.marginInitial {\n    margin-top: 90px;\n  }\n}\nion-content ion-grid.marginInitial ion-row ion-col h2 {\n  font-family: \"Poppins\", sans-serif;\n  color: #2f6da8;\n  margin-bottom: 30px;\n  text-align: center;\n}\nion-content ion-grid.marginInitial ion-row ion-col ion-item {\n  --background: transparent;\n}\nion-content ion-grid.marginInitial ion-row ion-col ion-item ion-label {\n  color: #000015;\n  font-family: \"Poppins\", sans-serif;\n}\nion-content ion-grid.marginInitial ion-row ion-col ion-item ion-input {\n  margin: 5px 0 0;\n  border: 1px solid #f2F2F2;\n  --background: #fff;\n  --padding-start: 15px;\n  font-family: \"Poppins\", sans-serif;\n  --placeholder-color: #bdbdbd;\n}\nion-content ion-grid.marginInitial ion-row ion-col ion-item ion-datetime {\n  background: #fff;\n  margin: 5px 0 0;\n  border: 1px solid #f2F2F2;\n  --padding-start: 15px;\n  font-family: \"Poppins\", sans-serif;\n}\nion-content ion-grid.marginInitial ion-row ion-col ion-item ion-select {\n  background: #fff;\n  margin: 5px 0 0;\n  border: 1px solid #f2F2F2;\n  --padding-start: 15px;\n  font-family: \"Poppins\", sans-serif;\n}\nion-content ion-grid.marginInitial ion-row ion-col ion-item ion-textarea {\n  background: #fff;\n  margin: 5px 0 0;\n  border: 1px solid #e6e6e6;\n  --padding-start: 15px;\n  font-family: \"Poppins\", sans-serif;\n}\nion-content ion-grid.marginInitial ion-row ion-col ion-item ionic-selectable {\n  background: #fff;\n  margin: 5px 0 0;\n  border: 1px solid #f2F2F2;\n  padding-left: 15px;\n  font-family: \"Poppins\", sans-serif;\n}\nion-content ion-grid.marginInitial ion-row img.imgAdd {\n  max-width: 100%;\n  max-height: 100px;\n}\nion-content ion-grid.marginInitial ion-row img.imgEnd {\n  margin-top: 30px;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid.marginInitial ion-row img.imgEnd {\n    max-width: 140px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid.marginInitial ion-row img.imgEnd {\n    max-width: 180px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid.marginInitial ion-row img.imgEnd {\n    max-width: 180px;\n  }\n}\nion-content ion-grid.marginInitial ion-row ion-icon {\n  position: absolute;\n  top: 0;\n  right: 5px;\n  border-radius: 50%;\n  background-color: red;\n  padding: 5px;\n}\nion-content ion-grid.marginInitial ion-row ion-button {\n  margin: 30px 0 0;\n  font-family: \"Poppins\", sans-serif;\n  --background: #2f6da8;\n  /* Old browsers */\n  --background: -moz-linear-gradient(left, #2f6da8 0%, #3192c8 76%, #73ad7d 100%);\n  /* FF3.6-15 */\n  --background: -webkit-linear-gradient(left, #2f6da8 0%, #3192c8 76%, #73ad7d 100%);\n  /* Chrome10-25,Safari5.1-6 */\n  --background: linear-gradient(to right, #2f6da8 0%, #3192c8 76%, #73ad7d 100%);\n  /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  --background-activated: #006fa6;\n  --background-focused: #006fa6;\n  --background-hover: #006fa6;\n  --color: #ffffff;\n  --border-radius: 50px;\n  --padding-start: 30px;\n  --padding-end: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZHVzdHJpYWxzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHFCQUFBO0FBQ0o7QUFFUTtFQUNJLG1CQUFBO0VBRUEsZUFBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0FBRFo7QUFHWTtFQUNJLGFBQUE7RUFDQSxrQkFBQTtBQURoQjtBQUlvQjtFQVdJLGNBQUE7QUFaeEI7QUFFd0I7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtBQUE1QjtBQUd3QjtFQUNJLGNBQUE7QUFENUI7QUFNd0I7RUFiSjtJQWNRLGVBQUE7RUFIMUI7QUFDRjtBQUt3QjtFQWpCSjtJQWtCUSxlQUFBO0VBRjFCO0FBQ0Y7QUFJd0I7RUFyQko7SUFzQlEsZUFBQTtFQUQxQjtBQUNGO0FBUVk7RUFESjtJQUVRLGdCQUFBO0VBTGQ7QUFDRjtBQU9ZO0VBTEo7SUFNUSxnQkFBQTtFQUpkO0FBQ0Y7QUFNWTtFQVRKO0lBVVEsZ0JBQUE7RUFIZDtBQUNGO0FBT29CO0VBQ0ksa0NBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUx4QjtBQVFvQjtFQUNJLHlCQUFBO0FBTnhCO0FBUXdCO0VBQ0ksY0FBQTtFQUNBLGtDQUFBO0FBTjVCO0FBU3dCO0VBQ0ksZUFBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtFQUNBLGtDQUFBO0VBQ0EsNEJBQUE7QUFQNUI7QUFVd0I7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0NBQUE7QUFSNUI7QUFXd0I7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0NBQUE7QUFUNUI7QUFZd0I7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0NBQUE7QUFWNUI7QUFhd0I7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0NBQUE7QUFYNUI7QUFpQm9CO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0FBZnhCO0FBa0JvQjtFQUNJLGdCQUFBO0FBaEJ4QjtBQWtCd0I7RUFISjtJQUlRLGdCQUFBO0VBZjFCO0FBQ0Y7QUFpQndCO0VBUEo7SUFRUSxnQkFBQTtFQWQxQjtBQUNGO0FBZ0J3QjtFQVhKO0lBWVEsZ0JBQUE7RUFiMUI7QUFDRjtBQWlCZ0I7RUFDSSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtFQUNBLFlBQUE7QUFmcEI7QUFrQmdCO0VBQ0ksZ0JBQUE7RUFDQSxrQ0FBQTtFQUNBLHFCQUFBO0VBQ0EsaUJBQUE7RUFDQSwrRUFBQTtFQUNBLGFBQUE7RUFDQSxrRkFBQTtFQUNBLDRCQUFBO0VBQ0EsOEVBQUE7RUFDQSxxREFBQTtFQUNBLCtCQUFBO0VBQ0EsNkJBQUE7RUFDQSwyQkFBQTtFQUNBLGdCQUFBO0VBQ0EscUJBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0FBaEJwQiIsImZpbGUiOiJpbmR1c3RyaWFscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNmYWZhZmE7XHJcblxyXG4gICAgaW9uLWdyaWQge1xyXG4gICAgICAgICYuaGVhZGVyR3JpZCB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmYWZhZmE7XHJcbiAgICAgICAgICAgIDtcclxuICAgICAgICAgICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgei1pbmRleDogOTk5OTk7XHJcblxyXG4gICAgICAgICAgICBpb24tcm93IHtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDMwcHg7XHJcbiAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblxyXG4gICAgICAgICAgICAgICAgaW9uLWNvbCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAmLmFjdGl2ZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjYmFkMzIwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICYuaW5hY3RpdmUge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICNiYWQzMjA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjYmFkMzIwO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDMxOXB4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAzNzRweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAyNXB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogNDE1cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMzVweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgJi5tYXJnaW5Jbml0aWFsIHtcclxuICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDMxOXB4KSB7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiA3MHB4O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogMzc0cHgpIHtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDgwcHg7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiA0MTVweCkge1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogOTBweDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaW9uLXJvdyB7XHJcbiAgICAgICAgICAgICAgICBpb24tY29sIHtcclxuICAgICAgICAgICAgICAgICAgICBoMiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjMmY2ZGE4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAzMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBpb24taXRlbSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpb24tbGFiZWwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICMwMDAwMTU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpb24taW5wdXQge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiA1cHggMCAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2YyRjJGMjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC0tcGFkZGluZy1zdGFydDogMTVweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAtLXBsYWNlaG9sZGVyLWNvbG9yOiAjYmRiZGJkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpb24tZGF0ZXRpbWUge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogNXB4IDAgMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNmMkYyRjI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDE1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpb24tc2VsZWN0IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDVweCAwIDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZjJGMkYyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAxNXB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaW9uLXRleHRhcmVhIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDVweCAwIDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZTZlNmU2O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAxNXB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaW9uaWMtc2VsZWN0YWJsZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiA1cHggMCAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2YyRjJGMjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMTVweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaW1nIHtcclxuICAgICAgICAgICAgICAgICAgICAmLmltZ0FkZCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1heC13aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWF4LWhlaWdodDogMTAwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAmLmltZ0VuZCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDMwcHg7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogMzE5cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heC13aWR0aDogMTQwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAzNzRweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4LXdpZHRoOiAxODBweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDQxNXB4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXgtd2lkdGg6IDE4MHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlvbi1pY29uIHtcclxuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgICAgICAgICAgdG9wOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgIHJpZ2h0OiA1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJlZDtcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiA1cHhcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBpb24tYnV0dG9uIHtcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDMwcHggMCAwO1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOiAjMmY2ZGE4O1xyXG4gICAgICAgICAgICAgICAgICAgIC8qIE9sZCBicm93c2VycyAqL1xyXG4gICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZDogLW1vei1saW5lYXItZ3JhZGllbnQobGVmdCwgIzJmNmRhOCAwJSwgIzMxOTJjOCA3NiUsICM3M2FkN2QgMTAwJSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLyogRkYzLjYtMTUgKi9cclxuICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KGxlZnQsICMyZjZkYTggMCUsICMzMTkyYzggNzYlLCAjNzNhZDdkIDEwMCUpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8qIENocm9tZTEwLTI1LFNhZmFyaTUuMS02ICovXHJcbiAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICMyZjZkYTggMCUsICMzMTkyYzggNzYlLCAjNzNhZDdkIDEwMCUpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8qIFczQywgSUUxMCssIEZGMTYrLCBDaHJvbWUyNissIE9wZXJhMTIrLCBTYWZhcmk3KyAqL1xyXG4gICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICMwMDZmYTY7XHJcbiAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6ICMwMDZmYTY7XHJcbiAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjMDA2ZmE2O1xyXG4gICAgICAgICAgICAgICAgICAgIC0tY29sb3I6ICNmZmZmZmY7XHJcbiAgICAgICAgICAgICAgICAgICAgLS1ib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIC0tcGFkZGluZy1zdGFydDogMzBweDtcclxuICAgICAgICAgICAgICAgICAgICAtLXBhZGRpbmctZW5kOiAzMHB4O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il19 */";

/***/ }),

/***/ 8944:
/*!********************************************************************!*\
  !*** ./src/app/pages/industrials/industrials.page.html?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "<app-menu TitleBar=\"Inspección Industrial\" isMenuVisible=\"false\" isCloseVisible=\"true\"></app-menu>\r\n\r\n<ion-content>\r\n\r\n    <!-- header fixed -->\r\n    <ion-grid class=\"ion-no-padding ion-no-margin headerGrid\">\r\n        <ion-row class=\"ion-no-padding ion-no-margin\">\r\n            <ion-col class=\"ion-no-padding ion-no-margin\" *ngIf=\"id==0\">\r\n                <ion-icon name=\"{{ tab0==1 ? 'checkmark-circle-outline' :\r\n                    'ellipse-outline' }}\" [ngClass]=\"tab0==1 ? 'active' :\r\n                    'inactive'\"></ion-icon><br>\r\n            </ion-col>\r\n            <ion-col class=\"ion-no-padding ion-no-margin\">\r\n                <ion-icon name=\"{{ tab1==1 ? 'checkmark-circle-outline' :\r\n                    'ellipse-outline' }}\" [ngClass]=\"tab1==1 ? 'active' :\r\n                    'inactive'\"></ion-icon><br>\r\n            </ion-col>\r\n            <ion-col class=\"ion-no-padding ion-no-margin\">\r\n                <ion-icon name=\"{{ tab2==1 ? 'checkmark-circle-outline' :\r\n                    'ellipse-outline' }}\" [ngClass]=\"tab2==1 ? 'active' :\r\n                    'inactive'\"></ion-icon><br>\r\n            </ion-col>\r\n            <ion-col class=\"ion-no-padding ion-no-margin\">\r\n                <ion-icon name=\"{{ tab3==1 ? 'checkmark-circle-outline' :\r\n                    'ellipse-outline' }}\" [ngClass]=\"tab3==1 ? 'active' :\r\n                    'inactive'\"></ion-icon><br>\r\n            </ion-col>\r\n            <ion-col class=\"ion-no-padding ion-no-margin\">\r\n                <ion-icon name=\"{{ tab4==1 ? 'checkmark-circle-outline' :\r\n                    'ellipse-outline' }}\" [ngClass]=\"tab4==1 ? 'active' :\r\n                    'inactive'\"></ion-icon><br>\r\n            </ion-col>\r\n            <ion-col class=\"ion-no-padding ion-no-margin\">\r\n                <ion-icon name=\"{{ tab5==1 ? 'checkmark-circle-outline' :\r\n                    'ellipse-outline' }}\" [ngClass]=\"tab5==1 ? 'active' :\r\n                    'inactive'\"></ion-icon><br>\r\n            </ion-col>\r\n            <ion-col class=\"ion-no-padding ion-no-margin\">\r\n                <ion-icon name=\"{{ tab6==1 ? 'checkmark-circle-outline' :\r\n                    'ellipse-outline' }}\" [ngClass]=\"tab6==1 ? 'active' :\r\n                    'inactive'\"></ion-icon><br>\r\n            </ion-col>\r\n            <ion-col class=\"ion-no-padding ion-no-margin\">\r\n                <ion-icon name=\"{{ tab7==1 ? 'checkmark-circle-outline' :\r\n                    'ellipse-outline' }}\" [ngClass]=\"tab7==1 ? 'active' :\r\n                    'inactive'\"></ion-icon><br>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- zero tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==0 && id==0\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Buscar embarcación\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Digite matricula de la embarcación</ion-label>\r\n                    <ion-input [(ngModel)]=\"matricula_search\"  style=\"text-transform: uppercase;\"\r\n                    (ionChange)=\"inputValidator($event)\" (keydown.space)=\"$event.preventDefault();\"></ion-input>\r\n                    <small style=\"margin-top: 10px;\">(Sin espacios ni caracteres especiales Ej. -#%?/)</small>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" align=\"center\">\r\n                <ion-button (click)=\"validateSearch()\" color=\"success\">\r\n                    Buscar embarcación\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"12\" align=\"center\" *ngIf=\"searchBoat\">\r\n                <ion-button (click)=\"nextTab()\">\r\n                    Continuar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- first tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==1\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Datos de solicitud\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Lugar *</ion-label>\r\n                    <!-- <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"lugar\"\r\n                        itemValueField=\"cod\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable> -->\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"lugar\" \r\n                        [canSearch]=\"false\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Fecha de expedición *</ion-label>\r\n                    <ion-datetime presentation=\"date\" [(ngModel)]=\"fecha_expedicion\" displayFormat=\"YYYY-MM-DD\" pickerFormat=\"YYYY-MMM-DD\"\r\n                        max=\"2030\" placeholder=\"Seleccione la fecha\"></ion-datetime>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Radicado</ion-label>\r\n                    <ion-input [(ngModel)]=\"radicado\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col *ngIf=\"actualTab>0 && id == 0\" size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"antTab()\">\r\n                    Volver\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"{{ id==0 ? '6' : '12' }}\" align=\"center\">\r\n                <ion-button (click)=\"nextTab()\" [disabled]=\"!lugar ||\r\n                    !fecha_expedicion\">\r\n                    Continuar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- second tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==2\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Datos del permisionario\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Permisionario y/o Titular *</ion-label>\r\n                    <ion-input [(ngModel)]=\"permisionario\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Número de NIT *</ion-label>\r\n                    <ion-row>\r\n                        <ion-col size=\"9\">\r\n                            <ion-input type=\"number\"\r\n                                pattern=\"[0-9]\" \r\n                                onkeypress=\"return !(event.charCode == 46 || event.charCode == 45 || event.charCode == 44 )\" step=\"1\"\r\n                                (keydown.space)=\"$event.preventDefault();\" [(ngModel)]=\"nit\" placeholder=\"8019345678\"></ion-input>\r\n                        </ion-col>\r\n                        <ion-col size=\"1\" align=\"center\">\r\n                            <p>\r\n                                -\r\n                            </p>\r\n                        </ion-col>\r\n                        <ion-col size=\"2\">\r\n                            <ion-input type=\"number\" [(ngModel)]=\"codigo_verificacion\" min=\"0\" max=\"9\" placeholder=\"1\">\r\n                            </ion-input>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col *ngIf=\"actualTab>0\" size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"antTab()\">\r\n                    Volver\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <!-- <ion-button (click)=\"nextTab()\" [disabled]=\"!permisionario || !nit || !codigo_verificacion\"> -->\r\n                <ion-button (click)=\"nextTab()\">\r\n                    Continuar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- third tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==3\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Identificación de la Embarcación\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Nombre del Representante de la\r\n                        Embarcación</ion-label>\r\n                    <ion-input type=\"text\" [(ngModel)]=\"nombre_representante\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Tipo de identificación</ion-label>\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"tipo_identificacion_representante\">\r\n                        <ion-select-option value=\"1\">C.C</ion-select-option>\r\n                        <ion-select-option value=\"2\">C.E</ion-select-option>\r\n                        <ion-select-option value=\"3\">Otro</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"tipo_identificacion_representante &&\r\n                tipo_identificacion_representante == 3\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">¿Cuál?</ion-label>\r\n                    <ion-input type=\"text\" [(ngModel)]=\"otro_tipo_identificacion_representante\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Número de Identificación</ion-label>\r\n                    <ion-input type=\"text\" [(ngModel)]=\"numero_identificacion_representante\" (ionChange)=\"numberValidator($event)\" (keydown.space)=\"$event.preventDefault();\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Cargo del representante</ion-label>\r\n                    <ion-input type=\"text\" [(ngModel)]=\"cargo_representante\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Nombre del Barco</ion-label>\r\n                    <ion-input [(ngModel)]=\"nombre_barco\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Número de la Matrícula*</ion-label>\r\n                    <small>(Sin espacios ni caracteres especiales Ej. -#%?/)</small>\r\n                    <ion-input [(ngModel)]=\"numero_matricula\" style=\"text-transform: uppercase;\"\r\n                        (ionChange)=\"inputValidator($event)\" (keydown.space)=\"$event.preventDefault();\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Lugar de expedición Matrícula</ion-label>\r\n                    <ion-input [(ngModel)]=\"lugar_matricula\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Fecha de expedición Matrícula</ion-label>\r\n                    <ion-datetime presentation=\"date\" [(ngModel)]=\"fecha_matricula\" displayFormat=\"YYYY-MM-DD\" pickerFormat=\"YYYY-MMM-DD\"\r\n                        max=\"2030\" placeholder=\"Seleccione la fecha\"></ion-datetime>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Fecha de vencimiento Matrícula</ion-label>\r\n                    <ion-datetime presentation=\"date\" [(ngModel)]=\"vencimiento_matricula\" displayFormat=\"YYYY-MM-DD\"\r\n                        pickerFormat=\"YYYY-MMM-DD\" max=\"2030\" placeholder=\"Seleccione la fecha\"></ion-datetime>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col *ngIf=\"actualTab>0\" size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"antTab()\">\r\n                    Volver\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"nextTab()\" [disabled]=\"!numero_matricula\">\r\n                    Continuar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- four tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==4\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Datos del registro\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Estado del pabellón (Bandera)</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"bandera\" [items]=\"countries\"\r\n                        itemValueField=\"code\" itemTextField=\"name\" [canSearch]=\"true\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Puerto de Registro</ion-label>\r\n                    <!-- <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"puerto_registro\"\r\n                        [items]=\"portsRegister\" itemValueField=\"codigo\" itemTextField=\"nombre\" [canSearch]=\"true\">\r\n                    </ionic-selectable> -->\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"puerto_registro\">\r\n                        <ion-select-option value=\"{{ m.codigo }}\" *ngFor=\"let m of portsRegister\">{{ m.nombre }}</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n            \r\n            <!-- <ion-col size=\"12\" *ngIf=\"puerto_registro && puerto_registro.codigo == 98\"> -->\r\n            <ion-col size=\"12\" *ngIf=\"puerto_registro && puerto_registro == 98\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otro_puerto_registro\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Puerto de desembarque</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"puerto_desembarque\"\r\n                        [items]=\"dembarquePorts\" itemValueField=\"codigo\" itemTextField=\"nombre\" [canSearch]=\"true\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"puerto_desembarque && puerto_desembarque.codigo == 98\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otro_puerto_desembarque\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Tipo de Barco</ion-label>\r\n                    <!-- <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"tipo_barco\" \r\n                        [items]=\"shipTypes\" itemValueField=\"index\" itemTextField=\"name\" [canSearch]=\"true\" >\r\n                    </ionic-selectable> -->\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"tipo_barco\">\r\n                        <ion-select-option value=\"{{ m.index }}\" *ngFor=\"let m of shipTypes\">{{ m.name }}</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"tipo_barco && tipo_barco.index == 98\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otro_tipo_barco\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Valor Aproximado</ion-label>\r\n                    <ion-input type=\"text\" [(ngModel)]=\"valor_embarcacion\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Vender Productos a</ion-label>\r\n                    <ion-input [(ngModel)]=\"venta_productos_a\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col *ngIf=\"actualTab>0\" size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"antTab()\">\r\n                    Volver\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"nextTab()\">\r\n                    Continuar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- five tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==5\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Características\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Calado (m)</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"calado\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Eslora (LOA)m</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"eslora\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Manga ext. (m)</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"manga\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Tonelaje R. Neto (TRN)</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"tonelaje\" placeholder=\"TRN\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Tonelaje R. Bruto (TRB)</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"tonelaje_registro_bruto\" placeholder=\"TRB\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Potencia Motor Ppal.</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"potencia_motor_ppal\" placeholder=\"Motor\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Unidad de potencia</ion-label>\r\n                    <!-- <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"unidad_potencia\"\r\n                        [items]=\"unityPotences\" itemValueField=\"code\" itemTextField=\"name\" [canSearch]=\"true\">\r\n                    </ionic-selectable> -->\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"unidad_potencia\">\r\n                        <ion-select-option value=\"{{ m.code }}\" *ngFor=\"let m of unityPotences\">{{ m.name }}</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"unidad_potencia && unidad_potencia.id ==\r\n                3\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otra_unidad_potencia\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Material Casco</ion-label>\r\n                    <!-- <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"material_casco\"\r\n                        [items]=\"materialsCasco\" itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"true\">\r\n                    </ionic-selectable> -->\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"material_casco\">\r\n                        <ion-select-option value=\"{{ m.id }}\" *ngFor=\"let m of materialsCasco\">{{ m.name }}</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"material_casco && material_casco.id ==\r\n                98\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otro_material_casco\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Número de bodegas</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"numero_bodegas\" placeholder=\"Bodegas..\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Alto de la bodega</ion-label>\r\n                    <ion-input type=\"number\" (ionChange)=\"calculateSize()\" [(ngModel)]=\"alto_bodegas\"\r\n                        placeholder=\"Metros..\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Largo de la bodega</ion-label>\r\n                    <ion-input type=\"number\" (ionChange)=\"calculateSize()\" [(ngModel)]=\"largo_bodegas\"\r\n                        placeholder=\"Metros..\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Ancho de la bodega</ion-label>\r\n                    <ion-input type=\"number\" (ionChange)=\"calculateSize()\" [(ngModel)]=\"ancho_bodegas\"\r\n                        placeholder=\"Metros..\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Capacidad de la bodega (m3)</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"capacidad_bodegas\" placeholder=\"m3\" readonly=\"true\" style=\"background:\r\n                        #F2f2f2\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Tipo de conservación del\r\n                        pescado</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"tipo_conservacion\"\r\n                        [items]=\"conservationFish\" itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"true\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"tipo_conservacion && tipo_conservacion.id == 98\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otro_tipo_conservacion\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Nombre del Propietario</ion-label>\r\n                    <ion-input type=\"text\" [(ngModel)]=\"nombre_propietario\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Tipo de identificación</ion-label>\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"tipo_identificacion\">\r\n                        <ion-select-option value=\"CC\">C.C</ion-select-option>\r\n                        <ion-select-option value=\"CE\">C.E</ion-select-option>\r\n                        <ion-select-option value=\"NIT\">NIT</ion-select-option>\r\n                        <ion-select-option value=\"Otro\">Otro</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"tipo_identificacion && tipo_identificacion\r\n                == 3\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">¿Cuál?</ion-label>\r\n                    <ion-input type=\"text\" [(ngModel)]=\"otro_tipo_identificacion\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Número de Identificación</ion-label>\r\n                    <ion-input type=\"text\" \r\n                        (ionChange)=\"numberValidator($event)\" (keydown.space)=\"$event.preventDefault();\"\r\n                        [(ngModel)]=\"numero_identificacion\"\r\n                    ></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">\r\n                        Nombre del administrador o Agencia Marítima\r\n                    </ion-label>\r\n                    <ion-input type=\"text\" [(ngModel)]=\"nombre_admin_agencia\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">No. tripulantes</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"numero_tripulantes\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">No. pescadores</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"numero_pescadores\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Artes de pesca *</ion-label>\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"artes_de_pesca\" multiple=\"true\">\r\n                        <ion-select-option *ngFor=\"let item of artesPesca\" value=\"{{ item.id }}\" >{{ item.nombre }}</ion-select-option>\r\n                       <!-- <ion-select-option value=2>Nasas</ion-select-option>\r\n                        <ion-select-option value=3>Buceo</ion-select-option>\r\n                        <ion-select-option value=98>Otro</ion-select-option> -->\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\" *ngIf=\"artes_de_pesca &&\r\n                artes_de_pesca.includes('4')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Otro arte de pesca, ¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otro_arte_pesca\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Valor Arte de pesca</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"valor_arte_pesca\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Zona de pesca</ion-label>\r\n                    <ion-input type=\"text\" [(ngModel)]=\"zona_pesca\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\" *ngIf=\"artes_de_pesca &&\r\n                artes_de_pesca.includes('1')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Denominación del arte de pesca tipo Sedal ó de anzuelo</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"denominacion_arte_pesca\"\r\n                        [items]=\"denominacionesAnzuelo\" itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"true\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"denominacion_arte_pesca &&\r\n                denominacion_arte_pesca.id == 98 && artes_de_pesca &&\r\n                artes_de_pesca.includes('1')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otra_denominacion_arte_pesca\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"artes_de_pesca &&\r\n                artes_de_pesca.includes('1')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Tipo de Anzuelo</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"tipo_anzuelo\"\r\n                        [items]=\"tiposAnzuelos\" itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\" *ngIf=\"artes_de_pesca &&\r\n                artes_de_pesca.includes('1')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Tamaño de Anzuelo</ion-label>\r\n                    <ion-input type=\"text\" [(ngModel)]=\"tamano_anzuelo\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\" *ngIf=\"artes_de_pesca &&\r\n                artes_de_pesca.includes('1')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Cantidad de Anzuelos</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"cantidad_anzuelos\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"artes_de_pesca &&\r\n                artes_de_pesca.includes('1')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Longitud de línea madre\r\n                        (Brazas)</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"longitud_linea_madre\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"artes_de_pesca &&\r\n                artes_de_pesca.includes('1')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Material de la Línea Madre</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"material_linea_madre\"\r\n                        [items]=\"materialesLineaMadre\" itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"artes_de_pesca &&\r\n                artes_de_pesca.includes('1')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Material de los Bajantes</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"material_bajantes\"\r\n                        [items]=\"mateterialesBajantes\" itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"material_bajantes && material_bajantes.id\r\n                == 4 && artes_de_pesca && artes_de_pesca.includes('1')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otro_material_bajantes\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"artes_de_pesca &&\r\n                artes_de_pesca.includes('1')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Cantidad total de Líneas</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"cantidad_total_lineas\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"artes_de_pesca &&\r\n                artes_de_pesca.includes('2')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Denominación del arte de pesca\r\n                        tipo Trampas o nasas</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"denominacion_alerta\"\r\n                        [items]=\"denomincacionArtesPesca\" itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"denominacion_alerta &&\r\n                denominacion_alerta.id == 4 && artes_de_pesca &&\r\n                artes_de_pesca.includes('2')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otra_denominacion_del_arte\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"artes_de_pesca &&\r\n                artes_de_pesca.includes('2')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Cantidad de Trampas o Nasas</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"cantidad_trampas_nasas\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"artes_de_pesca &&\r\n                artes_de_pesca.includes('2')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Material principal de la\r\n                        trampa o nasa</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"material_ppal_trampas\"\r\n                        [items]=\"materialPpalTrampa\" itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"material_ppal_trampas &&\r\n                material_ppal_trampas.id == 8 && artes_de_pesca &&\r\n                artes_de_pesca.includes('2')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otro_material_ppal\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"artes_de_pesca &&\r\n                artes_de_pesca.includes('3')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Tipo de artefactos de herir o\r\n                        aferrar</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"tipo_artefactos\"\r\n                        [items]=\"tiposDeArtefacto\" itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"tipo_artefactos && tipo_artefactos.id == 7\r\n                && artes_de_pesca && artes_de_pesca.includes('3')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otro_tipo_artefacto\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"artes_de_pesca &&\r\n                artes_de_pesca.includes('3')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Cantidad de Artefactos</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"cantidad_artefactos\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"artes_de_pesca &&\r\n                artes_de_pesca.includes('3')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Material del artefacto</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"material_artefacto\"\r\n                        [items]=\"materialesArtefacto\" itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"material_artefacto &&\r\n                material_artefacto.id == 4 && artes_de_pesca &&\r\n                artes_de_pesca.includes('3')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otro_material_artefacto\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Uso de Dispositivos\r\n                        Agregadores de Peces - FAD (Fish Aggregating Device)</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"uso_dispositivos\"\r\n                        [items]=\"booleans\" itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Tipo de FAD utilizados</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"tipo_fad_usados\"\r\n                        [items]=\"tiposFads\" itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"tipo_fad_usados && tipo_fad_usados.id ==\r\n                6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otro_tipo_fad_usados\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Cantidad de FAD utilizados</ion-label>\r\n                    <ion-input type=\"number\" [(ngModel)]=\"cantidad_fad_usados\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Componentes FAD</ion-label>\r\n                    <ion-input [(ngModel)]=\"componentes_fad\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col *ngIf=\"actualTab>0\" size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"antTab()\">\r\n                    Volver\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"nextTab()\">\r\n                    Continuar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- six tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==6\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Ayudas a la Navegación\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Cartas de Navegación</ion-label>\r\n                    <!-- <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"cartas_navegacion\"\r\n                        [items]=\"booleans\" itemValueField=\"name\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable> -->\r\n                    <ion-select [(ngModel)]=\"cartas_navegacion\">\r\n                        <ion-select-option value=\"Si\">Si</ion-select-option>\r\n                        <ion-select-option value=\"No\">No</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Compas Magnetico</ion-label>\r\n                    <!-- <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"compas_magnetico\"\r\n                        [items]=\"booleans\" itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable> -->\r\n                    <ion-select [(ngModel)]=\"compas_magnetico\">\r\n                        <ion-select-option value=\"Si\">Si</ion-select-option>\r\n                        <ion-select-option value=\"No\">No</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Gps</ion-label>\r\n                    <!-- <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"gps\" [items]=\"booleans\"\r\n                        itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable> -->\r\n                    <ion-select [(ngModel)]=\"gps\">\r\n                        <ion-select-option value=\"Si\">Si</ion-select-option>\r\n                        <ion-select-option value=\"No\">No</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Loran</ion-label>\r\n                    <!-- <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"loran\" [items]=\"booleans\"\r\n                        itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable> -->\r\n                    <ion-select [(ngModel)]=\"loran\">\r\n                        <ion-select-option value=\"Si\">Si</ion-select-option>\r\n                        <ion-select-option value=\"No\">No</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Radar</ion-label>\r\n                    <!-- <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"radar\" [items]=\"booleans\"\r\n                        itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable> -->\r\n                    <ion-select [(ngModel)]=\"radar\">\r\n                        <ion-select-option value=\"Si\">Si</ion-select-option>\r\n                        <ion-select-option value=\"No\">No</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Ecosonda</ion-label>\r\n                    <!-- <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"ecosonda\" [items]=\"booleans\"\r\n                        itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable> -->\r\n                    <ion-select [(ngModel)]=\"ecosonda\">\r\n                        <ion-select-option value=\"Si\">Si</ion-select-option>\r\n                        <ion-select-option value=\"No\">No</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Radio de Comunicación</ion-label>\r\n                    <!-- <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"radios_comunicacion\"\r\n                        [items]=\"booleans\" itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"false\">\r\n                    </ionic-selectable> -->\r\n                    <ion-select [(ngModel)]=\"radios_comunicacion\">\r\n                        <ion-select-option value=\"Si\">Si</ion-select-option>\r\n                        <ion-select-option value=\"No\">No</ion-select-option>\r\n                    </ion-select>\r\n                    \r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col *ngIf=\"actualTab>0\" size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"antTab()\">\r\n                    Volver\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"nextTab()\">\r\n                    Continuar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- seven tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==7\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Observaciones\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Observaciones</ion-label>\r\n                    <ion-textarea [(ngModel)]=\"observations\"></ion-textarea>\r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Imágenes\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col>\r\n                <img src=\"../../../assets/images/thumb-add-imagen.png\" class=\"imgAdd\" (click)=\"uPloadNewPhoto()\">\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row *ngIf=\"fotos_embarcacion.length>0\" class=\"marginTop\" align=\"center\">\r\n            <ion-col size=\"4\" *ngFor=\"let image of fotos_embarcacion; let\r\n                i=index\">\r\n                <img src=\"{{ image.image }}\" class=\"imgAdd\">\r\n                <ion-icon name=\"close\" class=\"deleteIcon\" (click)=\"deleteImages(i)\"></ion-icon>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col *ngIf=\"actualTab>0\" size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"antTab()\">\r\n                    Volver\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"saveInLocal()\">\r\n                    Finalizar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_industrials_industrials_module_ts.js.map