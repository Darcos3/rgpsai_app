"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_pescador_pescador_module_ts"],{

/***/ 3257:
/*!***********************************************************!*\
  !*** ./src/app/pages/pescador/pescador-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PescadorPageRoutingModule": () => (/* binding */ PescadorPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _pescador_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pescador.page */ 7823);




const routes = [
    {
        path: '',
        component: _pescador_page__WEBPACK_IMPORTED_MODULE_0__.PescadorPage
    }
];
let PescadorPageRoutingModule = class PescadorPageRoutingModule {
};
PescadorPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PescadorPageRoutingModule);



/***/ }),

/***/ 6543:
/*!***************************************************!*\
  !*** ./src/app/pages/pescador/pescador.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PescadorPageModule": () => (/* binding */ PescadorPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _pescador_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pescador-routing.module */ 3257);
/* harmony import */ var _pescador_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pescador.page */ 7823);
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/components.module */ 5642);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ionic-selectable */ 5073);









let PescadorPageModule = class PescadorPageModule {
};
PescadorPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _pescador_routing_module__WEBPACK_IMPORTED_MODULE_0__.PescadorPageRoutingModule,
            _components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
            ionic_selectable__WEBPACK_IMPORTED_MODULE_8__.IonicSelectableModule
        ],
        declarations: [_pescador_page__WEBPACK_IMPORTED_MODULE_1__.PescadorPage]
    })
], PescadorPageModule);



/***/ }),

/***/ 7823:
/*!*************************************************!*\
  !*** ./src/app/pages/pescador/pescador.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PescadorPage": () => (/* binding */ PescadorPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _pescador_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pescador.page.html?ngResource */ 3092);
/* harmony import */ var _pescador_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pescador.page.scss?ngResource */ 3850);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _config_data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../config/data */ 2995);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var src_app_config_events__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/config/events */ 6721);
/* harmony import */ var _capacitor_network__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/network */ 4984);
/* harmony import */ var _capacitor_preferences__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/preferences */ 5191);
/* harmony import */ var _capacitor_camera__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @capacitor/camera */ 4241);
/* harmony import */ var src_app_services_api_rest_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/api-rest.service */ 6363);












let PescadorPage = class PescadorPage {
    constructor(loadingController, alertController, activatedRoute, api, router, events) {
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.activatedRoute = activatedRoute;
        this.api = api;
        this.router = router;
        this.events = events;
        this.dataStorage = [];
        //############################### VARS
        //is new or old register
        this.id = this.activatedRoute.snapshot.paramMap.get('id');
        //tabs
        this.actualTab = this.id == 0 ? 0 : 1;
        this.counter = this.id == 0 ? 0 : 1;
        this.tab0 = 0;
        this.tab1 = 0;
        this.tab2 = 0;
        this.tab3 = 0;
        this.tab4 = 0;
        this.tab5 = 0;
        this.tab6 = 0;
        this.tab7 = 0;
        this.cedula_search = '';
        this.data_boats = [];
        this.emailValidate = true;
        this.buscado = false;
        this.certificacion_id = null;
        this.certificacion_name = null;
        //open gallery and take a photo
        this.uPloadNewPhoto = () => (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_6__.Camera.checkPermissions();
            const image = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_6__.Camera.getPhoto({
                quality: 95,
                allowEditing: false,
                resultType: _capacitor_camera__WEBPACK_IMPORTED_MODULE_6__.CameraResultType.Base64,
                //width: 512,
                //height: 512,
                correctOrientation: true,
                promptLabelPhoto: 'Biblioteca de imágenes',
                promptLabelPicture: 'Tomar una foto',
                promptLabelHeader: 'Embarcación Imágenes',
                promptLabelCancel: 'Cancelar'
            });
            var imageUrl = image.base64String;
            this.photo = 'data:image/jpeg;base64,' + imageUrl;
        });
    }
    ngOnInit() {
        this.validateSession();
        this.lugares = _config_data__WEBPACK_IMPORTED_MODULE_2__.LocationsMunicipios;
        // console.log(this.lugares)
        this.certificaciones = _config_data__WEBPACK_IMPORTED_MODULE_2__.CertificacionExpedida;
        this.paises = _config_data__WEBPACK_IMPORTED_MODULE_2__.Countries;
        this.tipoEmbarcacionArnal = _config_data__WEBPACK_IMPORTED_MODULE_2__.TipoEmbarcacionArtesanal;
        this.tiposPesqueria = _config_data__WEBPACK_IMPORTED_MODULE_2__.TiposPesqueria;
        this.artesPesca = _config_data__WEBPACK_IMPORTED_MODULE_2__.ArtesPescaPescadores;
        this.documentoAcredita = _config_data__WEBPACK_IMPORTED_MODULE_2__.DocumentoAcredita;
        this.genres = _config_data__WEBPACK_IMPORTED_MODULE_2__.Genero;
        this.maritalStates = _config_data__WEBPACK_IMPORTED_MODULE_2__.EstadoCivil;
        this.educationLevels = _config_data__WEBPACK_IMPORTED_MODULE_2__.NivelEducativo;
        this.servicesHealt = _config_data__WEBPACK_IMPORTED_MODULE_2__.ServicioSalud;
        this.timePesca = _config_data__WEBPACK_IMPORTED_MODULE_2__.TiempoPesca;
        this.dedicationDrop = _config_data__WEBPACK_IMPORTED_MODULE_2__.Dedicacion;
        this.horarioPesca = _config_data__WEBPACK_IMPORTED_MODULE_2__.HorarioPesca;
        if (this.id != 0) {
            this.loadData();
        }
    }
    validateSession() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            let dataSession = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_5__.Preferences.get({ key: 'sessionPersistence' });
            let session = JSON.parse(dataSession.value);
            if (session) {
                if (session.userID) {
                    this.userID = session.userID;
                }
                if (session.userToken) {
                    this.userToken = session.userToken;
                }
            }
            else {
                this.router.navigate(['login']);
            }
            let dataRegisters = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_5__.Preferences.get({ key: 'dataRegistersPescadores' });
            let sessionRegisters = JSON.parse(dataRegisters.value);
            if (this.id == 0 && sessionRegisters && sessionRegisters.length >= 10) {
                this.presentMessage('Advertencia', 'No podrás registrar más inspecciones a menos que subas una de las que tienes en el listado, solo se permite tenér un máximo de 10 registros por listado.', true);
            }
            this.dataStorage = sessionRegisters ? sessionRegisters : [];
            //dropdowns
            let ddC = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_5__.Preferences.get({ key: 'sessionSelectOrganizations' });
            let sC = JSON.parse(ddC.value);
            let ddSf = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_5__.Preferences.get({ key: 'sessionSelectLanding' });
            let sSf = JSON.parse(ddSf.value);
            let ddP = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_5__.Preferences.get({ key: 'sessionSelectPorts' });
            let sP = JSON.parse(ddP.value);
            this.empresas = sC.data;
            this.dembarquePorts = sSf.data;
            this.portsRegister = sP.data;
            //add declaración juramentada
            this.empresas.push({
                id: null,
                name: 'Declaración Juramentada'
            });
            console.log("empresas ", this.empresas);
        });
    }
    antTab() {
        this.counter--;
        if (this.counter == 0) {
            this.actualTab = 0;
            this.tab0 = 0;
            this.tab1 = 0;
            this.tab2 = 0;
            this.tab3 = 0;
            this.tab4 = 0;
            this.tab5 = 0;
            this.tab6 = 0;
            this.tab7 = 0;
        }
        else if (this.counter == 1) {
            this.actualTab = 1;
            this.tab0 = 1;
            this.tab1 = 0;
            this.tab2 = 0;
            this.tab3 = 0;
            this.tab4 = 0;
            this.tab5 = 0;
            this.tab6 = 0;
            this.tab7 = 0;
        }
        else if (this.counter == 2) {
            this.actualTab = 2;
            this.tab0 = 1;
            this.tab1 = 1;
            this.tab2 = 0;
            this.tab3 = 0;
            this.tab4 = 0;
            this.tab5 = 0;
            this.tab6 = 0;
            this.tab7 = 0;
        }
        else if (this.counter == 3) {
            this.actualTab = 3;
            this.tab0 = 1;
            this.tab1 = 1;
            this.tab2 = 1;
            this.tab3 = 0;
            this.tab4 = 0;
            this.tab5 = 0;
            this.tab6 = 0;
            this.tab7 = 0;
        }
        else if (this.counter == 4) {
            this.actualTab = 4;
            this.tab0 = 1;
            this.tab1 = 1;
            this.tab2 = 1;
            this.tab3 = 1;
            this.tab4 = 0;
            this.tab5 = 0;
            this.tab6 = 0;
            this.tab7 = 0;
        }
        else if (this.counter == 5) {
            this.actualTab = 5;
            this.tab0 = 1;
            this.tab1 = 1;
            this.tab2 = 1;
            this.tab3 = 1;
            this.tab4 = 1;
            this.tab5 = 0;
            this.tab6 = 0;
            this.tab7 = 0;
        }
        else if (this.counter == 6) {
            this.actualTab = 6;
            this.tab0 = 1;
            this.tab1 = 1;
            this.tab2 = 1;
            this.tab3 = 1;
            this.tab4 = 1;
            this.tab5 = 1;
            this.tab6 = 0;
            this.tab7 = 0;
        }
        else if (this.counter == 7) {
            this.actualTab = 7;
            this.tab0 = 1;
            this.tab1 = 1;
            this.tab2 = 1;
            this.tab3 = 1;
            this.tab4 = 1;
            this.tab5 = 1;
            this.tab6 = 1;
            this.tab7 = 0;
        }
        console.log('Data...', this.actualTab);
    }
    nextTab() {
        if (this.counter == 0) {
            this.actualTab = 1;
            this.tab0 = 1;
        }
        else if (this.counter == 1) {
            this.actualTab = 2;
            this.tab1 = 1;
        }
        else if (this.counter == 2) {
            this.actualTab = 3;
            this.tab2 = 1;
        }
        else if (this.counter == 3) {
            this.actualTab = 4;
            this.tab3 = 1;
        }
        else if (this.counter == 4) {
            this.actualTab = 5;
            this.tab4 = 1;
        }
        else if (this.counter == 5) {
            this.actualTab = 6;
            this.tab5 = 1;
        }
        else if (this.counter == 6) {
            this.actualTab = 7;
            this.tab6 = 1;
        }
        else if (this.counter == 7) {
            this.actualTab = 8;
            this.tab7 = 1;
        }
        this.counter++;
    }
    //validate fields
    numberValidator(event) {
        //console.log(event.target.value);
        const pattern = /^[0-9 -]*$/;
        //let inputChar = String.fromCharCode(event.charCode)
        if (!pattern.test(event.target.value)) {
            event.target.value = event.target.value.replace(/[^0-9 -]/g, "");
            // invalid character, prevent input
        }
    }
    //validate email
    validarEmail(event) {
        let email = event.detail.value;
        if (/^\w+([.-_+]?\w+)*@\w+([.-]?\w+)*(\.\w{2,10})+$/.test(email)) {
            this.emailValidate = true;
            return true;
        }
        else {
            if (email == '') {
                this.emailValidate = true;
            }
            else {
                this.emailValidate = false;
            }
            return false;
        }
    }
    //search validate
    validateSearch() {
        if (this.cedula_search.length < 4) {
            this.presentMessage('Advertencia', 'Debe envíar un número de cédula valido');
            return;
        }
        const logCurrentNetworkStatus = () => (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const status = yield _capacitor_network__WEBPACK_IMPORTED_MODULE_4__.Network.getStatus();
            //console.log(status);
            if (status.connected === true) {
                this.searchPescador();
            }
            else {
                this.searchPesca = true;
                this.presentMessage('Advertencia', 'No es posible realizar la búsqueda, conéctese a internet o realice un nuevo registro');
            }
        });
        logCurrentNetworkStatus();
    }
    setVal() {
        console.log(this.department);
    }
    //search pescador
    searchPescador() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            this.searchPesca = true;
            const loading = yield this.loadingController.create({
                message: 'Cargando...',
                spinner: 'crescent',
                showBackdrop: true,
            });
            yield loading.present();
            this.api.searchPescador("Bearer " + this.userToken, this.cedula_search).subscribe(response => {
                loading.dismiss();
                if (response[0] && response[0].data && response[0].data.data && response[0].data.data[0]) {
                    let tfArray = [];
                    if (response[0].data.data[0].type_fishery && response[0].data.data[0].type_fishery.length > 0) {
                        response[0].data.data[0].type_fishery.map(data => {
                            tfArray.push(`${data.id}`);
                        });
                    }
                    let apArray = []; //artes de pesca
                    if (response[0].data.data[0].fishing_arts && response[0].data.data[0].fishing_arts.length > 0) {
                        response[0].data.data[0].fishing_arts.map(data => {
                            apArray.push(`${data.id}`);
                        });
                    }
                    let boatsArray = []; //boats
                    if (response[0].data.data[0].boats && response[0].data.data[0].boats.length > 0) {
                        response[0].data.data[0].boats.map(data => {
                            boatsArray.push({
                                id: data.id,
                                nombre: data.nombre,
                                registration_number: data.registration_number,
                            });
                        });
                    }
                    this.department = this.lugares.find(({ codigo }) => codigo === response[0].data.data[0].department);
                    this.filed = response[0].data.data[0].filed;
                    this.filing_date = response[0].data.data[0].filing_date;
                    //tab 2
                    this.copy_identification_document = response[0].data.data[0].copy_identification_document;
                    this.copy_occre = response[0].data.data[0].copy_occre;
                    this.copy_sisben = response[0].data.data[0].copy_sisben;
                    this.accreditation_certificate = response[0].data.data[0].accreditation_certificate;
                    this.certification_issued_by = this.empresas.find(({ id }) => id == response[0].data.data[0].certification_issued_by);
                    this.vigencia_permiso = response[0].data.data[0].vigencia_permiso;
                    this.expedition_date = response[0].data.data[0].expedition_date;
                    this.expiration_date = response[0].data.data[0].expiration_date;
                    //tab 3
                    this.photo = response[0].data.data[0].fisherman_photo_file;
                    this.name = response[0].data.data[0].name;
                    this.lastname = response[0].data.data[0].lastname;
                    this.type_of_card = response[0].data.data[0].type_of_card;
                    this.identification_number = response[0].data.data[0].identification_number;
                    this.occre = response[0].data.data[0].occre;
                    this.no_occre = response[0].data.data[0].no_occre;
                    this.nationality = this.paises.find(({ codigo }) => codigo == response[0].data.data[0].nationality);
                    this.email = response[0].data.data[0].email;
                    this.address = response[0].data.data[0].address;
                    this.phone = response[0].data.data[0].phone;
                    this.organization_cooperative = response[0].data.data[0].organization_cooperative;
                    this.organization_name = this.empresas.find(({ id }) => id == response[0].data.data[0].organization_name);
                    //tab 4
                    this.dembarque_port = this.dembarquePorts.find(({ codigo }) => codigo == response[0].data.data[0].landing_zone);
                    this.zona_frecuente_pesca = response[0].data.data[0].frequent_fishing_area;
                    this.tipo_embarcacion_artesanal = response[0].data.data[0].type_of_artesanal_boat;
                    this.otro_tipo_embarcacion_artesanal = response[0].data.data[0].type_of_artesanal_boat_state;
                    this.tipo_pesqueria = tfArray;
                    this.artes_pesca = apArray;
                    //tab 5
                    this.reporta_embarcacion = response[0].data.data[0].report_boat;
                    this.propietario_embarcacion = response[0].data.data[0].owns_boat;
                    this.documento_acredita = null; //response[0].data.data[0].documento_acredita;
                    this.data_boats = boatsArray;
                    //tab 6
                    this.birthdate = response[0].data.data[0].birth_date;
                    this.age = response[0].data.data[0].age;
                    this.genre = response[0].data.data[0].gender;
                    this.marital_state = response[0].data.data[0].marital_status;
                    this.otro_marital_state = response[0].data.data[0].material_status_state;
                    this.read_write = response[0].data.data[0].read_and_write;
                    this.education_level = response[0].data.data[0].education_level;
                    this.otro_education_level = response[0].data.data[0].otro_education_level;
                    this.own_home = response[0].data.data[0].own_house;
                    this.healt_service = response[0].data.data[0].type_health_service;
                    this.otro_healt_service = response[0].data.data[0].type_health_service_state;
                    this.pesca_time = response[0].data.data[0].fishing_time;
                    this.otro_pesca_time = response[0].data.data[0].fishing_time_state;
                    this.dedication = response[0].data.data[0].tiempo_en_actividad.codigo;
                    this.hour_pesca = response[0].data.data[0].fishing_schedule;
                    //tab 7
                    // this.observations = response[0].data.data[0].observations;     
                    this.observations = '';
                    this.presentMessage('Resultado exitoso', 'REGISTRO ENCONTRADO');
                }
                else {
                    this.presentMessage('Advertencia', 'REGISTRO NO ENCONTRADO');
                }
            }, err => {
                loading.dismiss();
                this.presentMessage('Advertencia', 'No podemos establecer conexión con el servidor, por favor cierre y vuelva a iniciar sesión e intente de nuevo');
            });
        });
    }
    //alert with warning
    presentMessage(title, message, redirect = false) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: title,
                message: message,
                backdropDismiss: false,
                buttons: [
                    {
                        text: 'OK',
                        handler: () => redirect ? this.router.navigate(['registers']) : null
                    }
                ]
            });
            yield alert.present();
        });
    }
    //select value radio
    selectedRadio(type, event) {
        if (type == 1) {
            this.copy_identification_document = event.detail.value;
        }
        else if (type == 2) {
            this.copy_occre = event.detail.value;
        }
        else if (type == 3) {
            this.copy_sisben = event.detail.value;
        }
        else if (type == 4) {
            this.accreditation_certificate = event.detail.value;
        }
        else if (type == 5) {
            this.occre = event.detail.value;
        }
        else if (type == 6) {
            this.organization_cooperative = event.detail.value;
            this.assignedOrganizationValue(event.detail.value);
        }
        else if (type == 7) {
            this.reporta_embarcacion = event.detail.value;
        }
        else if (type == 8) {
            this.propietario_embarcacion = event.detail.value;
        }
        else if (type == 9) {
            this.read_write = event.detail.value;
        }
        else if (type == 10) {
            this.own_home = event.detail.value;
        }
    }
    //update expiration date
    updateExpiration(type) {
        if (type == 1) {
            if (this.vigencia_permiso && this.expedition_date) {
                this.addDays(1, Number(this.vigencia_permiso));
            }
        }
    }
    //add days to date
    addDays(type, n) {
        if (type == 1) {
            let dat = new Date(this.expedition_date);
            let startDate = new Date(dat);
            let requiredDate = new Date(startDate.getFullYear() + n, startDate.getMonth(), startDate.getDate());
            this.expiration_date = requiredDate.toISOString().substring(0, 10);
        }
    }
    // on change cert by
    filterEmpresas(text) {
        return this.empresas.filter(empresa => {
            return empresa.name.toLowerCase().indexOf(text) !== -1;
        });
    }
    onChangeCert(event) {
        let text = event.text.trim().toLowerCase();
        if (this.empresaSubscription) {
            this.empresaSubscription.unsubscribe();
        }
        if (!text) {
            // Close any running subscription.
            if (this.empresaSubscription) {
                this.empresaSubscription.unsubscribe();
            }
            event.component.items = [];
            event.component.endSearch();
            return;
        }
        event.component.items = this.filterEmpresas(text);
        event.component.endSearch();
        // if(event.value.id == null){
        //     this.organization_cooperative = 'NO';
        //     if(this.department && this.department.codigo=='UNO'){
        //         this.organization_name = {"id":"1031","name":"INDEPENDIENTE SAI"};
        //     }else if(this.department && this.department.codigo=='DOS'){
        //         this.organization_name = {"id":"1032","name":"INDEPENDIENTE PROV"};
        //     }
        // }
    }
    assignedOrganizationValue(selection) {
        if (selection == 'NO') {
            if (this.department && this.department.codigo == 'UNO') {
                this.organization_name = { "id": "1031", "name": "INDEPENDIENTE SAI" };
            }
            else if (this.department && this.department.codigo == 'DOS') {
                this.organization_name = { "id": "1032", "name": "INDEPENDIENTE PROV" };
            }
        }
    }
    //search vessel
    searchVessel() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Cargando...',
                spinner: 'crescent',
                showBackdrop: true,
            });
            yield loading.present();
            this.api.searchVessel("Bearer " + this.userToken, this.search_vessel_field + "/art").subscribe(response => {
                loading.dismiss();
                if (response[0] && response[0].data && response[0].data[0]) {
                    // var result = this.data_boats.find(item => item.registration_number === this.search_vessel_field);
                    var result = this.data_boats.find(item => item.registration_number === this.search_vessel_field);
                    if (!result) {
                        // boat_request_id: response[0].data[0].id,
                        // propietario: this.propietario_embarcacion,
                        // tipo_certificado: this.documento_acredita.description,
                        this.data_boats.push({
                            boat_request_id: response[0].data[0].numero_matricula,
                            propietario: response[0].data[0].nombre_propietario,
                            tipo_certificado: response[0].data[0].tipo_identificacion,
                            nombre: response[0].data[0].nombre_barco
                        });
                        this.search_vessel_field = '';
                    }
                    console.log('response[0].data[0] ', response[0].data[0]);
                    // console.log('result =>', result);
                    // console.log('data_boats =>', this.data_boats);
                }
                else {
                    this.presentMessage('Advertencia', 'REGISTRO NO ENCONTRADO');
                }
            }, err => {
                loading.dismiss();
                this.presentMessage('Advertencia', 'No podemos establecer conexión con el servidor, por favor cierre y vuelva a iniciar sesión e intente de nuevo');
            });
        });
    }
    deleteVesselAsociate(vessel) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            let items = this.data_boats.filter((item) => {
                return item.registration_number === vessel;
            });
            items.forEach((element) => {
                var index = this.data_boats.indexOf(element);
                this.data_boats.splice(index, 1);
            });
        });
    }
    calculateAge() {
        var birthDate = this.birthdate;
        let currentTime = new Date().getTime();
        let birthDateTime = new Date(birthDate).getTime();
        let difference = (currentTime - birthDateTime);
        var ageInYears = Number(difference / (1000 * 60 * 60 * 24 * 365));
        this.age = Math.round(ageInYears);
    }
    //storage in local
    saveInLocal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            if (this.id == 0) {
                let object = Object();
                object.id = Math.random().toString(36).substr(2, 9);
                object.update_date = new Date().toLocaleDateString();
                object.status = 1;
                //tab 0
                object.searchPesca = this.searchPesca;
                object.cedula_search = this.cedula_search;
                //tab 1
                object.department = this.department;
                object.filed = this.filed;
                object.filing_date = this.filing_date;
                //tab 2
                object.copy_identification_document = this.copy_identification_document;
                object.copy_occre = this.copy_occre;
                object.copy_sisben = this.copy_sisben;
                object.accreditation_certificate = this.accreditation_certificate;
                object.certification_issued_by = this.certification_issued_by;
                object.vigencia_permiso = this.vigencia_permiso;
                object.expedition_date = this.expedition_date;
                object.expiration_date = this.expiration_date;
                //tab 3
                object.photo = this.photo;
                object.name = this.name;
                object.lastname = this.lastname;
                object.type_of_card = this.type_of_card;
                object.identification_number = this.identification_number;
                object.occre = this.occre;
                object.no_occre = this.no_occre;
                object.nationality = this.nationality;
                object.email = this.email;
                object.address = this.address;
                object.phone = this.phone;
                object.organization_cooperative = this.organization_cooperative;
                object.organization_name = this.organization_name;
                //tab 4
                object.dembarque_port = this.dembarque_port;
                object.zona_frecuente_pesca = this.zona_frecuente_pesca;
                object.tipo_embarcacion_artesanal = this.tipo_embarcacion_artesanal;
                object.otro_tipo_embarcacion_artesanal = this.otro_tipo_embarcacion_artesanal;
                object.tipo_pesqueria = this.tipo_pesqueria;
                object.artes_pesca = this.artes_pesca;
                //tab 5
                object.reporta_embarcacion = this.reporta_embarcacion;
                object.propietario_embarcacion = this.propietario_embarcacion;
                object.documento_acredita = this.documento_acredita;
                object.data_boats = this.data_boats;
                object.search_vessel_field = this.search_vessel_field;
                //tab 6
                object.birthdate = this.birthdate;
                object.age = this.age;
                object.genre = this.genre;
                object.marital_state = this.marital_state;
                object.otro_marital_state = this.otro_marital_state;
                object.read_write = this.read_write;
                object.education_level = this.education_level;
                object.otro_education_level = this.otro_education_level;
                object.own_home = this.own_home;
                object.healt_service = this.healt_service;
                object.otro_healt_service = this.otro_healt_service;
                object.pesca_time = this.pesca_time;
                object.otro_pesca_time = this.otro_pesca_time;
                object.dedication = this.dedication;
                object.hour_pesca = this.hour_pesca;
                //tab 7
                object.observations = this.observations;
                this.dataStorage.push(object);
            }
            else {
                let items = this.dataStorage.filter((item) => {
                    return item.id === this.id;
                });
                items.forEach((data) => {
                    data.update_date = new Date().toLocaleDateString();
                    data.status = 1;
                    //tab 0
                    data.searchPesca = this.searchPesca;
                    data.cedula_search = this.cedula_search;
                    //tab 1
                    data.department = this.department;
                    data.filed = this.filed;
                    data.filing_date = this.filing_date;
                    //tab 2
                    data.copy_identification_document = this.copy_identification_document;
                    data.copy_occre = this.copy_occre;
                    data.copy_sisben = this.copy_sisben;
                    data.accreditation_certificate = this.accreditation_certificate;
                    data.certification_issued_by = this.certification_issued_by;
                    data.vigencia_permiso = this.vigencia_permiso;
                    data.expedition_date = this.expedition_date;
                    data.expiration_date = this.expiration_date;
                    //tab 3
                    data.photo = this.photo;
                    data.name = this.name;
                    data.lastname = this.lastname;
                    data.type_of_card = this.type_of_card;
                    data.identification_number = this.identification_number;
                    data.occre = this.occre;
                    data.no_occre = this.no_occre;
                    data.nationality = this.nationality;
                    data.email = this.email;
                    data.address = this.address;
                    data.phone = this.phone;
                    data.organization_cooperative = this.organization_cooperative;
                    data.organization_name = this.organization_name;
                    //tab 4
                    data.dembarque_port = this.dembarque_port;
                    data.zona_frecuente_pesca = this.zona_frecuente_pesca;
                    data.tipo_embarcacion_artesanal = this.tipo_embarcacion_artesanal;
                    data.otro_tipo_embarcacion_artesanal = this.otro_tipo_embarcacion_artesanal;
                    data.tipo_pesqueria = this.tipo_pesqueria;
                    data.artes_pesca = this.artes_pesca;
                    //tab 5
                    data.reporta_embarcacion = this.reporta_embarcacion;
                    data.propietario_embarcacion = this.propietario_embarcacion;
                    data.documento_acredita = this.documento_acredita;
                    data.this_boats = this.data_boats;
                    data.search_vessel_field = this.search_vessel_field;
                    //tab 6
                    data.birthdate = this.birthdate;
                    data.age = this.age;
                    data.genre = this.genre;
                    data.marital_state = this.marital_state;
                    data.otro_marital_state = this.otro_marital_state;
                    data.read_write = this.read_write;
                    data.education_level = this.education_level;
                    data.otro_education_level = this.otro_education_level;
                    data.own_home = this.own_home;
                    data.healt_service = this.healt_service;
                    data.otro_healt_service = this.otro_healt_service;
                    data.pesca_time = this.pesca_time;
                    data.otro_pesca_time = this.otro_pesca_time;
                    data.dedication = this.dedication;
                    data.hour_pesca = this.hour_pesca;
                    //tab 7
                    data.observations = this.observations;
                });
            }
            yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_5__.Preferences.set({
                key: 'dataRegistersPescadores',
                value: JSON.stringify(this.dataStorage),
            }).then(() => {
                this.AlertStore();
            });
        });
    }
    //uplad register server
    AlertStore() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Confirmación',
                message: 'Datos almacenados exitosamente',
                buttons: [
                    {
                        text: 'Aceptar',
                        handler: () => {
                            this.actualTab = this.id == 0 ? 0 : 1;
                            this.counter = this.id == 0 ? 0 : 1;
                            this.searchPesca = false;
                            this.cedula_search = null;
                            this.events.publish('updateRegisters', []);
                            this.router.navigate(["registers"]);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    //load data persistence
    loadData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            let dataRegister = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_5__.Preferences.get({ key: 'dataRegistersPescadores' });
            let response = JSON.parse(dataRegister.value);
            this.dataStorage = response;
            let items = this.dataStorage.filter((item) => {
                return item.id === this.id;
            });
            //console.log('Registro: ', items)
            items.forEach((data) => {
                //tab 0
                this.searchPesca = data.searchPesca;
                this.cedula_search = data.cedula_search;
                //tab 1
                this.department = data.department;
                this.filed = data.filed;
                this.filing_date = data.filing_date;
                //tab 2
                this.copy_identification_document = data.copy_identification_document;
                this.copy_occre = data.copy_occre;
                this.copy_sisben = data.copy_sisben;
                this.accreditation_certificate = data.accreditation_certificate;
                this.certification_issued_by = data.certification_issued_by;
                this.vigencia_permiso = data.vigencia_permiso;
                this.expedition_date = data.expedition_date;
                this.expiration_date = data.expiration_date;
                //tab 3
                this.photo = data.photo;
                this.name = data.name;
                this.lastname = data.lastname;
                this.type_of_card = data.type_of_card;
                this.identification_number = data.identification_number;
                this.occre = data.occre;
                this.no_occre = data.no_occre;
                this.nationality = data.nationality;
                this.email = data.email;
                this.address = data.address;
                this.phone = data.phone;
                this.organization_cooperative = data.organization_cooperative;
                this.organization_name = data.organization_name;
                //tab 4
                this.dembarque_port = data.dembarque_port;
                this.zona_frecuente_pesca = data.zona_frecuente_pesca;
                this.tipo_embarcacion_artesanal = data.tipo_embarcacion_artesanal;
                this.otro_tipo_embarcacion_artesanal = data.otro_tipo_embarcacion_artesanal;
                this.tipo_pesqueria = data.tipo_pesqueria;
                this.artes_pesca = data.artes_pesca;
                //tab 5
                this.reporta_embarcacion = data.reporta_embarcacion;
                this.propietario_embarcacion = data.propietario_embarcacion;
                this.documento_acredita = data.documento_acredita;
                this.data_boats = data.data_boats;
                this.search_vessel_field = data.search_vessel_field;
                //tab 6
                this.birthdate = data.birthdate;
                this.age = data.age;
                this.genre = data.genre;
                this.marital_state = data.marital_state;
                this.otro_marital_state = data.otro_marital_state;
                this.read_write = data.read_write;
                this.education_level = data.education_level;
                this.otro_education_level = data.otro_education_level;
                this.own_home = data.own_home;
                this.healt_service = data.healt_service;
                this.otro_healt_service = data.otro_healt_service;
                this.pesca_time = data.pesca_time;
                this.otro_pesca_time = data.otro_pesca_time;
                this.dedication = data.dedication;
                this.hour_pesca = data.hour_pesca;
                //tab 7
                this.observations = data.observations;
            });
        });
    }
};
PescadorPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute },
    { type: src_app_services_api_rest_service__WEBPACK_IMPORTED_MODULE_7__.ApiRestService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router },
    { type: src_app_config_events__WEBPACK_IMPORTED_MODULE_3__.Events }
];
PescadorPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-pescador',
        template: _pescador_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_pescador_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PescadorPage);



/***/ }),

/***/ 3850:
/*!**************************************************************!*\
  !*** ./src/app/pages/pescador/pescador.page.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --background: #fafafa;\n}\nion-content ion-grid.headerGrid {\n  background: #fafafa;\n  position: fixed;\n  width: 100%;\n  z-index: 99999;\n}\nion-content ion-grid.headerGrid ion-row {\n  padding: 30px;\n  text-align: center;\n}\nion-content ion-grid.headerGrid ion-row ion-col ion-icon {\n  color: #bad320;\n}\nion-content ion-grid.headerGrid ion-row ion-col ion-icon.active {\n  border-radius: 50%;\n  background: #bad320;\n  color: #fff;\n}\nion-content ion-grid.headerGrid ion-row ion-col ion-icon.inactive {\n  color: #bad320;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid.headerGrid ion-row ion-col ion-icon {\n    font-size: 20px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid.headerGrid ion-row ion-col ion-icon {\n    font-size: 25px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid.headerGrid ion-row ion-col ion-icon {\n    font-size: 35px;\n  }\n}\n@media (min-width: 319px) {\n  ion-content ion-grid.marginInitial {\n    margin-top: 70px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid.marginInitial {\n    margin-top: 80px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid.marginInitial {\n    margin-top: 90px;\n  }\n}\nion-content ion-grid.marginInitial ion-row ion-col.radios {\n  margin: 10px 0;\n  padding: 0 25px;\n}\nion-content ion-grid.marginInitial ion-row ion-col.radios ion-text p {\n  font-size: 17px;\n  margin: 15px 0;\n}\nion-content ion-grid.marginInitial ion-row ion-col.radios ion-list, ion-content ion-grid.marginInitial ion-row ion-col.radios ion-radio-group {\n  margin-top: 10px;\n}\nion-content ion-grid.marginInitial ion-row ion-col.radios ion-list ion-item ion-icon, ion-content ion-grid.marginInitial ion-row ion-col.radios ion-radio-group ion-item ion-icon {\n  font-size: 20px;\n  margin-right: 10px;\n}\nion-content ion-grid.marginInitial ion-row ion-col.radios ion-list ion-item ion-label, ion-content ion-grid.marginInitial ion-row ion-col.radios ion-radio-group ion-item ion-label {\n  font-size: 16px;\n  color: #4B555D;\n  font-weight: 400;\n  margin: 0;\n}\nion-content ion-grid.marginInitial ion-row ion-col h2 {\n  font-family: \"Poppins\", sans-serif;\n  color: #2f6da8;\n  margin-bottom: 30px;\n  text-align: center;\n}\nion-content ion-grid.marginInitial ion-row ion-col ion-item {\n  --background: transparent;\n}\nion-content ion-grid.marginInitial ion-row ion-col ion-item ion-label {\n  color: #000015;\n  font-family: \"Poppins\", sans-serif;\n}\nion-content ion-grid.marginInitial ion-row ion-col ion-item ion-input {\n  margin: 5px 0 0;\n  border: 1px solid #f2F2F2;\n  --background: #fff;\n  --padding-start: 15px;\n  font-family: \"Poppins\", sans-serif;\n  --placeholder-color: #bdbdbd;\n}\nion-content ion-grid.marginInitial ion-row ion-col ion-item ion-datetime {\n  background: #fff;\n  margin: 5px 0 0;\n  border: 1px solid #f2F2F2;\n  --padding-start: 15px;\n  font-family: \"Poppins\", sans-serif;\n}\nion-content ion-grid.marginInitial ion-row ion-col ion-item ion-select {\n  background: #fff;\n  margin: 5px 0 0;\n  border: 1px solid #f2F2F2;\n  --padding-start: 15px;\n  font-family: \"Poppins\", sans-serif;\n}\nion-content ion-grid.marginInitial ion-row ion-col ion-item ion-textarea {\n  background: #fff;\n  margin: 5px 0 0;\n  border: 1px solid #e6e6e6;\n  --padding-start: 15px;\n  font-family: \"Poppins\", sans-serif;\n}\nion-content ion-grid.marginInitial ion-row ion-col ion-item ionic-selectable {\n  background: #fff;\n  margin: 5px 0 0;\n  border: 1px solid #f2F2F2;\n  padding-left: 15px;\n  font-family: \"Poppins\", sans-serif;\n}\nion-content ion-grid.marginInitial ion-row img.imgAdd {\n  max-width: 100%;\n  max-height: 100px;\n}\nion-content ion-grid.marginInitial ion-row img.imgEnd {\n  margin-top: 30px;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid.marginInitial ion-row img.imgEnd {\n    max-width: 140px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid.marginInitial ion-row img.imgEnd {\n    max-width: 180px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid.marginInitial ion-row img.imgEnd {\n    max-width: 180px;\n  }\n}\nion-content ion-grid.marginInitial ion-row ion-icon {\n  position: absolute;\n  top: 0;\n  right: 5px;\n  border-radius: 50%;\n  background-color: red;\n  padding: 5px;\n}\nion-content ion-grid.marginInitial ion-row ion-icon.noStyles {\n  position: relative;\n  background-color: transparent;\n  border-radius: 0;\n  right: 0;\n  padding: 0;\n}\nion-content ion-grid.marginInitial ion-row ion-button {\n  margin: 30px 0 0;\n  font-family: \"Poppins\", sans-serif;\n  --background: #2f6da8;\n  /* Old browsers */\n  --background: -moz-linear-gradient(left, #2f6da8 0%, #3192c8 76%, #73ad7d 100%);\n  /* FF3.6-15 */\n  --background: -webkit-linear-gradient(left, #2f6da8 0%, #3192c8 76%, #73ad7d 100%);\n  /* Chrome10-25,Safari5.1-6 */\n  --background: linear-gradient(to right, #2f6da8 0%, #3192c8 76%, #73ad7d 100%);\n  /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  --background-activated: #006fa6;\n  --background-focused: #006fa6;\n  --background-hover: #006fa6;\n  --color: #ffffff;\n  --border-radius: 50px;\n  --padding-start: 30px;\n  --padding-end: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBlc2NhZG9yLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHFCQUFBO0FBQ0o7QUFFUTtFQUNJLG1CQUFBO0VBRUEsZUFBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0FBRFo7QUFHWTtFQUNJLGFBQUE7RUFDQSxrQkFBQTtBQURoQjtBQUlvQjtFQVdJLGNBQUE7QUFaeEI7QUFFd0I7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtBQUE1QjtBQUd3QjtFQUNJLGNBQUE7QUFENUI7QUFNd0I7RUFiSjtJQWNRLGVBQUE7RUFIMUI7QUFDRjtBQUt3QjtFQWpCSjtJQWtCUSxlQUFBO0VBRjFCO0FBQ0Y7QUFJd0I7RUFyQko7SUFzQlEsZUFBQTtFQUQxQjtBQUNGO0FBUVk7RUFESjtJQUVRLGdCQUFBO0VBTGQ7QUFDRjtBQU9ZO0VBTEo7SUFNUSxnQkFBQTtFQUpkO0FBQ0Y7QUFNWTtFQVRKO0lBVVEsZ0JBQUE7RUFIZDtBQUNGO0FBT29CO0VBQ0ksY0FBQTtFQUNBLGVBQUE7QUFMeEI7QUFPNEI7RUFDSSxlQUFBO0VBQ0EsY0FBQTtBQUxoQztBQVF3QjtFQUNJLGdCQUFBO0FBTjVCO0FBUWdDO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0FBTnBDO0FBUWdDO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLFNBQUE7QUFOcEM7QUFXb0I7RUFDSSxrQ0FBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBVHhCO0FBWW9CO0VBQ0kseUJBQUE7QUFWeEI7QUFZd0I7RUFDSSxjQUFBO0VBQ0Esa0NBQUE7QUFWNUI7QUFhd0I7RUFDSSxlQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0NBQUE7RUFDQSw0QkFBQTtBQVg1QjtBQWN3QjtFQUNJLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLHlCQUFBO0VBQ0EscUJBQUE7RUFDQSxrQ0FBQTtBQVo1QjtBQWV3QjtFQUNJLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLHlCQUFBO0VBQ0EscUJBQUE7RUFDQSxrQ0FBQTtBQWI1QjtBQWdCd0I7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0NBQUE7QUFkNUI7QUFpQndCO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLGtDQUFBO0FBZjVCO0FBcUJvQjtFQUNJLGVBQUE7RUFDQSxpQkFBQTtBQW5CeEI7QUFzQm9CO0VBQ0ksZ0JBQUE7QUFwQnhCO0FBc0J3QjtFQUhKO0lBSVEsZ0JBQUE7RUFuQjFCO0FBQ0Y7QUFxQndCO0VBUEo7SUFRUSxnQkFBQTtFQWxCMUI7QUFDRjtBQW9Cd0I7RUFYSjtJQVlRLGdCQUFBO0VBakIxQjtBQUNGO0FBcUJnQjtFQUNJLGtCQUFBO0VBQ0EsTUFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtBQW5CcEI7QUFvQm9CO0VBQ0ksa0JBQUE7RUFDQSw2QkFBQTtFQUNBLGdCQUFBO0VBQ0EsUUFBQTtFQUNBLFVBQUE7QUFsQnhCO0FBc0JnQjtFQUNJLGdCQUFBO0VBQ0Esa0NBQUE7RUFDQSxxQkFBQTtFQUNBLGlCQUFBO0VBQ0EsK0VBQUE7RUFDQSxhQUFBO0VBQ0Esa0ZBQUE7RUFDQSw0QkFBQTtFQUNBLDhFQUFBO0VBQ0EscURBQUE7RUFDQSwrQkFBQTtFQUNBLDZCQUFBO0VBQ0EsMkJBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtBQXBCcEIiLCJmaWxlIjoicGVzY2Fkb3IucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjZmFmYWZhO1xyXG5cclxuICAgIGlvbi1ncmlkIHtcclxuICAgICAgICAmLmhlYWRlckdyaWQge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZmFmYWZhO1xyXG4gICAgICAgICAgICA7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICAgIHotaW5kZXg6IDk5OTk5O1xyXG5cclxuICAgICAgICAgICAgaW9uLXJvdyB7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAzMHB4O1xyXG4gICAgICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5cclxuICAgICAgICAgICAgICAgIGlvbi1jb2wge1xyXG4gICAgICAgICAgICAgICAgICAgIGlvbi1pY29uIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgJi5hY3RpdmUge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2JhZDMyMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAmLmluYWN0aXZlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjYmFkMzIwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogI2JhZDMyMDtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAzMTlweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogMzc0cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDQxNXB4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDM1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICYubWFyZ2luSW5pdGlhbCB7XHJcbiAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAzMTlweCkge1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogNzBweDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDM3NHB4KSB7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiA4MHB4O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogNDE1cHgpIHtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDkwcHg7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlvbi1yb3cge1xyXG4gICAgICAgICAgICAgICAgaW9uLWNvbCB7XHJcbiAgICAgICAgICAgICAgICAgICAgJi5yYWRpb3N7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogMTBweCAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAwIDI1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlvbi10ZXh0e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE3cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAxNXB4IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgaW9uLWxpc3QsIGlvbi1yYWRpby1ncm91cHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpb24taXRlbXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpb24taWNvbntcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlvbi1sYWJlbHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzRCNTU1RDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBoMiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjMmY2ZGE4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAzMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBpb24taXRlbSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpb24tbGFiZWwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICMwMDAwMTU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpb24taW5wdXQge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiA1cHggMCAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2YyRjJGMjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC0tcGFkZGluZy1zdGFydDogMTVweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAtLXBsYWNlaG9sZGVyLWNvbG9yOiAjYmRiZGJkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpb24tZGF0ZXRpbWUge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogNXB4IDAgMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNmMkYyRjI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDE1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpb24tc2VsZWN0IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDVweCAwIDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZjJGMkYyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAxNXB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaW9uLXRleHRhcmVhIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDVweCAwIDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZTZlNmU2O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAxNXB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaW9uaWMtc2VsZWN0YWJsZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiA1cHggMCAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2YyRjJGMjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMTVweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaW1nIHtcclxuICAgICAgICAgICAgICAgICAgICAmLmltZ0FkZCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1heC13aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWF4LWhlaWdodDogMTAwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAmLmltZ0VuZCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDMwcHg7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogMzE5cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heC13aWR0aDogMTQwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAzNzRweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4LXdpZHRoOiAxODBweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDQxNXB4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXgtd2lkdGg6IDE4MHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlvbi1pY29uIHtcclxuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgICAgICAgICAgdG9wOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgIHJpZ2h0OiA1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJlZDtcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiA1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgJi5ub1N0eWxlc3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmlnaHQ6IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlvbi1idXR0b24ge1xyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbjogMzBweCAwIDA7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6ICMyZjZkYTg7XHJcbiAgICAgICAgICAgICAgICAgICAgLyogT2xkIGJyb3dzZXJzICovXHJcbiAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOiAtbW96LWxpbmVhci1ncmFkaWVudChsZWZ0LCAjMmY2ZGE4IDAlLCAjMzE5MmM4IDc2JSwgIzczYWQ3ZCAxMDAlKTtcclxuICAgICAgICAgICAgICAgICAgICAvKiBGRjMuNi0xNSAqL1xyXG4gICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZDogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQobGVmdCwgIzJmNmRhOCAwJSwgIzMxOTJjOCA3NiUsICM3M2FkN2QgMTAwJSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLyogQ2hyb21lMTAtMjUsU2FmYXJpNS4xLTYgKi9cclxuICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzJmNmRhOCAwJSwgIzMxOTJjOCA3NiUsICM3M2FkN2QgMTAwJSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLyogVzNDLCBJRTEwKywgRkYxNissIENocm9tZTI2KywgT3BlcmExMissIFNhZmFyaTcrICovXHJcbiAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogIzAwNmZhNjtcclxuICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQtZm9jdXNlZDogIzAwNmZhNjtcclxuICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQtaG92ZXI6ICMwMDZmYTY7XHJcbiAgICAgICAgICAgICAgICAgICAgLS1jb2xvcjogI2ZmZmZmZjtcclxuICAgICAgICAgICAgICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDUwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAzMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIC0tcGFkZGluZy1lbmQ6IDMwcHg7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0iXX0= */";

/***/ }),

/***/ 3092:
/*!**************************************************************!*\
  !*** ./src/app/pages/pescador/pescador.page.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<app-menu TitleBar=\"Pescador artesanal\" isMenuVisible=\"false\" isCloseVisible=\"true\"></app-menu>\r\n\r\n<ion-content>\r\n\r\n    <!-- header fixed -->\r\n    <ion-grid class=\"ion-no-padding ion-no-margin headerGrid\">\r\n        <ion-row class=\"ion-no-padding ion-no-margin\">\r\n            <ion-col class=\"ion-no-padding ion-no-margin\" *ngIf=\"id==0\">\r\n                <ion-icon name=\"{{ tab0==1 ? 'checkmark-circle-outline' :\r\n                    'ellipse-outline' }}\" [ngClass]=\"tab0==1 ? 'active' :\r\n                    'inactive'\"></ion-icon><br>\r\n            </ion-col>\r\n            <ion-col class=\"ion-no-padding ion-no-margin\">\r\n                <ion-icon name=\"{{ tab1==1 ? 'checkmark-circle-outline' :\r\n                    'ellipse-outline' }}\" [ngClass]=\"tab1==1 ? 'active' :\r\n                    'inactive'\"></ion-icon><br>\r\n            </ion-col>\r\n            <ion-col class=\"ion-no-padding ion-no-margin\">\r\n                <ion-icon name=\"{{ tab2==1 ? 'checkmark-circle-outline' :\r\n                    'ellipse-outline' }}\" [ngClass]=\"tab2==1 ? 'active' :\r\n                    'inactive'\"></ion-icon><br>\r\n            </ion-col>\r\n            <ion-col class=\"ion-no-padding ion-no-margin\">\r\n                <ion-icon name=\"{{ tab3==1 ? 'checkmark-circle-outline' :\r\n                    'ellipse-outline' }}\" [ngClass]=\"tab3==1 ? 'active' :\r\n                    'inactive'\"></ion-icon><br>\r\n            </ion-col>\r\n            <ion-col class=\"ion-no-padding ion-no-margin\">\r\n                <ion-icon name=\"{{ tab4==1 ? 'checkmark-circle-outline' :\r\n                    'ellipse-outline' }}\" [ngClass]=\"tab4==1 ? 'active' :\r\n                    'inactive'\"></ion-icon><br>\r\n            </ion-col>\r\n            <ion-col class=\"ion-no-padding ion-no-margin\">\r\n                <ion-icon name=\"{{ tab5==1 ? 'checkmark-circle-outline' :\r\n                    'ellipse-outline' }}\" [ngClass]=\"tab5==1 ? 'active' :\r\n                    'inactive'\"></ion-icon><br>\r\n            </ion-col>\r\n            <ion-col class=\"ion-no-padding ion-no-margin\">\r\n                <ion-icon name=\"{{ tab6==1 ? 'checkmark-circle-outline' :\r\n                    'ellipse-outline' }}\" [ngClass]=\"tab6==1 ? 'active' :\r\n                    'inactive'\"></ion-icon><br>\r\n            </ion-col>\r\n            <ion-col class=\"ion-no-padding ion-no-margin\">\r\n                <ion-icon name=\"{{ tab7==1 ? 'checkmark-circle-outline' :\r\n                    'ellipse-outline' }}\" [ngClass]=\"tab7==1 ? 'active' :\r\n                    'inactive'\"></ion-icon><br>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- zero tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==0 && id==0\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Buscar pescador registrado\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Digite cédula del pescador</ion-label>\r\n                    <ion-input [(ngModel)]=\"cedula_search\"  style=\"text-transform: uppercase;\"\r\n                    (ionChange)=\"numberValidator($event)\" (keydown.space)=\"$event.preventDefault();\"></ion-input>\r\n                    <small style=\"margin-top: 10px;\">(Sin letras, espacios ni caracteres especiales Ej. -#%?/)</small>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" align=\"center\">\r\n                <ion-button (click)=\"validateSearch()\" color=\"success\">\r\n                    Buscar pescador\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"12\" align=\"center\" *ngIf=\"searchPesca\">\r\n                <ion-button (click)=\"nextTab()\">\r\n                    Continuar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- first tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==1\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Datos de la solicitud\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Radicado *</ion-label>\r\n                    <ion-input [(ngModel)]=\"filed\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Fecha de radicado *</ion-label>\r\n                    <ion-datetime presentation=\"date\" [(ngModel)]=\"filing_date\" displayFormat=\"YYYY-MM-DD\" pickerFormat=\"YYYY-MMM-DD\"\r\n                        max=\"2030\" placeholder=\"Seleccione la fecha\"></ion-datetime>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Municipio *</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"department\" [items]=\"lugares\"\r\n                        itemValueField=\"codigo\" itemTextField=\"nombre\" [canSearch]=\"false\" (onChange)=\"setVal()\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col *ngIf=\"actualTab>0 && id == 0\" size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"antTab()\">\r\n                    Volver\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"{{ id==0 ? '6' : '12' }}\" align=\"center\">\r\n                <ion-button (click)=\"nextTab()\" [disabled]=\"!department || !filed || !filing_date\">\r\n                    Continuar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- second tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==2\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Documentos de la solicitud\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col size=\"12\" class=\"radios\">\r\n                <ion-label position=\"stacked\">Copia del documento de identificación *</ion-label>\r\n                <ion-list>\r\n                    <ion-radio-group (ionChange)=\"selectedRadio(1, $event)\" [value]=\"copy_identification_document\">\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>SI</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"SI\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>NO</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"NO\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                    </ion-radio-group>\r\n                </ion-list>\r\n            </ion-col>\r\n            <ion-col size=\"12\" class=\"radios\">\r\n                <ion-label position=\"stacked\">Copia OCCRE *</ion-label>\r\n                <ion-list>\r\n                    <ion-radio-group (ionChange)=\"selectedRadio(2, $event)\" [value]=\"copy_occre\">\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>SI</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"SI\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>NO</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"NO\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                    </ion-radio-group>\r\n                </ion-list>\r\n            </ion-col>\r\n            <ion-col size=\"12\" class=\"radios\">\r\n                <ion-label position=\"stacked\">Fotocopia de afiliación de salud *</ion-label>\r\n                <ion-list>\r\n                    <ion-radio-group (ionChange)=\"selectedRadio(3, $event)\" [value]=\"copy_sisben\">\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>SI</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"SI\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>NO</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"NO\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                    </ion-radio-group>\r\n                </ion-list>\r\n            </ion-col>\r\n            <ion-col size=\"12\" class=\"radios\">\r\n                <ion-label position=\"stacked\">Certificación / Acreditación *</ion-label>\r\n                <ion-list>\r\n                    <ion-radio-group (ionChange)=\"selectedRadio(4, $event)\" [value]=\"accreditation_certificate\">\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>SI</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"SI\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>NO</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"NO\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                    </ion-radio-group>\r\n                </ion-list>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"accreditation_certificate==='SI'\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Certificación expedida por *</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"certification_issued_by\"\r\n                        [items]=\"empresas\" itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"true\" (onSearch)=\"onChangeCert($event)\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col *ngIf=\"actualTab>0\" size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"antTab()\">\r\n                    Volver\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <ion-button (click)=\"nextTab()\" [disabled]=\"!copy_identification_document || !copy_occre || !copy_sisben || !accreditation_certificate || !certification_issued_by\">\r\n                    Continuar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- third tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==3\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Datos del permiso\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Vigencia del permiso (años) *</ion-label>\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"vigencia_permiso\" (ionChange)=\"updateExpiration(1)\" required>\r\n                        <ion-select-option value=\"5\">5</ion-select-option>\r\n                        <ion-select-option value=\"4\">4</ion-select-option>\r\n                        <ion-select-option value=\"3\">3</ion-select-option>\r\n                        <ion-select-option value=\"2\">2</ion-select-option>\r\n                        <ion-select-option value=\"1\">1</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Fecha de expedición *</ion-label>\r\n                    <ion-datetime presentation=\"date\" [(ngModel)]=\"expedition_date\" displayFormat=\"YYYY-MM-DD\" pickerFormat=\"YYYY-MMM-DD\"\r\n                        max=\"2030\" placeholder=\"Seleccione la fecha\" (ionChange)=\"updateExpiration(1)\"></ion-datetime>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Fecha de expiración *</ion-label>\r\n                    <ion-input [(ngModel)]=\"expiration_date\" readonly></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col *ngIf=\"actualTab>0\" size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"antTab()\">\r\n                    Volver\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"nextTab()\" [disabled]=\"!expiration_date || !expedition_date || !vigencia_permiso\">\r\n                    Continuar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- four tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==4\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Identificación del pescador\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col align=\"center\">\r\n                <!-- <img src=\"{{ photo ? photo : '../../../assets/images/thumb-add-imagen.png' }}\" class=\"imgAdd\" (click)=\"uPloadNewPhoto()\"> -->\r\n                \r\n                <ion-item button style=\"width: 90px; margin: 0 auto;\" (click)=\"uPloadNewPhoto()\" lines=\"none\">\r\n                    <ion-thumbnail>\r\n                        <img src=\"https://backend.rgpsai.org/storage/fishermen/{{ photo }}\"  *ngIf=\"photo != null\" class=\"imgAdd\"/>\r\n                        <img src=\"../../../assets/images/user.png\"  *ngIf=\"photo == null\" class=\"imgAdd\"/>\r\n                    </ion-thumbnail>\r\n                    <ion-label>\r\n                        <ion-icon name=\"camera\" style=\"background: var(--ion-color-primary);\" color=\"light\"></ion-icon>\r\n                    </ion-label>\r\n                </ion-item>\r\n\r\n                <ion-text>\r\n                    <p>\r\n                        Foto del pescador\r\n                    </p>\r\n                </ion-text>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Nombre(s) del pescador *</ion-label>\r\n                    <ion-input [(ngModel)]=\"name\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Apellido(s) del pescador *</ion-label>\r\n                    <ion-input [(ngModel)]=\"lastname\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Tipo de documento *</ion-label>\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"type_of_card\">\r\n                        <ion-select-option value=\"UNO\">CC</ion-select-option>\r\n                        <ion-select-option value=\"DOS\">CE</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Número de documento *</ion-label>\r\n                    <ion-input [(ngModel)]=\"identification_number\" (ionChange)=\"numberValidator($event)\" (keydown.space)=\"$event.preventDefault();\" type=\"cel\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" class=\"radios\">\r\n                <ion-label position=\"stacked\">Clasificación de certificación OCCRE</ion-label>\r\n                <ion-list>\r\n                    <ion-radio-group (ionChange)=\"selectedRadio(5, $event)\" [value]=\"occre\">\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>RAIZAL</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"RAIZAL\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>RESIDENTE</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"RESIDENTE\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                    </ion-radio-group>\r\n                </ion-list>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">No. de OCCRE *</ion-label>\r\n                    <ion-input [(ngModel)]=\"no_occre\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Nacionalidad</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"nationality\"\r\n                        [items]=\"paises\" itemValueField=\"codigo\" itemTextField=\"name\" [canSearch]=\"true\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Email</ion-label>\r\n                    <ion-input [(ngModel)]=\"email\" (ionChange)=\"validarEmail($event)\"></ion-input>\r\n                </ion-item>\r\n                <small *ngIf=\"!emailValidate\" style=\"color: red; margin-left:20px\">\r\n                    Debe digitar un email valido\r\n                </small>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Dirección</ion-label>\r\n                    <ion-input [(ngModel)]=\"address\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Teléfono</ion-label>\r\n                    <ion-input [(ngModel)]=\"phone\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"12\" class=\"radios\">\r\n                <ion-label position=\"stacked\">Organización / Cooperativa</ion-label>\r\n                <ion-list>\r\n                    <ion-radio-group (ionChange)=\"selectedRadio(6, $event)\" [value]=\"organization_cooperative\">\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>SI</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"SI\" mode=\"md\" [disabled]=\"certification_issued_by.id==null ? true : false\"></ion-radio>\r\n                        </ion-item>\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>NO</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"NO\" mode=\"md\" [disabled]=\"certification_issued_by.id==null ? true : false\"></ion-radio>\r\n                        </ion-item>\r\n                    </ion-radio-group>\r\n                </ion-list>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"organization_cooperative=='SI'\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Nombre de la organización *</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"organization_name\"\r\n                        [items]=\"empresas\" itemValueField=\"id\" itemTextField=\"name\" [canSearch]=\"true\" [disabled]=\"certification_issued_by.id==null ? true : false\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col *ngIf=\"actualTab>0\" size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"antTab()\">\r\n                    Volver\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"nextTab()\" [disabled]=\"!name || !lastname || !type_of_card || !identification_number || !no_occre || !nationality\">\r\n                    Continuar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- five tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==5\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Descripción de actividad pesquera\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Zona de desembarque *</ion-label>\r\n                    <ionic-selectable item-content placeholder=\"Seleccione\" [(ngModel)]=\"dembarque_port\"\r\n                        [items]=\"dembarquePorts\" itemValueField=\"codigo\" itemTextField=\"nombre\" [canSearch]=\"true\">\r\n                    </ionic-selectable>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Zona de frecuente de pesca</ion-label>\r\n                    <ion-input type=\"text\" [(ngModel)]=\"zona_frecuente_pesca\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Tipo de embarcación artesanal</ion-label>\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"tipo_embarcacion_artesanal\">\r\n                        <ion-select-option *ngFor=\"let item of tipoEmbarcacionArnal\" value=\"{{ item.codigo }}\">{{ item.nombre }}</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\" *ngIf=\"tipo_embarcacion_artesanal && tipo_embarcacion_artesanal.includes('CINCO')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Otro tipo de embarcación artesanal, ¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otro_tipo_embarcacion_artesanal\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Tipo de pesquería</ion-label>\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"tipo_pesqueria\" multiple=\"true\">\r\n                        <ion-select-option *ngFor=\"let item of tiposPesqueria\" value=\"{{ item.type_of_fishery_id }}\">{{ item.description }}</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Artes de pesca</ion-label>\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"artes_pesca\" multiple=\"true\">\r\n                        <ion-select-option *ngFor=\"let item of artesPesca\" value=\"{{ item.fishing_art_id }}\">{{ item.description }}</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col *ngIf=\"actualTab>0\" size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"antTab()\">\r\n                    Volver\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"nextTab()\">\r\n                    Continuar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- six tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==6\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Embarcaciones\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col size=\"12\" class=\"radios\">\r\n                <ion-label position=\"stacked\">Reporta embarcación</ion-label>\r\n                <ion-list>\r\n                    <ion-radio-group (ionChange)=\"selectedRadio(7, $event)\" [value]=\"reporta_embarcacion\">\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>SI</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"SI\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>NO</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"NO\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                    </ion-radio-group>\r\n                </ion-list>\r\n            </ion-col>\r\n            <ion-col size=\"12\" class=\"radios\" *ngIf=\"reporta_embarcacion=='SI'\">\r\n                <ion-label position=\"stacked\">Propietario de la embarcación</ion-label>\r\n                <ion-list>\r\n                    <ion-radio-group (ionChange)=\"selectedRadio(8, $event)\" [value]=\"propietario_embarcacion\">\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>SI</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"SI\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>NO</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"NO\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                    </ion-radio-group>\r\n                </ion-list>\r\n            </ion-col>\r\n            <ion-col size=\"12\" *ngIf=\"reporta_embarcacion=='SI'\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Documento que lo acredita</ion-label>\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"documento_acredita\">\r\n                        <ion-select-option *ngFor=\"let item of documentoAcredita\" value=\"{{ item.description }}\">{{ item.description }}</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n            \r\n            <ion-col size=\"12\" *ngIf=\"reporta_embarcacion=='SI'\">\r\n                <ion-row>\r\n                    <ion-col size=\"9\">\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label position=\"stacked\">Buscar embarcación</ion-label>\r\n                            <ion-input type=\"text\" [(ngModel)]=\"search_vessel_field\" placeholder=\"Registration number\"></ion-input>\r\n                        </ion-item>\r\n                    </ion-col>\r\n                    <ion-col size=\"3\">\r\n                        <ion-button size=\"small\" style=\"margin-top:50px\" (click)=\"searchVessel()\">\r\n                            <ion-icon name=\"add-outline\" class=\"noStyles\"></ion-icon>\r\n                        </ion-button>\r\n                    </ion-col>\r\n                </ion-row>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\" *ngIf=\"data_boats && data_boats.length>0 && reporta_embarcacion=='SI'\">\r\n                <ion-row>\r\n                    <ion-col size=\"1\"></ion-col>\r\n                    <ion-col size=\"10\">\r\n                        <h5>\r\n                            Embarcaciones asociadas\r\n                        </h5>\r\n                        <ion-row *ngFor=\"let item of data_boats; index as i\">\r\n                            <ion-col size=\"10\">\r\n                                {{ item.boat_request_id }} - {{ item.nombre }}\r\n                                <!-- {{ item.registration_number }} - {{ item.name }} -->\r\n                            </ion-col>\r\n                            <ion-col>\r\n                                <ion-icon name=\"trash-outline\" class=\"noStyles\" (click)=\"deleteVesselAsociate(item.registration_number)\"></ion-icon>\r\n                            </ion-col>\r\n                        </ion-row>\r\n                    </ion-col>\r\n                </ion-row>\r\n            </ion-col>\r\n\r\n            <ion-col *ngIf=\"actualTab>0\" size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"antTab()\">\r\n                    Volver\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"nextTab()\">\r\n                    Continuar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- seven tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==7\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Información socioeconómica\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Fecha de nacimiento </ion-label>\r\n                    <ion-datetime presentation=\"date\" [(ngModel)]=\"birthdate\" displayFormat=\"YYYY-MM-DD\" pickerFormat=\"YYYY-MMM-DD\"\r\n                        max=\"2030\" placeholder=\"Seleccione la fecha\" (ionChange)=\"calculateAge()\"></ion-datetime>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Edad</ion-label>\r\n                    <ion-input type=\"text\" [(ngModel)]=\"age\" placeholder=\"Seleccione fecha de nacimiento\" readonly></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Sexo</ion-label>\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"genre\">\r\n                        <ion-select-option *ngFor=\"let item of genres\" value=\"{{ item.codigo }}\">{{ item.nombre }}</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Estado civil</ion-label>\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"marital_state\">\r\n                        <ion-select-option *ngFor=\"let item of maritalStates\" value=\"{{ item.codigo }}\">{{ item.nombre }}</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\" *ngIf=\"marital_state && marital_state.includes('CINCO')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Otro estado civil, ¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otro_marital_state\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\" class=\"radios\">\r\n                <ion-label position=\"stacked\">Lee y escribe</ion-label>\r\n                <ion-list>\r\n                    <ion-radio-group (ionChange)=\"selectedRadio(9, $event)\" [value]=\"read_write\">\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>SI</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"SI\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>NO</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"NO\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                    </ion-radio-group>\r\n                </ion-list>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Nivel educativo del pescador</ion-label>\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"education_level\">\r\n                        <ion-select-option *ngFor=\"let item of educationLevels\" value=\"{{ item.codigo }}\">{{ item.nombre }}</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\" *ngIf=\"education_level && education_level.includes('SEIS')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Otro nivel educativo, ¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otro_education_level\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\" class=\"radios\">\r\n                <ion-label position=\"stacked\">Posee casa propia</ion-label>\r\n                <ion-list>\r\n                    <ion-radio-group (ionChange)=\"selectedRadio(10, $event)\" [value]=\"own_home\">\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>SI</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"SI\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                        <ion-item lines=\"none\">\r\n                            <ion-label>NO</ion-label>\r\n                            <ion-radio slot=\"start\" value=\"NO\" mode=\"md\"></ion-radio>\r\n                        </ion-item>\r\n                    </ion-radio-group>\r\n                </ion-list>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Tipo de servicio de salud</ion-label>\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"healt_service\">\r\n                        <ion-select-option *ngFor=\"let item of servicesHealt\" value=\"{{ item.codigo }}\">{{ item.nombre }}</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\" *ngIf=\"healt_service && healt_service.includes('CUATRO')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Otro tipo de servicio de salud, ¿Cuál?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otro_healt_service\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Tiempo en la pesca</ion-label>\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"pesca_time\">\r\n                        <ion-select-option *ngFor=\"let item of timePesca\" value=\"{{ item.codigo }}\">{{ item.nombre }}</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\" *ngIf=\"pesca_time && pesca_time.includes('CUATRO')\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Otro, ¿Cuántos?</ion-label>\r\n                    <ion-input [(ngModel)]=\"otro_pesca_time\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Dedicación</ion-label>\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"dedication\">\r\n                        <ion-select-option *ngFor=\"let item of dedicationDrop\" value=\"{{ item.codigo }}\">{{ item.nombre }}</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Horario de pesca</ion-label>\r\n                    <ion-select placeholder=\"Seleccione\" [(ngModel)]=\"hour_pesca\">\r\n                        <ion-select-option *ngFor=\"let item of horarioPesca\" value=\"{{ item.codigo }}\">{{ item.nombre }}</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col *ngIf=\"actualTab>0\" size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"antTab()\">\r\n                    Volver\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"nextTab()\">\r\n                    Continuar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- eight tab -->\r\n    <ion-grid class=\"marginInitial\" *ngIf=\"actualTab==8\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <ion-text>\r\n                    <h2>\r\n                        Observaciones\r\n                    </h2>\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Observaciones</ion-label>\r\n                    <ion-textarea [(ngModel)]=\"observations\" maxLength=\"800\"></ion-textarea>\r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col *ngIf=\"actualTab>0\" size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"antTab()\">\r\n                    Volver\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"6\" align=\"center\">\r\n                <ion-button (click)=\"saveInLocal()\">\r\n                    Finalizar\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_pescador_pescador_module_ts.js.map