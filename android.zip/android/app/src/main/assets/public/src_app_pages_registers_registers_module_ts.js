"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_registers_registers_module_ts"],{

/***/ 5642:
/*!*************************************************!*\
  !*** ./src/app/components/components.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ComponentsModule": () => (/* binding */ ComponentsModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _components_menu_menu_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../components/menu/menu.component */ 5819);





let ComponentsModule = class ComponentsModule {
};
ComponentsModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [
            _components_menu_menu_component__WEBPACK_IMPORTED_MODULE_0__.MenuComponent,
        ],
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        ],
        exports: [
            _components_menu_menu_component__WEBPACK_IMPORTED_MODULE_0__.MenuComponent,
        ],
    })
], ComponentsModule);



/***/ }),

/***/ 5819:
/*!***************************************************!*\
  !*** ./src/app/components/menu/menu.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuComponent": () => (/* binding */ MenuComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _menu_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./menu.component.html?ngResource */ 2574);
/* harmony import */ var _menu_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./menu.component.scss?ngResource */ 1346);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 3819);






let MenuComponent = class MenuComponent {
    constructor(alertController, router) {
        this.alertController = alertController;
        this.router = router;
    }
    ngOnInit() { }
    closeView() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Confirmación',
                message: '¿Desea salir de esta vista?<br> Si lo hace perdera los avances que tenga en el formulario',
                backdropDismiss: false,
                buttons: [
                    {
                        text: 'No',
                        role: 'cancel',
                        handler: () => { }
                    },
                    {
                        text: 'Si',
                        handler: () => {
                            this.router.navigate(['registers']);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
MenuComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router }
];
MenuComponent.propDecorators = {
    TitleBar: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["TitleBar",] }],
    isMenuVisible: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["isMenuVisible",] }],
    isBackVisible: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["isBackVisible",] }],
    isFilterVisible: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["isFilterVisible",] }],
    isBackItemVisible: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["isBackItemVisible",] }],
    isCloseVisible: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["isCloseVisible",] }]
};
MenuComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-menu',
        template: _menu_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_menu_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], MenuComponent);



/***/ }),

/***/ 7834:
/*!*************************************************************!*\
  !*** ./src/app/pages/registers/registers-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistersPageRoutingModule": () => (/* binding */ RegistersPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _registers_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./registers.page */ 1529);




const routes = [
    {
        path: '',
        component: _registers_page__WEBPACK_IMPORTED_MODULE_0__.RegistersPage
    }
];
let RegistersPageRoutingModule = class RegistersPageRoutingModule {
};
RegistersPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RegistersPageRoutingModule);



/***/ }),

/***/ 7449:
/*!*****************************************************!*\
  !*** ./src/app/pages/registers/registers.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistersPageModule": () => (/* binding */ RegistersPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _registers_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./registers-routing.module */ 7834);
/* harmony import */ var _registers_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./registers.page */ 1529);
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/components.module */ 5642);








let RegistersPageModule = class RegistersPageModule {
};
RegistersPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _registers_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegistersPageRoutingModule,
            _components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule
        ],
        declarations: [_registers_page__WEBPACK_IMPORTED_MODULE_1__.RegistersPage]
    })
], RegistersPageModule);



/***/ }),

/***/ 1529:
/*!***************************************************!*\
  !*** ./src/app/pages/registers/registers.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistersPage": () => (/* binding */ RegistersPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _registers_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./registers.page.html?ngResource */ 7286);
/* harmony import */ var _registers_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./registers.page.scss?ngResource */ 9586);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_services_api_rest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api-rest.service */ 6363);
/* harmony import */ var _config_events__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../config/events */ 6721);
/* harmony import */ var _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/preferences */ 5191);









let RegistersPage = class RegistersPage {
    constructor(alertController, loadingController, api, router, zone, events) {
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.api = api;
        this.router = router;
        this.zone = zone;
        this.events = events;
        //generals
        this.dataStoragePescador = [];
        this.dataStorage = [];
        this.dataStorageArtesanal = [];
        this.typeSelected = 1;
        this.events.subscribe('updateRegisters', (data) => {
            this.zone.run(() => {
                this.validateSession();
            });
        });
    }
    ngOnInit() {
        this.zone.run(() => {
            this.validateSession();
        });
        this.changeTab(1);
    }
    validateSession() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            this.data = [];
            this.dataArtesanal = [];
            let dataSession = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.get({ key: 'sessionPersistence' });
            let session = JSON.parse(dataSession.value);
            if (session) {
                if (session.userID) {
                    this.userID = session.userID;
                }
                if (session.userToken) {
                    this.tokenUser = session.userToken;
                }
            }
            else {
                this.router.navigate(['login']);
            }
            //this.updateArtesanalArray();
            //this.updateIndustrialArray();
            let dataRegistersIndustrial = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.get({ key: 'dataRegistersIndustrial' });
            let sessionDataRegistersIndustrial = JSON.parse(dataRegistersIndustrial.value);
            if (sessionDataRegistersIndustrial) {
                this.data = this.sortByKey(sessionDataRegistersIndustrial, 'creation_date');
                //console.log(this.data)
            }
            let dataRegistersArtesanal = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.get({ key: 'dataRegistersArtesanal' });
            let sessionDataRegistersArtesanal = JSON.parse(dataRegistersArtesanal.value);
            if (sessionDataRegistersArtesanal) {
                this.dataArtesanal = this.sortByKey(sessionDataRegistersArtesanal, 'creation_date');
                //console.log(this.dataArtesanal)
            }
            let dataRegistersPescadores = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.get({ key: 'dataRegistersPescadores' });
            let sessionDataRegistersPescadores = JSON.parse(dataRegistersPescadores.value);
            if (sessionDataRegistersPescadores) {
                this.dataPescador = this.sortByKey(sessionDataRegistersPescadores, 'creation_date');
                //console.log(this.dataPescador)
            }
        });
    }
    sortByKey(array, key) {
        return array.sort(function (b, a) {
            var x = a[key];
            var y = b[key];
            return ((x < y) ? -1 : ((x > y) ? 0 : 1));
        });
    }
    //change tab
    changeTab(type) {
        this.typeSelected = type;
    }
    //create/edit industrial
    goToIndustrial(item) {
        this.router.navigate(["industrials", item]);
    }
    //create/edit artesanal
    goToArtesanal(item) {
        this.router.navigate(["artesanals", item]);
    }
    //create/edit pescador
    goToPescador(item) {
        this.router.navigate(["pescador", item]);
    }
    //open detail industrial
    detailIndustrial(id) {
        this.router.navigate(["industrials/detail", id]);
    }
    //open detail artesanal
    detailArtesanal(id) {
        this.router.navigate(["artesanals/detail", id]);
    }
    //open detail pescador
    detailPescador(id) {
        this.router.navigate(["pescador/detail", id]);
    }
    //delete industrial record
    deleteIndustrial(registerID) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            let dataRegisters = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.get({ key: 'dataRegistersIndustrial' });
            let response = JSON.parse(dataRegisters.value);
            this.dataStorage = response;
            const alert = yield this.alertController.create({
                header: 'Confirmación!',
                message: '¿Esta seguro de realizar esta acción?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        handler: () => { },
                    },
                    {
                        text: 'Si',
                        role: 'confirm',
                        handler: () => {
                            let items = this.dataStorage.filter((item) => {
                                return item.id === registerID;
                            });
                            items.forEach((element) => {
                                var index = this.dataStorage.indexOf(element);
                                this.dataStorage.splice(index, 1);
                            });
                            this.updateIndustrialArray();
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
    //delete industrial record
    deleteArtesanals(registerID) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            let dataRegisters = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.get({ key: 'dataRegistersArtesanal' });
            let response = JSON.parse(dataRegisters.value);
            this.dataStorageArtesanal = response;
            const alert = yield this.alertController.create({
                header: 'Confirmación!',
                message: '¿Esta seguro de realizar esta acción?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        handler: () => { },
                    },
                    {
                        text: 'Si',
                        role: 'confirm',
                        handler: () => {
                            let items = this.dataStorageArtesanal.filter((item) => {
                                return item.id === registerID;
                            });
                            items.forEach((element) => {
                                var index = this.dataStorageArtesanal.indexOf(element);
                                this.dataStorageArtesanal.splice(index, 1);
                            });
                            this.updateArtesanalArray();
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
    //delete industrial record
    deletePescador(registerID) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            let dataRegisters = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.get({ key: 'dataRegistersPescadores' });
            let response = JSON.parse(dataRegisters.value);
            this.dataStoragePescador = response;
            const alert = yield this.alertController.create({
                header: 'Confirmación!',
                message: '¿Esta seguro de realizar esta acción?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        handler: () => { },
                    },
                    {
                        text: 'Si',
                        role: 'confirm',
                        handler: () => {
                            let items = this.dataStoragePescador.filter((item) => {
                                return item.id === registerID;
                            });
                            items.forEach((element) => {
                                var index = this.dataStoragePescador.indexOf(element);
                                this.dataStoragePescador.splice(index, 1);
                            });
                            this.updatePescadoresArray();
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
    //upload industrial
    getStoreIndustrials(registerID) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            let object = Object();
            let dataRegistersIndustrial = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.get({ key: 'dataRegistersIndustrial' });
            let responseJson = JSON.parse(dataRegistersIndustrial.value);
            if (responseJson) {
                //console.log(response);
                this.dataStorage = responseJson;
                let items = this.dataStorage.filter((item) => {
                    return item.id === registerID;
                });
                items.forEach((data) => {
                    data.status = 3;
                    //object.user_id = this.userID;
                    //tab 1
                    object.lugar = data.lugar.id;
                    object.fecha_expedicion = data.fecha_expedicion;
                    //tab 2
                    object.permisionario = data.permisionario;
                    object.nit = data.nit;
                    //tab 3
                    object.nombre_barco = data.nombre_barco;
                    object.numero_matricula = data.numero_matricula;
                    object.lugar_matricula = data.lugar_matricula;
                    object.fecha_matricula = data.fecha_matricula;
                    object.vencimiento_matricula = data.vencimiento_matricula;
                    //tab 4
                    object.bandera = data.bandera ? data.bandera : null;
                    object.puerto_registro = data.puerto_registro ? data.puerto_registro : null;
                    object.otro_puerto_registro = data.otro_puerto_registro;
                    object.tipo_barco = data.tipo_barco ? data.tipo_barco : null;
                    object.otro_tipo_barco = data.otro_tipo_barco;
                    object.valor_embarcacion = data.valor_embarcacion;
                    object.venta_productos_a = data.venta_productos_a;
                    //tab 5
                    object.eslora = data.eslora;
                    object.manga = data.manga;
                    object.tonelaje = data.tonelaje;
                    object.tonelaje_registro_bruto = data.tonelaje_registro_bruto;
                    object.potencia_motor_ppal = data.potencia_motor_ppal;
                    object.unidad_potencia = data.unidad_potencia ? data.unidad_potencia : null;
                    object.material_casco = data.material_casco ? data.material_casco : null;
                    object.numero_bodegas = data.numero_bodegas;
                    object.alto_bodegas = data.alto_bodegas;
                    object.largo_bodegas = data.largo_bodegas;
                    object.ancho_bodegas = data.ancho_bodegas;
                    object.capacidad_bodegas = data.capacidad_bodegas;
                    object.tipo_conservacion = data.tipo_conservacion ? data.tipo_conservacion : null;
                    object.nombre_admin_agencia = data.nombre_admin_agencia;
                    object.numero_tripulantes = data.numero_tripulantes;
                    object.numero_pescadores = data.numero_pescadores;
                    object.valor_arte_pesca = data.valor_arte_pesca;
                    object.zona_pesca = data.zona_pesca;
                    object.denominacion_arte_pesca = data.denominacion_arte_pesca ? data.denominacion_arte_pesca : null;
                    object.otra_denominacion_arte_pesca = data.otra_denominacion_arte_pesca;
                    object.tipo_anzuelo = data.tipo_anzuelo ? data.tipo_anzuelo : null;
                    object.tamano_anzuelo = data.tamano_anzuelo;
                    object.cantidad_anzuelos = data.cantidad_anzuelos;
                    object.longitud_linea_madre = data.longitud_linea_madre;
                    object.material_linea_madre = data.material_linea_madre ? data.material_linea_madre : null;
                    object.material_bajantes = data.material_bajantes ? data.material_bajantes : null;
                    object.otro_material_bajantes = data.otro_material_bajantes;
                    object.cantidad_total_lineas = data.cantidad_total_lineas;
                    object.denominacion_alerta = data.denominacion_alerta ? data.denominacion_alerta : null;
                    object.otra_denominacion_del_arte = data.otra_denominacion_del_arte;
                    object.cantidad_trampas_nasas = data.cantidad_trampas_nasas;
                    object.material_ppal_trampas = data.material_ppal_trampas ? data.material_ppal_trampas : null;
                    object.otro_material_ppal = data.otro_material_ppal;
                    object.tipo_artefactos = data.tipo_artefactos ? data.tipo_artefactos : null;
                    object.otro_tipo_artefacto = data.otro_tipo_artefacto;
                    object.cantidad_artefactos = data.cantidad_artefactos;
                    object.material_artefacto = data.material_artefacto ? data.material_artefacto : null;
                    object.otro_material_artefacto = data.otro_material_artefacto;
                    object.uso_dispositivos = data.uso_dispositivos ? data.uso_dispositivos : null;
                    object.tipo_fad_usados = data.tipo_fad_usados ? data.tipo_fad_usados.id : 'N/A';
                    object.otro_tipo_fad_usados = data.otro_tipo_fad_usados;
                    object.cantidad_fad_usados = data.cantidad_fad_usados;
                    object.componentes_fad = data.componentes_fad;
                    //tab6
                    object.cartas_navegacion = data.cartas_navegacion ? data.cartas_navegacion : 'N/A';
                    ;
                    object.compas_magnetico = data.compas_magnetico ? data.compas_magnetico : 'N/A';
                    ;
                    object.gps = data.gps ? data.gps : 'N/A';
                    ;
                    object.loran = data.loran ? data.loran : 'N/A';
                    ;
                    object.radar = data.radar ? data.radar : 'N/A';
                    ;
                    object.ecosonda = data.ecosonda ? data.ecosonda : 'N/A';
                    ;
                    object.radios_comunicacion = data.radios_comunicacion ? data.radios_comunicacion : 'N/A';
                    ;
                    //tab 7
                    object.firma_representante = data.signature;
                    object.fotos_embarcacion = data.fotos_embarcacion;
                    object.observations = data.observations;
                    //new
                    object.calado = data.calado;
                    object.otra_unidad_potencia = data.otra_unidad_potencia;
                    object.otro_material_casco = data.otro_material_casco;
                    object.otro_tipo_conservacion = data.otro_tipo_conservacion;
                    object.radicado = data.radicado;
                    object.codigo_verificacion = data.codigo_verificacion;
                    object.nombre_propietario = data.nombre_propietario;
                    object.tipo_identificacion = data.tipo_identificacion;
                    object.otro_tipo_identificacion = data.otro_tipo_identificacion;
                    object.numero_identificacion = data.numero_identificacion;
                    object.nombre_representante = data.nombre_representante;
                    object.tipo_identificacion_representante = data.tipo_identificacion_representante;
                    object.otro_tipo_identificacion_representante = data.otro_tipo_identificacion_representante;
                    object.numero_identificacion_representante = data.numero_identificacion_representante;
                    object.cargo_representante = data.cargo_representante;
                    object.artes_de_pesca = data.artes_de_pesca;
                    object.otro_arte_pesca = data.otro_arte_pesca;
                    object.puerto_desembarque = data.puerto_desembarque ? data.puerto_desembarque : null;
                    object.otro_puerto_desembarque = data.otro_puerto_desembarque;
                });
            }
            //console.log('Datos enviados...', object);
            const loading = yield this.loadingController.create({
                message: 'Cargando...',
                spinner: 'crescent',
                showBackdrop: true,
            });
            yield loading.present();
            this.api.getStoreIndustrials(object, "Bearer " + this.tokenUser).subscribe(response => {
                loading.dismiss();
                if (response[0].codigo == 200) {
                    console.log(response[0]);
                    let items = this.dataStorage.filter((item) => {
                        return item.id === registerID;
                    });
                    items.forEach((element) => {
                        var index = this.dataStorage.indexOf(element);
                        this.dataStorage.splice(index, 1);
                    });
                    this.alertUpload(response[0].message);
                }
                else {
                    this.presentError(response[0].message);
                }
            }, err => {
                //console.log(err, this.tokenUser);
                loading.dismiss();
                if (err.status == '401') {
                    this.presentError("Tu sesión ha expirado, por favor inicia sesión nuevamente");
                    this.closeSession();
                    this.router.navigate(["login"]);
                }
                else {
                    this.presentError('No podemos procesar tu solicitud en este momento, intenta más tarde.');
                }
            });
        });
    }
    //uplad register server
    alertUpload(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Confirmación',
                message: message,
                buttons: [
                    {
                        text: 'Aceptar',
                        handler: () => {
                            this.updateIndustrialArray();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    //upload industrial
    getStoreArtesanal(registerID) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            let object = Object();
            let dataRegistersArtesanal = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.get({ key: 'dataRegistersArtesanal' });
            let responseObject = JSON.parse(dataRegistersArtesanal.value);
            if (responseObject) {
                this.dataStorageArtesanal = responseObject;
                let items = this.dataStorageArtesanal.filter((item) => {
                    return item.id === registerID;
                });
                items.forEach((data) => {
                    //object.user_id = this.userID;
                    data.status = 3;
                    //tab 1
                    object.lugar = data.lugar ? data.lugar : null;
                    object.fecha_expedicion = data.lugar ? data.fecha_expedicion : null;
                    //tab 2
                    object.permisionario = data.permisionario;
                    object.nit = data.nit;
                    //tab 3
                    object.nombre_barco = data.nombre_barco;
                    object.numero_matricula = data.numero_matricula ? (data.numero_matricula).toUpperCase() : null;
                    object.lugar_matricula = data.lugar_matricula;
                    object.fecha_matricula = data.fecha_matricula;
                    object.vencimiento_matricula = data.vencimiento_matricula;
                    //tab 4
                    object.bandera = data.bandera ? data.bandera.codigo : null;
                    object.puerto_registro = data.puerto_registro ? data.puerto_registro : null;
                    object.otro_puerto_registro = data.otro_puerto_registro;
                    object.tipo_barco = data.tipo_barco ? data.tipo_barco : null;
                    object.otro_tipo_barco = data.otro_tipo_barco;
                    object.valor_embarcacion = data.valor_embarcacion;
                    object.venta_productos_a = data.venta_productos_a;
                    //tab 5
                    object.eslora = data.eslora;
                    object.manga = data.manga;
                    object.tonelaje = data.tonelaje;
                    object.tonelaje_registro_bruto = data.tonelaje_registro_bruto;
                    object.potencia_motor_ppal = data.potencia_motor_ppal;
                    object.unidad_potencia = data.unidad_potencia ? data.unidad_potencia : null;
                    object.material_casco = data.material_casco ? data.material_casco : null;
                    object.numero_bodegas = data.numero_bodegas;
                    object.alto_bodegas = data.alto_bodegas;
                    object.largo_bodegas = data.largo_bodegas;
                    object.ancho_bodegas = data.ancho_bodegas;
                    object.capacidad_bodegas = data.capacidad_bodegas;
                    object.tipo_conservacion = data.tipo_conservacion ? data.tipo_conservacion : null;
                    object.nombre_admin_agencia = data.nombre_admin_agencia;
                    object.numero_tripulantes = data.numero_tripulantes;
                    object.numero_pescadores = data.numero_pescadores;
                    object.valor_arte_pesca = data.valor_arte_pesca;
                    object.zona_pesca = data.zona_pesca;
                    object.denominacion_arte_pesca = data.denominacion_arte_pesca ? data.denominacion_arte_pesca : null;
                    object.otra_denominacion_arte_pesca = data.otra_denominacion_arte_pesca;
                    object.tipo_anzuelo = data.tipo_anzuelo ? data.tipo_anzuelo : null;
                    object.tamano_anzuelo = data.tipo_anzuelo ? data.tamano_anzuelo : null;
                    object.cantidad_anzuelos = data.cantidad_anzuelos;
                    object.longitud_linea_madre = data.longitud_linea_madre;
                    object.material_linea_madre = data.material_linea_madre ? data.material_linea_madre : 1;
                    object.material_bajantes = data.material_bajantes ? data.material_bajantes : null;
                    object.otro_material_bajantes = data.otro_material_bajantes;
                    object.cantidad_total_lineas = data.cantidad_total_lineas;
                    object.denominacion_alerta = data.denominacion_alerta ? data.denominacion_alerta : null;
                    object.otra_denominacion_del_arte = data.otra_denominacion_del_arte;
                    object.cantidad_trampas_nasas = data.cantidad_trampas_nasas;
                    object.material_ppal_trampas = data.material_ppal_trampas ? data.material_ppal_trampas : null;
                    object.otro_material_ppal = data.otro_material_ppal;
                    object.tipo_artefactos = data.tipo_artefactos ? data.tipo_artefactos : null;
                    object.otro_tipo_artefacto = data.otro_tipo_artefacto;
                    object.cantidad_artefactos = data.cantidad_artefactos;
                    object.material_artefacto = data.material_artefacto ? data.material_artefacto : null;
                    object.otro_material_artefacto = data.otro_material_artefacto;
                    object.uso_dispositivos = data.uso_dispositivos ? data.uso_dispositivos : null;
                    object.tipo_fad_usados = data.tipo_fad_usados ? data.tipo_fad_usados : 'N/A';
                    object.otro_tipo_fad_usados = data.otro_tipo_fad_usados;
                    object.cantidad_fad_usados = data.cantidad_fad_usados;
                    object.componentes_fad = data.componentes_fad;
                    //tab6
                    object.cartas_navegacion = data.cartas_navegacion ? data.cartas_navegacion : 'N/A';
                    ;
                    object.compas_magnetico = data.compas_magnetico ? data.compas_magnetico : 'N/A';
                    ;
                    object.gps = data.gps ? data.gps : 'N/A';
                    ;
                    object.loran = data.loran ? data.loran : 'N/A';
                    ;
                    object.radar = data.radar ? data.radar : 'N/A';
                    ;
                    object.ecosonda = data.ecosonda ? data.ecosonda : 'N/A';
                    ;
                    object.radios_comunicacion = data.radios_comunicacion ? data.radios_comunicacion : 'N/A';
                    ;
                    //tab 7
                    object.firma_representante = data.signature;
                    object.fotos_embarcacion = data.fotos_embarcacion;
                    object.observations = data.observations;
                    //new
                    object.tipo_registro = data.tipo_registro;
                    object.tipo_propulsion = data.tipo_propulsion ? data.tipo_propulsion : null;
                    object.nombre_propietario = data.nombre_propietario;
                    object.tipo_identificacion = data.tipo_identificacion;
                    object.otro_tipo_identificacion = data.otro_tipo_identificacion;
                    object.numero_identificacion = data.numero_identificacion;
                    //new
                    object.calado = data.calado;
                    object.otra_unidad_potencia = data.otra_unidad_potencia;
                    object.otro_material_casco = data.otro_material_casco;
                    object.otro_tipo_conservacion = data.otro_tipo_conservacion;
                    object.radicado = data.radicado;
                    object.codigo_verificacion = data.codigo_verificacion;
                    object.nombre_representante = data.nombre_representante;
                    object.tipo_identificacion_representante = data.tipo_identificacion_representante;
                    object.otro_tipo_identificacion_representante = data.otro_tipo_identificacion_representante;
                    object.numero_identificacion_representante = data.numero_identificacion_representante;
                    object.cargo_representante = data.cargo_representante;
                    object.artes_de_pesca = data.artes_de_pesca;
                    object.otro_arte_pesca = data.otro_arte_pesca;
                    object.tiene_matricula = data.tiene_matricula;
                    object.puerto_desembarque = data.puerto_desembarque ? data.puerto_desembarque : null;
                    object.otro_puerto_desembarque = data.otro_puerto_desembarque;
                });
            }
            // alert(JSON.stringify(object.fotos_embarcacion, null, 2));
            const loading = yield this.loadingController.create({
                message: 'Cargando...',
                spinner: 'crescent',
                showBackdrop: true,
            });
            yield loading.present();
            this.api.getStoreArtesanals(object, "Bearer " + this.tokenUser).subscribe(response => {
                loading.dismiss();
                console.log(response[0]);
                if (response[0].codigo == 200) {
                    this.alertUploadArtesanal(response[0].message);
                    let items = this.dataStorageArtesanal.filter((item) => {
                        return item.id === registerID;
                    });
                    items.forEach((element) => {
                        var index = this.dataStorageArtesanal.indexOf(element);
                        this.dataStorageArtesanal.splice(index, 1);
                    });
                }
                else {
                    this.presentError(response[0].message);
                }
            }, err => {
                //console.log(err, this.tokenUser);
                loading.dismiss();
                if (err.status == '401') {
                    this.presentError("Tu sesión ha expirado, por favor inicia sesión nuevamente");
                    this.closeSession();
                    this.router.navigate(["login"]);
                }
                else {
                    this.presentError('No podemos procesar tu solicitud en este momento, intenta más tarde.');
                }
            });
        });
    }
    //uplad register server
    alertUploadArtesanal(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Confirmación',
                message: message,
                buttons: [
                    {
                        text: 'Aceptar',
                        handler: () => {
                            this.updateArtesanalArray();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    //upload industrial
    getStorePescador(registerID) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            let object = Object();
            let dataRegistersPescadores = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.get({ key: 'dataRegistersPescadores' });
            let responseObject = JSON.parse(dataRegistersPescadores.value);
            if (responseObject) {
                this.dataStoragePescador = responseObject;
                let items = this.dataStoragePescador.filter((item) => {
                    return item.id === registerID;
                });
                items.forEach((data) => {
                    //tab 1
                    object.department = data.department.codigo;
                    object.filed = data.filed;
                    object.filing_date = new Date(data.filing_date).toLocaleString();
                    //tab 2
                    object.copy_identification_document = data.copy_identification_document;
                    object.copy_occre = data.copy_occre;
                    object.copy_sisben = data.copy_sisben;
                    object.accreditation_certificate = data.accreditation_certificate;
                    object.certification_issued_by = data.certification_issued_by.id;
                    object.vigencia_permiso = data.vigencia_permiso;
                    object.expedition_date = data.expedition_date;
                    object.expiration_date = data.expiration_date;
                    //tab 3
                    object.fisherman_photo_file = data.photo;
                    object.name = data.name;
                    object.lastname = data.lastname;
                    object.type_of_card = data.type_of_card;
                    object.identification_number = data.identification_number;
                    object.occre = data.occre;
                    object.no_occre = data.no_occre;
                    object.nationality = data.nationality.codigo;
                    object.email = data.email;
                    object.address = data.address;
                    object.phone = data.phone;
                    object.organization_cooperative = data.organization_cooperative;
                    object.organization_name = data.organization_name.name;
                    //tab 4
                    object.landing_zone = data.dembarque_port.codigo;
                    object.frequent_fishing_area = data.zona_frecuente_pesca;
                    object.type_of_artesanal_boat = data.tipo_embarcacion_artesanal;
                    object.other_type_of_artesanal_boat = data.otro_tipo_embarcacion_artesanal;
                    object.types_fishery = data.tipo_pesqueria;
                    object.artes_pesca = data.artes_pesca;
                    //tab 5
                    object.report_boat = data.reporta_embarcacion;
                    object.propietario_embarcacion = data.propietario_embarcacion;
                    object.documento_acredita = data.documento_acredita;
                    object.data_boats = data.data_boats;
                    //tab six
                    object.birth_date = data.birthdate;
                    object.age = data.age;
                    object.gender = data.genre;
                    object.marital_status = data.marital_state;
                    object.other_marital_status = data.otro_marital_state;
                    object.read_and_write = data.read_write;
                    object.education_level = data.education_level;
                    object.other_education_level = data.otro_education_level;
                    object.own_house = data.own_home;
                    object.type_health_service = data.healt_service;
                    object.other_type_health_service = data.otro_healt_service;
                    object.fishing_time = data.pesca_time;
                    object.other_fishing_time = data.otro_pesca_time;
                    object.time_in_activity = data.dedication;
                    object.fishing_schedule = data.hour_pesca;
                    //tab seven
                    object.observations = data.observations;
                    object.estado = data.status;
                    object.update_date = data.update_date;
                    object.signature = data.signature;
                });
            }
            const loading = yield this.loadingController.create({
                message: 'Cargando...',
                spinner: 'crescent',
                showBackdrop: true,
            });
            yield loading.present();
            this.api.getStorePescador(object, "Bearer " + this.tokenUser).subscribe(response => {
                loading.dismiss();
                console.log(response[0]);
                if (response[0].id > 0) {
                    this.alertUploadPescador('Registro creado exitosamente en el servidor, será eliminado de la base de datos interna.');
                    let items = this.dataStoragePescador.filter((item) => {
                        return item.id === registerID;
                    });
                    items.forEach((element) => {
                        var index = this.dataStoragePescador.indexOf(element);
                        this.dataStoragePescador.splice(index, 1);
                    });
                }
                else {
                    this.presentError('Erro en la operación, intente más tarde');
                }
            }, err => {
                //console.log(err, this.tokenUser);
                loading.dismiss();
                if (err.status == '401') {
                    this.presentError("Tu sesión ha expirado, por favor inicia sesión nuevamente");
                    this.closeSession();
                    this.router.navigate(["login"]);
                }
                else {
                    this.presentError('No podemos procesar tu solicitud en este momento, intenta más tarde.');
                }
            });
        });
    }
    //uplad register server
    alertUploadPescador(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Confirmación',
                message: message,
                buttons: [
                    {
                        text: 'Aceptar',
                        handler: () => {
                            this.updatePescadoresArray();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    //close sessión
    closeSession() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.remove({ key: 'sessionPersistence' });
        });
    }
    updateIndustrialArray() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.set({
                key: 'dataRegistersIndustrial',
                value: JSON.stringify(this.dataStorage),
            }).then(() => {
                this.events.publish('updateRegisters', []);
            });
        });
    }
    updateArtesanalArray() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.set({
                key: 'dataRegistersArtesanal',
                value: JSON.stringify(this.dataStorageArtesanal),
            }).then(() => {
                this.events.publish('updateRegisters', []);
            });
        });
    }
    updatePescadoresArray() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.set({
                key: 'dataRegistersPescadores',
                value: JSON.stringify(this.dataStoragePescador),
            }).then(() => {
                this.events.publish('updateRegisters', []);
            });
        });
    }
    //alert with warning
    presentError(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Advertencia',
                message: message,
                backdropDismiss: false,
                buttons: ['OK']
            });
            yield alert.present();
        });
    }
};
RegistersPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController },
    { type: src_app_services_api_rest_service__WEBPACK_IMPORTED_MODULE_2__.ApiRestService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.NgZone },
    { type: _config_events__WEBPACK_IMPORTED_MODULE_3__.Events }
];
RegistersPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-registers',
        template: _registers_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_registers_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], RegistersPage);



/***/ }),

/***/ 1346:
/*!****************************************************************!*\
  !*** ./src/app/components/menu/menu.component.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "ion-header ion-toolbar {\n  --background: #2f6da8; /* Old browsers */\n  --background: -moz-linear-gradient(left, #2f6da8 0%, #3192c8 76%, #73ad7d 100%); /* FF3.6-15 */\n  --background: -webkit-linear-gradient(left, #2f6da8 0%,#3192c8 76%,#73ad7d 100%); /* Chrome10-25,Safari5.1-6 */\n  --background: linear-gradient(to right, #2f6da8 0%,#3192c8 76%,#73ad7d 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  padding-top: 30px;\n  padding-bottom: 10px;\n}\nion-header ion-toolbar ion-title {\n  font-family: \"Poppins\", sans-serif;\n  color: #ffffff;\n  text-align: center;\n}\nion-header ion-toolbar ion-menu-button {\n  --color: #FFFFFF;\n}\nion-header ion-toolbar ion-back-button {\n  --color: #FFFFFF;\n}\nion-header ion-toolbar img {\n  width: 25px;\n  margin-right: 10px;\n}\nion-header ion-toolbar ion-icon {\n  color: #ffffff;\n  font-size: 24px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lbnUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDSSxxQkFBQSxFQUFBLGlCQUFBO0VBQ0EsK0VBQUEsRUFBQSxhQUFBO0VBQ0EsZ0ZBQUEsRUFBQSw0QkFBQTtFQUNBLDRFQUFBLEVBQUEscURBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0FBQVI7QUFDUTtFQUNJLGtDQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBQ1o7QUFDUTtFQUNJLGdCQUFBO0FBQ1o7QUFDUTtFQUNJLGdCQUFBO0FBQ1o7QUFDUTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtBQUNaO0FBQ1E7RUFDSSxjQUFBO0VBQ0EsZUFBQTtBQUNaIiwiZmlsZSI6Im1lbnUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVye1xyXG4gICAgaW9uLXRvb2xiYXJ7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjMmY2ZGE4OyAvKiBPbGQgYnJvd3NlcnMgKi9cclxuICAgICAgICAtLWJhY2tncm91bmQ6IC1tb3otbGluZWFyLWdyYWRpZW50KGxlZnQsICMyZjZkYTggMCUsICMzMTkyYzggNzYlLCAjNzNhZDdkIDEwMCUpOyAvKiBGRjMuNi0xNSAqL1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQobGVmdCwgIzJmNmRhOCAwJSwjMzE5MmM4IDc2JSwjNzNhZDdkIDEwMCUpOyAvKiBDaHJvbWUxMC0yNSxTYWZhcmk1LjEtNiAqL1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjMmY2ZGE4IDAlLCMzMTkyYzggNzYlLCM3M2FkN2QgMTAwJSk7IC8qIFczQywgSUUxMCssIEZGMTYrLCBDaHJvbWUyNissIE9wZXJhMTIrLCBTYWZhcmk3KyAqL1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAzMHB4O1xyXG4gICAgICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gICAgICAgIGlvbi10aXRsZXtcclxuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgICAgICAgICAgY29sb3I6ICNmZmZmZmY7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaW9uLW1lbnUtYnV0dG9ue1xyXG4gICAgICAgICAgICAtLWNvbG9yOiAjRkZGRkZGO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpb24tYmFjay1idXR0b257XHJcbiAgICAgICAgICAgIC0tY29sb3I6ICNGRkZGRkY7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGltZ3tcclxuICAgICAgICAgICAgd2lkdGg6IDI1cHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaW9uLWljb257XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il19 */";

/***/ }),

/***/ 9586:
/*!****************************************************************!*\
  !*** ./src/app/pages/registers/registers.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "@charset \"UTF-8\";\nion-content {\n  --background: #FAFAFA;\n  background: #FAFAFA;\n}\nion-content ion-grid.headerGrid {\n  position: fixed;\n  width: 100%;\n  z-index: 99999;\n}\nion-content ion-grid.headerGrid ion-row {\n  padding: 20px;\n  background: #fff;\n  border-bottom: 2px solid  #e6e6e6;\n}\nion-content ion-grid.headerGrid ion-row ion-col.active {\n  border-bottom: 3px solid #FED610;\n  padding-bottom: 5px;\n}\nion-content ion-grid.headerGrid ion-row ion-col ion-text {\n  font-family: \"Poppins\", sans-serif;\n}\nion-content ion-grid.headerGrid ion-row ion-col ion-text.active {\n  color: #000043;\n}\nion-content ion-grid.headerGrid ion-row ion-col ion-text.inactive {\n  color: #DBDBDB;\n  border-bottom: 0;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid.headerGrid ion-row ion-col ion-text {\n    font-size: 14px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid.headerGrid ion-row ion-col ion-text {\n    font-size: 16px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid.headerGrid ion-row ion-col ion-text {\n    font-size: 20px;\n  }\n}\nion-content ion-grid ion-row.marginInitial {\n  margin-top: 110px;\n}\nion-content ion-grid ion-row.marginTop {\n  margin-top: 10px;\n}\nion-content ion-grid ion-row ion-col ion-button {\n  font-family: \"Poppins\", sans-serif;\n  --border-radius: 50px;\n  --background: #2f6da8; /* Old browsers */\n  --background: -moz-linear-gradient(left, #2f6da8 0%, #3192c8 76%, #73ad7d 100%); /* FF3.6-15 */\n  --background: -webkit-linear-gradient(left, #2f6da8 0%,#3192c8 76%,#73ad7d 100%); /* Chrome10-25,Safari5.1-6 */\n  --background: linear-gradient(to right, #2f6da8 0%,#3192c8 76%,#73ad7d 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  --background-activated: #006fa6;\n  --background-focused: #006fa6;\n  --background-hover: #006fa6;\n  min-width: 80%;\n  font-size: 16px;\n}\nion-content ion-grid ion-row ion-col ion-card.specialCard {\n  padding-bottom: 30px;\n}\nion-content ion-grid ion-row ion-col ion-card ion-icon.detail {\n  background-color: #3192c8;\n  color: #ffffff;\n  font-size: 20px;\n  padding: 5px;\n  border-radius: 50%;\n  position: absolute;\n  top: 5px;\n  right: 5px;\n}\nion-content ion-grid ion-row ion-col ion-card ion-icon.trash {\n  background-color: red;\n  color: #ffffff;\n  font-size: 20px;\n  padding: 5px;\n  border-radius: 50%;\n  position: absolute;\n  top: 65px;\n  right: 5px;\n}\nion-content ion-grid ion-row ion-col ion-card div {\n  display: flex;\n  align-items: center;\n  margin-top: 10px;\n  width: 50px;\n  height: 50px;\n  overflow: hidden;\n  border-radius: 50%;\n}\nion-content ion-grid ion-row ion-col ion-card div img {\n  display: block;\n  object-fit: cover;\n  width: 100%;\n  height: 100%;\n}\nion-content ion-grid ion-row ion-col ion-card img.imgCircle {\n  margin: 20px 0 0 10px;\n  border-radius: 50%;\n  max-width: 90%;\n  border: 2px solid #FED610;\n}\nion-content ion-grid ion-row ion-col ion-card img.imgIcon {\n  width: 15px;\n}\nion-content ion-grid ion-row ion-col ion-card img.imgButton {\n  width: 30px;\n}\nion-content ion-grid ion-row ion-col ion-card ion-item {\n  margin: 0;\n  padding: 0;\n  --padding-start: 0;\n  --padding-end: 0;\n  margin: 0;\n}\nion-content ion-grid ion-row ion-col ion-card ion-text {\n  font-family: \"Poppins\", sans-serif;\n  margin: 0;\n}\nion-content ion-grid ion-row ion-col ion-card ion-text h1 {\n  margin-bottom: 0;\n  color: #414141;\n  font-weight: lighter;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h1 {\n    font-size: 18px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h1 {\n    font-size: 20px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h1 {\n    font-size: 25px;\n  }\n}\nion-content ion-grid ion-row ion-col ion-card ion-text h4 {\n  margin: 0 0 0 10px;\n  color: #414141;\n  font-weight: lighter;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h4 {\n    font-size: 13px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h4 {\n    font-size: 14px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h4 {\n    font-size: 18px;\n  }\n}\nion-content ion-grid ion-row ion-col ion-card ion-text h4 span {\n  font-weight: normal;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h4 span {\n    font-size: 16px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h4 span {\n    font-size: 17px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text h4 span {\n    font-size: 21px;\n  }\n}\nion-content ion-grid ion-row ion-col ion-card ion-text h4 span.pending {\n  color: red;\n}\nion-content ion-grid ion-row ion-col ion-card ion-text h4 span.firmed {\n  color: #994F00;\n}\nion-content ion-grid ion-row ion-col ion-card ion-text h4 span.upload {\n  color: #168500;\n}\nion-content ion-grid ion-row ion-col ion-card ion-text p {\n  margin: 5px 0 0;\n  color: #414141;\n  font-weight: normal;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text p {\n    font-size: 11px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text p {\n    font-size: 12px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-text p {\n    font-size: 15px;\n  }\n}\nion-content ion-grid ion-row ion-col ion-card ion-button {\n  font-family: \"Poppins\", sans-serif;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-button {\n    font-size: 12px;\n    width: 90%;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-button {\n    font-size: 13px;\n    width: 90%;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid ion-row ion-col ion-card ion-button {\n    min-width: 90%;\n  }\n}\nion-content ion-grid ion-row ion-col ion-card ion-button.upload {\n  --color: #ffffff;\n  --background: #2f6da8; /* Old browsers */\n  --background: -moz-linear-gradient(left, #2f6da8 0%, #3192c8 76%, #73ad7d 100%); /* FF3.6-15 */\n  --background: -webkit-linear-gradient(left, #2f6da8 0%,#3192c8 76%,#73ad7d 100%); /* Chrome10-25,Safari5.1-6 */\n  --background: linear-gradient(to right, #2f6da8 0%,#3192c8 76%,#73ad7d 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  --background-activated: #006fa6;\n  --background-focused: #006fa6;\n  --background-hover: #006fa6;\n}\nion-content ion-grid ion-row ion-col ion-card ion-button.edit {\n  --background: #bad320;\n  --background-activated: #869819;\n  --background-focused: #869819;\n  --background-hover: #869819;\n  --color: #000015;\n}\nion-content ion-row#templateAlt {\n  margin: 20px 20px 0;\n}\nion-content ion-row#templateAlt ion-text {\n  font-family: \"Poppins\", sans-serif;\n  color: #414141;\n}\n@media (min-width: 319px) {\n  ion-content ion-row#templateAlt ion-text {\n    font-size: 14px;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-row#templateAlt ion-text {\n    font-size: 16px;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-row#templateAlt ion-text {\n    font-size: 20px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZ2lzdGVycy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCO0FBQWhCO0VBQ0kscUJBQUE7RUFDQSxtQkFBQTtBQUVKO0FBQVE7RUFDSSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7QUFFWjtBQURZO0VBQ0ksYUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUNBQUE7QUFHaEI7QUFEb0I7RUFDSSxnQ0FBQTtFQUNBLG1CQUFBO0FBR3hCO0FBRG9CO0VBQ0ksa0NBQUE7QUFHeEI7QUFGd0I7RUFDSSxjQUFBO0FBSTVCO0FBRndCO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0FBSTVCO0FBRndCO0VBVEo7SUFVUSxlQUFBO0VBSzFCO0FBQ0Y7QUFKd0I7RUFaSjtJQWFRLGVBQUE7RUFPMUI7QUFDRjtBQU53QjtFQWZKO0lBZ0JRLGVBQUE7RUFTMUI7QUFDRjtBQUhZO0VBQ0ksaUJBQUE7QUFLaEI7QUFIWTtFQUNJLGdCQUFBO0FBS2hCO0FBRmdCO0VBQ0ksa0NBQUE7RUFDQSxxQkFBQTtFQUNBLHFCQUFBLEVBQUEsaUJBQUE7RUFDQSwrRUFBQSxFQUFBLGFBQUE7RUFDQSxnRkFBQSxFQUFBLDRCQUFBO0VBQ0EsNEVBQUEsRUFBQSxxREFBQTtFQUNBLCtCQUFBO0VBQ0EsNkJBQUE7RUFDQSwyQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FBSXBCO0FBRG9CO0VBQ0ksb0JBQUE7QUFHeEI7QUFBd0I7RUFDSSx5QkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0VBQ0EsVUFBQTtBQUU1QjtBQUF3QjtFQUNJLHFCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0FBRTVCO0FBQ29CO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUFDeEI7QUFBd0I7RUFDSSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUU1QjtBQUV3QjtFQUNJLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EseUJBQUE7QUFBNUI7QUFFd0I7RUFDSSxXQUFBO0FBQTVCO0FBRXdCO0VBQ0ksV0FBQTtBQUE1QjtBQUdvQjtFQUNJLFNBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLFNBQUE7QUFEeEI7QUFHb0I7RUFDSSxrQ0FBQTtFQUNBLFNBQUE7QUFEeEI7QUFFd0I7RUFDSSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxvQkFBQTtBQUE1QjtBQUM0QjtFQUpKO0lBS1EsZUFBQTtFQUU5QjtBQUNGO0FBRDRCO0VBUEo7SUFRUSxlQUFBO0VBSTlCO0FBQ0Y7QUFINEI7RUFWSjtJQVdRLGVBQUE7RUFNOUI7QUFDRjtBQUp3QjtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLG9CQUFBO0FBTTVCO0FBTDRCO0VBSko7SUFLUSxlQUFBO0VBUTlCO0FBQ0Y7QUFQNEI7RUFQSjtJQVFRLGVBQUE7RUFVOUI7QUFDRjtBQVQ0QjtFQVZKO0lBV1EsZUFBQTtFQVk5QjtBQUNGO0FBWDRCO0VBQ0ksbUJBQUE7QUFhaEM7QUFaZ0M7RUFGSjtJQUdRLGVBQUE7RUFlbEM7QUFDRjtBQWRnQztFQUxKO0lBTVEsZUFBQTtFQWlCbEM7QUFDRjtBQWhCZ0M7RUFSSjtJQVNRLGVBQUE7RUFtQmxDO0FBQ0Y7QUFsQmdDO0VBQ0ksVUFBQTtBQW9CcEM7QUFsQmdDO0VBQ0ksY0FBQTtBQW9CcEM7QUFsQmdDO0VBQ0ksY0FBQTtBQW9CcEM7QUFoQndCO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtBQWtCNUI7QUFqQjRCO0VBSko7SUFLUSxlQUFBO0VBb0I5QjtBQUNGO0FBbkI0QjtFQVBKO0lBUVEsZUFBQTtFQXNCOUI7QUFDRjtBQXJCNEI7RUFWSjtJQVdRLGVBQUE7RUF3QjlCO0FBQ0Y7QUFyQm9CO0VBQ0ksa0NBQUE7QUF1QnhCO0FBdEJ3QjtFQUZKO0lBR1EsZUFBQTtJQUNBLFVBQUE7RUF5QjFCO0FBQ0Y7QUF4QndCO0VBTko7SUFPUSxlQUFBO0lBQ0EsVUFBQTtFQTJCMUI7QUFDRjtBQTFCd0I7RUFWSjtJQVdRLGNBQUE7RUE2QjFCO0FBQ0Y7QUE1QndCO0VBQ0ksZ0JBQUE7RUFDQSxxQkFBQSxFQUFBLGlCQUFBO0VBQ0EsK0VBQUEsRUFBQSxhQUFBO0VBQ0EsZ0ZBQUEsRUFBQSw0QkFBQTtFQUNBLDRFQUFBLEVBQUEscURBQUE7RUFDQSwrQkFBQTtFQUNBLDZCQUFBO0VBQ0EsMkJBQUE7QUE4QjVCO0FBNUJ3QjtFQUNJLHFCQUFBO0VBQ0EsK0JBQUE7RUFDQSw2QkFBQTtFQUNBLDJCQUFBO0VBQ0EsZ0JBQUE7QUE4QjVCO0FBdkJJO0VBQ0ksbUJBQUE7QUF5QlI7QUF4QlE7RUFDSSxrQ0FBQTtFQUNBLGNBQUE7QUEwQlo7QUF6Qlk7RUFISjtJQUlRLGVBQUE7RUE0QmQ7QUFDRjtBQTNCWTtFQU5KO0lBT1EsZUFBQTtFQThCZDtBQUNGO0FBN0JZO0VBVEo7SUFVUSxlQUFBO0VBZ0NkO0FBQ0YiLCJmaWxlIjoicmVnaXN0ZXJzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjRkFGQUZBO1xyXG4gICAgYmFja2dyb3VuZDogI0ZBRkFGQTtcclxuICAgIGlvbi1ncmlke1xyXG4gICAgICAgICYuaGVhZGVyR3JpZHtcclxuICAgICAgICAgICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgei1pbmRleDogOTk5OTk7XHJcbiAgICAgICAgICAgIGlvbi1yb3d7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAyMHB4O1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDJweCBzb2xpZMKgI2U2ZTZlNjtcclxuICAgICAgICAgICAgICAgIGlvbi1jb2x7XHJcbiAgICAgICAgICAgICAgICAgICAgJi5hY3RpdmV7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDNweCBzb2xpZCAjRkVENjEwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogNXB4O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpb24tdGV4dHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgJi5hY3RpdmV7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzAwMDA0MztcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAmLmluYWN0aXZle1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICNEQkRCREI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAzMTlweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAzNzRweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiA0MTVweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSAgIFxyXG4gICAgICAgIGlvbi1yb3d7XHJcbiAgICAgICAgICAgICYubWFyZ2luSW5pdGlhbHtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDExMHB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICYubWFyZ2luVG9we1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpb24tY29se1xyXG4gICAgICAgICAgICAgICAgaW9uLWJ1dHRvbntcclxuICAgICAgICAgICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG4gICAgICAgICAgICAgICAgICAgIC0tYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6ICMyZjZkYTg7IC8qIE9sZCBicm93c2VycyAqL1xyXG4gICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZDogLW1vei1saW5lYXItZ3JhZGllbnQobGVmdCwgIzJmNmRhOCAwJSwgIzMxOTJjOCA3NiUsICM3M2FkN2QgMTAwJSk7IC8qIEZGMy42LTE1ICovXHJcbiAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOiAtd2Via2l0LWxpbmVhci1ncmFkaWVudChsZWZ0LCAjMmY2ZGE4IDAlLCMzMTkyYzggNzYlLCM3M2FkN2QgMTAwJSk7IC8qIENocm9tZTEwLTI1LFNhZmFyaTUuMS02ICovXHJcbiAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICMyZjZkYTggMCUsIzMxOTJjOCA3NiUsIzczYWQ3ZCAxMDAlKTsgLyogVzNDLCBJRTEwKywgRkYxNissIENocm9tZTI2KywgT3BlcmExMissIFNhZmFyaTcrICovXHJcbiAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogICMwMDZmYTY7XHJcbiAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6ICMwMDZmYTY7XHJcbiAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjMDA2ZmE2O1xyXG4gICAgICAgICAgICAgICAgICAgIG1pbi13aWR0aDogODAlO1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlvbi1jYXJke1xyXG4gICAgICAgICAgICAgICAgICAgICYuc3BlY2lhbENhcmR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiAzMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpb24taWNvbntcclxuICAgICAgICAgICAgICAgICAgICAgICAgJi5kZXRhaWx7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzE5MmM4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICNmZmZmZmY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiA1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3A6IDVweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJpZ2h0OiA1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgJi50cmFzaHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJlZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogNXB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9wOiA2NXB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmlnaHQ6IDVweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBkaXZ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiA1MHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDUwcHg7IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGltZ3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpbWd7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICYuaW1nQ2lyY2xle1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAyMHB4IDAgMCAxMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4LXdpZHRoOiA5MCU7ICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogMnB4IHNvbGlkICNGRUQ2MTA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgJi5pbWdJY29ue1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDE1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgJi5pbWdCdXR0b257XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogMzBweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpb24taXRlbXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAtLXBhZGRpbmctc3RhcnRcdDogMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLS1wYWRkaW5nLWVuZDogMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpb24tdGV4dHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBoMXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzQxNDE0MTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBsaWdodGVyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDMxOXB4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDM3NHB4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDQxNXB4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAyNXB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGg0e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwIDAgMCAxMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM0MTQxNDE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogbGlnaHRlcjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAzMTlweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAzNzRweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiA0MTVweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNwYW57XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogMzE5cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogMzc0cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxN3B4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogNDE1cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAyMXB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAmLnBlbmRpbmd7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiByZWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICYuZmlybWVke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzk5NEYwMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJi51cGxvYWR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjMTY4NTAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDVweCAwIDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzQxNDE0MTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogMzE5cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDExcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogMzc0cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogNDE1cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlvbi1idXR0b257XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAzMTlweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDkwJTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogMzc0cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiA5MCU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDQxNXB4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW4td2lkdGg6IDkwJTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAmLnVwbG9hZHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC0tY29sb3I6ICNmZmZmZmY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6ICMyZjZkYTg7IC8qIE9sZCBicm93c2VycyAqL1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOiAtbW96LWxpbmVhci1ncmFkaWVudChsZWZ0LCAjMmY2ZGE4IDAlLCAjMzE5MmM4IDc2JSwgIzczYWQ3ZCAxMDAlKTsgLyogRkYzLjYtMTUgKi9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZDogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQobGVmdCwgIzJmNmRhOCAwJSwjMzE5MmM4IDc2JSwjNzNhZDdkIDEwMCUpOyAvKiBDaHJvbWUxMC0yNSxTYWZhcmk1LjEtNiAqL1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICMyZjZkYTggMCUsIzMxOTJjOCA3NiUsIzczYWQ3ZCAxMDAlKTsgLyogVzNDLCBJRTEwKywgRkYxNissIENocm9tZTI2KywgT3BlcmExMissIFNhZmFyaTcrICovXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAgIzAwNmZhNjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZC1mb2N1c2VkOiAjMDA2ZmE2O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjMDA2ZmE2O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICYuZWRpdHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZDogI2JhZDMyMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICAjODY5ODE5O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6ICM4Njk4MTk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQtaG92ZXI6ICM4Njk4MTk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAtLWNvbG9yOiAjMDAwMDE1O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgaW9uLXJvdyN0ZW1wbGF0ZUFsdHtcclxuICAgICAgICBtYXJnaW46IDIwcHggMjBweCAwO1xyXG4gICAgICAgIGlvbi10ZXh0e1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG4gICAgICAgICAgICBjb2xvcjogIzQxNDE0MTtcclxuICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDMxOXB4KSB7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDM3NHB4KSB7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDQxNXB4KSB7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0iXX0= */";

/***/ }),

/***/ 2574:
/*!****************************************************************!*\
  !*** ./src/app/components/menu/menu.component.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\r\n    <ion-toolbar>\r\n        <img src=\"../../../assets/resources/ico-filter.png\" slot=\"end\" *ngIf=\"isFilterVisible=='true'\"> \r\n        <ion-buttons slot=\"start\" *ngIf=\"isBackVisible=='true'\">\r\n            <ion-back-button text=\"\" defaultHref=\"registers\"></ion-back-button>\r\n        </ion-buttons>\r\n        <ion-buttons slot=\"start\" *ngIf=\"isCloseVisible=='true'\">\r\n            <ion-icon name=\"close\" (click)=\"closeView()\"></ion-icon>\r\n        </ion-buttons>\r\n        <ion-buttons slot=\"start\" *ngIf=\"isBackItemVisible=='true'\">\r\n            <ion-back-button text=\"\" defaultHref=\"/\"></ion-back-button>\r\n        </ion-buttons>\r\n        <ion-buttons slot=\"end\" *ngIf=\"isMenuVisible=='true'\">\r\n            <ion-menu-button></ion-menu-button>\r\n        </ion-buttons>\r\n        <ion-title>\r\n            {{ TitleBar }}\r\n        </ion-title>\r\n    </ion-toolbar>\r\n</ion-header>";

/***/ }),

/***/ 7286:
/*!****************************************************************!*\
  !*** ./src/app/pages/registers/registers.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<app-menu TitleBar=\"Listado de Inspecciones\" isMenuVisible=\"true\" isBackVisible=\"false\"></app-menu>\r\n\r\n<ion-content>\r\n\r\n    <!-- header fixed -->\r\n    <ion-grid class=\"ion-no-padding ion-no-margin headerGrid\">\r\n        <ion-row class=\"ion-no-padding ion-no-margin\" align=\"center\">\r\n            <ion-col class=\"ion-no-padding ion-no-margin {{ typeSelected==1 ? 'active' : null }}\">\r\n                <ion-text [ngClass]=\"typeSelected==1 ? 'active' : 'inactive'\" (click)=\"changeTab(1)\">\r\n                    Pesca Industrial\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col class=\"ion-no-padding ion-no-margin {{ typeSelected==2 ? 'active' : null }}\">\r\n                <ion-text [ngClass]=\"typeSelected==2 ? 'active' : 'inactive'\" (click)=\"changeTab(2)\">\r\n                    Pesca Artesanal\r\n                </ion-text>\r\n            </ion-col>\r\n            <ion-col class=\"ion-no-padding ion-no-margin {{ typeSelected==3 ? 'active' : null }}\">\r\n                <ion-text [ngClass]=\"typeSelected==3 ? 'active' : 'inactive'\" (click)=\"changeTab(3)\">\r\n                    Pescador Artesanal\r\n                </ion-text>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- first tab -->\r\n    <ion-grid *ngIf=\"typeSelected===1\">\r\n        <ion-row class=\"marginInitial\">\r\n            <ion-col align=\"center\">\r\n                <ion-button (click)=\"goToIndustrial(0)\">\r\n                    Nueva Inspección / Registro\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row *ngIf=\"data && data.length > 0 ; else showNoInfo\">\r\n            <ion-col>\r\n                <ion-card *ngFor=\"let item of data; let i=index\">\r\n                    <ion-row class=\"justify-content-center align-items-center\">\r\n                        <ion-col size=\"2\">\r\n                            <img src=\"../../../assets/images/barco.png\" class=\"imgCircle\">\r\n                        </ion-col>\r\n                        <ion-col size=\"9\">\r\n                            <ion-row>\r\n                                <ion-col>\r\n                                    <ion-text>\r\n                                        <h1>\r\n                                            {{ item.nombre_barco ? item.nombre_barco : 'Indefinido' }}\r\n                                        </h1>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                            </ion-row>\r\n                            <ion-row>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <img src=\"../../../assets/images/user.png\" class=\"imgIcon\">\r\n                                        <ion-text>\r\n                                            <h4><b>Administrador</b></h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                    <ion-text>\r\n                                        <h4>{{ item.nombre_admin_agencia ? item.nombre_admin_agencia : 'Indefinido' }}\r\n                                        </h4>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <img src=\"../../../assets/images/build.png\" class=\"imgIcon\">\r\n                                        <ion-text>\r\n                                            <h4><b>Empresa</b></h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                    <ion-text>\r\n                                        <h4>{{ item.permisionario ? item.permisionario : 'Indefinido' }}\r\n                                        </h4>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <img src=\"../../../assets/images/map.png\" class=\"imgIcon\">\r\n                                        <ion-text>\r\n                                            <h4><b>Lugar Registro</b></h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                    <ion-text>\r\n                                        <h4>{{ item.lugar_matricula ? item.lugar_matricula : 'Indefinido' }}\r\n                                        </h4>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <img src=\"../../../assets/images/calendar.png\" class=\"imgIcon\">\r\n                                        <ion-text>\r\n                                            <h4><b>Solicitud de Inspección</b></h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                    <ion-text>\r\n                                        <h4>{{ item.fecha_matricula ? item.fecha_matricula : 'Indefinido' }}\r\n                                        </h4>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <ion-text>\r\n                                            <h4>\r\n                                                <b>Estado: </b>\r\n                                                <span\r\n                                                    [ngClass]=\"item.status == 1 ? 'pending' : item.status == 2 ? 'firmed' : 'upload'\">\r\n                                                    {{ item.status == 1 ? ' Pendiente' : item.status == 2 ? ' Firmado' : ' Guardado' }}\r\n                                                </span>\r\n                                            </h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                </ion-col>\r\n                            </ion-row>\r\n                        </ion-col>\r\n                        <ion-icon name=\"ellipsis-vertical-outline\" class=\"detail\" (click)=\"detailIndustrial(item.id)\"></ion-icon>\r\n                        <ion-icon name=\"trash-outline\" class=\"trash\" (click)=\"deleteIndustrial(item.id)\"></ion-icon>\r\n                    </ion-row>\r\n                    <ion-row align=\"center\">\r\n                        <ion-col>\r\n                            <ion-button class=\"edit\" (click)=\"goToIndustrial(item.id)\"\r\n                                [disabled]=\"item.status!=1\" >\r\n                                Editar Registro\r\n                            </ion-button>\r\n                        </ion-col>\r\n                        <ion-col>\r\n                            <ion-button class=\"upload\" (click)=\"getStoreIndustrials(item.id)\"\r\n                             [disabled]=\"item.status==1 || item.status == 3\" \r\n                                >\r\n                                Subir Registro\r\n                            </ion-button>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                </ion-card>\r\n\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- second tab -->\r\n    <ion-grid *ngIf=\"typeSelected===2\">\r\n        <ion-row class=\"marginInitial\">\r\n            <ion-col align=\"center\">\r\n                <ion-button (click)=\"goToArtesanal(0)\">\r\n                    Nueva Inspección / Registro\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row *ngIf=\"dataArtesanal && dataArtesanal.length > 0 ; else showNoInfo\">\r\n            <ion-col>\r\n                <ion-card *ngFor=\"let item of dataArtesanal; let i=index\">\r\n                    <ion-row class=\"justify-content-center align-items-center\">\r\n                        <ion-col size=\"2\">\r\n                            <img src=\"../../../assets/images/barco.png\" class=\"imgCircle\">\r\n                        </ion-col>\r\n                        <ion-col size=\"9\">\r\n                            <ion-row>\r\n                                <ion-col>\r\n                                    <ion-text>\r\n                                        <h1>\r\n                                            {{ item.nombre_barco ? item.nombre_barco : 'Indefinido' }}\r\n                                        </h1>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                            </ion-row>\r\n                            <ion-row>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <img src=\"../../../assets/images/user.png\" class=\"imgIcon\">\r\n                                        <ion-text>\r\n                                            <h4><b>Administrador</b></h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                    <ion-text>\r\n                                        <h4>{{ item.nombre_admin_agencia ? item.nombre_admin_agencia : 'Indefinido' }}\r\n                                        </h4>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <img src=\"../../../assets/images/build.png\" class=\"imgIcon\">\r\n                                        <ion-text>\r\n                                            <h4><b>Empresa</b></h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                    <ion-text>\r\n                                        <h4>{{ item.permisionario ? item.permisionario : 'Indefinido' }}\r\n                                        </h4>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <img src=\"../../../assets/images/map.png\" class=\"imgIcon\">\r\n                                        <ion-text>\r\n                                            <h4><b>Lugar Registro</b></h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                    <ion-text>\r\n                                        <h4>{{ item.lugar_matricula ? item.lugar_matricula : 'Indefinido' }}\r\n                                        </h4>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <img src=\"../../../assets/images/calendar.png\" class=\"imgIcon\">\r\n                                        <ion-text>\r\n                                            <h4><b>Solicitud de Inspección</b></h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                    <ion-text>\r\n                                        <h4>{{ item.fecha_matricula ? item.fecha_matricula : 'Indefinido' }}\r\n                                        </h4>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <ion-text>\r\n                                            <h4>\r\n                                                <b>Estado: </b>\r\n                                                <span\r\n                                                    [ngClass]=\"item.status == 1 ? 'pending' : item.status == 2 ? 'firmed' : 'upload'\">\r\n                                                    {{ item.status == 1 ? ' Pendiente' : item.status == 2 ? ' Firmado' : ' Guardado' }}\r\n                                                </span>\r\n                                            </h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                </ion-col>\r\n                            </ion-row>\r\n                        </ion-col>\r\n                        <ion-icon name=\"ellipsis-vertical-outline\" class=\"detail\" (click)=\"detailArtesanal(item.id)\"></ion-icon>\r\n                        <ion-icon name=\"trash-outline\" class=\"trash\" (click)=\"deleteArtesanals(item.id)\"></ion-icon>\r\n                    </ion-row>\r\n                    <ion-row align=\"center\">\r\n                        <ion-col>\r\n                            <ion-button class=\"edit\" (click)=\"goToArtesanal(item.id)\"  [disabled]=\"item.status!=1\">\r\n                                Editar Registro\r\n                            </ion-button>\r\n                        </ion-col>\r\n                        <ion-col>\r\n                            <ion-button class=\"upload\" (click)=\"getStoreArtesanal(item.id)\"\r\n                            [disabled]=\"item.status==1 || item.status == 3\" \r\n                            >\r\n                                Subir Registro\r\n                            </ion-button>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                </ion-card>\r\n\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- third tab -->\r\n    <ion-grid *ngIf=\"typeSelected===3\">\r\n        <ion-row class=\"marginInitial\">\r\n            <ion-col align=\"center\">\r\n                <ion-button (click)=\"goToPescador(0)\">\r\n                    Nuevo pescador / Registro\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row *ngIf=\"dataPescador && dataPescador.length > 0 ; else showNoInfo\">\r\n            <ion-col>\r\n                <ion-card *ngFor=\"let item of dataPescador; let i=index\">\r\n                    <ion-row class=\"justify-content-center align-items-center\">\r\n                        <ion-col size=\"2\">\r\n                            <div>\r\n                                <!-- <img src=\"{{ item.photo ? item.photo : 'assets/images/barco.png' }}\"> -->\r\n                                <img src=\"https://backend.rgpsai.org/storage/fishermen/{{ item.photo }}\" class=\"imgAdd\"/>\r\n                            </div>\r\n                        </ion-col>\r\n                        <ion-col size=\"9\">\r\n                            <ion-row>\r\n                                <ion-col>\r\n                                    <ion-text>\r\n                                        <h1>\r\n                                            {{ item.name }}  {{ item.lastname }}\r\n                                        </h1>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                            </ion-row>\r\n                            <ion-row>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <img src=\"../../../assets/images/build.png\" class=\"imgIcon\">\r\n                                        <ion-text>\r\n                                            <h4><b>Documento</b></h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                    <ion-text>\r\n                                        <h4>\r\n                                            {{ item.type_of_card ? item.type_of_card : 'Indefinido' }}\r\n                                            - {{ item.identification_number ? item.identification_number : 'Indefinido' }}\r\n                                        </h4>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <img src=\"../../../assets/images/map.png\" class=\"imgIcon\">\r\n                                        <ion-text>\r\n                                            <h4><b>Municipio</b></h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                    <ion-text>\r\n                                        <h4>{{ item.department ? item.department.nombre : 'Indefinido' }}\r\n                                        </h4>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <img src=\"../../../assets/images/calendar.png\" class=\"imgIcon\">\r\n                                        <ion-text>\r\n                                            <h4><b>Fecha actualización</b></h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                    <ion-text>\r\n                                        <h4>\r\n                                            {{ item.update_date ? item.update_date : 'Indefinido' }}\r\n                                        </h4>\r\n                                    </ion-text>\r\n                                </ion-col>\r\n                                <ion-col size-md=\"6\" size-xs=\"12\">\r\n                                    <ion-item lines=\"none\">\r\n                                        <ion-text>\r\n                                            <h4>\r\n                                                <b>Estado: </b>\r\n                                                <span\r\n                                                    [ngClass]=\"item.status == 1 ? 'pending' : item.status == 2 ? 'firmed' : 'upload'\">\r\n                                                    {{ item.status == 1 ? ' Pendiente' : item.status == 2 ? ' Firmado' : ' Guardado' }}\r\n                                                </span>\r\n                                            </h4>\r\n                                        </ion-text>\r\n                                    </ion-item>\r\n                                </ion-col>\r\n                            </ion-row>\r\n                        </ion-col>\r\n                        <ion-icon name=\"ellipsis-vertical-outline\" class=\"detail\" (click)=\"detailPescador(item.id)\"></ion-icon>\r\n                        <ion-icon name=\"trash-outline\" class=\"trash\" (click)=\"deletePescador(item.id)\"></ion-icon>\r\n                    </ion-row>\r\n                    <ion-row align=\"center\">\r\n                        <ion-col>\r\n                            <ion-button class=\"edit\" (click)=\"goToPescador(item.id)\" >\r\n                                Editar Registro\r\n                            </ion-button>\r\n                        </ion-col>\r\n                        <ion-col>\r\n                            <ion-button class=\"upload\" (click)=\"getStorePescador(item.id)\"\r\n                            [disabled]=\"item.status==1 || item.status == 3\" \r\n                            >\r\n                                Subir Registro\r\n                            </ion-button>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                </ion-card>\r\n\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <!-- info not found -->\r\n    <ng-template #showNoInfo>\r\n        <ion-row id=\"templateAlt\">\r\n            <ion-col align=\"center\">\r\n                <ion-text>\r\n                    No cuentas con información registrada actualmente.\r\n                </ion-text>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ng-template>\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_registers_registers_module_ts.js.map