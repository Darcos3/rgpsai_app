"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_login_login_module_ts"],{

/***/ 5642:
/*!*************************************************!*\
  !*** ./src/app/components/components.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ComponentsModule": () => (/* binding */ ComponentsModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _components_menu_menu_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../components/menu/menu.component */ 5819);





let ComponentsModule = class ComponentsModule {
};
ComponentsModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [
            _components_menu_menu_component__WEBPACK_IMPORTED_MODULE_0__.MenuComponent,
        ],
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        ],
        exports: [
            _components_menu_menu_component__WEBPACK_IMPORTED_MODULE_0__.MenuComponent,
        ],
    })
], ComponentsModule);



/***/ }),

/***/ 5819:
/*!***************************************************!*\
  !*** ./src/app/components/menu/menu.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuComponent": () => (/* binding */ MenuComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _menu_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./menu.component.html?ngResource */ 2574);
/* harmony import */ var _menu_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./menu.component.scss?ngResource */ 1346);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 3819);






let MenuComponent = class MenuComponent {
    constructor(alertController, router) {
        this.alertController = alertController;
        this.router = router;
    }
    ngOnInit() { }
    closeView() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Confirmación',
                message: '¿Desea salir de esta vista?<br> Si lo hace perdera los avances que tenga en el formulario',
                backdropDismiss: false,
                buttons: [
                    {
                        text: 'No',
                        role: 'cancel',
                        handler: () => { }
                    },
                    {
                        text: 'Si',
                        handler: () => {
                            this.router.navigate(['registers']);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
MenuComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router }
];
MenuComponent.propDecorators = {
    TitleBar: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["TitleBar",] }],
    isMenuVisible: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["isMenuVisible",] }],
    isBackVisible: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["isBackVisible",] }],
    isFilterVisible: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["isFilterVisible",] }],
    isBackItemVisible: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["isBackItemVisible",] }],
    isCloseVisible: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input, args: ["isCloseVisible",] }]
};
MenuComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-menu',
        template: _menu_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_menu_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], MenuComponent);



/***/ }),

/***/ 3403:
/*!*****************************************************!*\
  !*** ./src/app/pages/login/login-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageRoutingModule": () => (/* binding */ LoginPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page */ 3058);




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_0__.LoginPage
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ 1053:
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageModule": () => (/* binding */ LoginPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login-routing.module */ 3403);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page */ 3058);
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/components.module */ 5642);








let LoginPageModule = class LoginPageModule {
};
LoginPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _login_routing_module__WEBPACK_IMPORTED_MODULE_0__.LoginPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_1__.LoginPage]
    })
], LoginPageModule);



/***/ }),

/***/ 3058:
/*!*******************************************!*\
  !*** ./src/app/pages/login/login.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPage": () => (/* binding */ LoginPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page.html?ngResource */ 6752);
/* harmony import */ var _login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page.scss?ngResource */ 8433);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var src_app_config_events__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/config/events */ 6721);
/* harmony import */ var src_app_services_api_rest_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/api-rest.service */ 6363);
/* harmony import */ var _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/preferences */ 5191);










let LoginPage = class LoginPage {
    constructor(loadingController, alertController, formBuilder, api, router, zone, events) {
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.formBuilder = formBuilder;
        this.api = api;
        this.router = router;
        this.zone = zone;
        this.events = events;
        this.loginForm = formBuilder.group({
            emailField: [null, [
                    _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.email
                ]],
            passField: [null, [
                    _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.minLength(5),
                    _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.maxLength(15)
                ]]
        });
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            this.zone.run(() => {
                this.validateSession();
            });
        });
    }
    validateSession() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            let data = yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.get({ key: 'sessionPersistence' });
            let session = JSON.parse(data.value);
            if (session && session.sessionStatus == 200) {
                this.router.navigate(['registers']);
            }
        });
    }
    //login auth
    getLogin() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            let object = Object();
            object.grant_type = 'password';
            object.client_id = 2;
            object.client_secret = 'mS5WmSWppoKIwewDs6P9JjVuWk0pebybYCyfA7Nf';
            object.username = this.emailField;
            object.password = this.passField;
            object.scope = 'general'; //externalApi
            const loading = yield this.loadingController.create({
                message: 'Cargando...',
                spinner: 'crescent',
                showBackdrop: true,
            });
            yield loading.present();
            this.api.getLogin(object).subscribe(response => {
                loading.dismiss();
                ////console.log(response[0])
                if (response[0].access_token) {
                    let user = Object();
                    user.token = response[0].access_token;
                    user.email = this.emailField;
                    user.userID = 1;
                    this.userToken = response[0].access_token;
                    this.api.setDataProfile(user, "Bearer " + response[0].access_token).subscribe(data => {
                        user.userID = data[0].user.id;
                    }, err => {
                        //console.log('ErrorLogin', err);
                    });
                    this._storeKeysSession(user);
                    this.downloadDropdowns();
                    this.router.navigate(["registers"]);
                }
                else {
                    this.presentError(response[0].success_message);
                }
            }, err => {
                this.presentError('Los datos de acceso estan errados, por favor verifique y vuelva a intentar.');
                //console.log('Error servicio: ', JSON.stringify(err));
                loading.dismiss();
            });
        });
    }
    //store and create user session
    _storeKeysSession(data) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            let session = Object();
            session.sessionStatus = 200;
            session.userToken = data.token;
            session.userEmail = data.email;
            session.userID = data.userID;
            yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.set({
                key: 'sessionPersistence',
                value: JSON.stringify(session),
            });
            this.loginForm.reset();
        });
    }
    //alert with warning
    presentError(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Advertencia',
                message: message,
                backdropDismiss: false,
                buttons: ['OK']
            });
            yield alert.present();
        });
    }
    //download all dropdowns
    downloadDropdowns() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Cargando...',
                spinner: 'crescent',
                showBackdrop: true,
            });
            yield loading.present();
            this.api.listDropdownPortsOfLanding("Bearer " + this.userToken).subscribe(response => {
                //console.log('Landing', response[0]);
                this._storeKeysDropdowns('sessionSelectLanding', response[0]);
            }, err => {
                //console.log('Error servicio Landing: ', JSON.stringify(err));
            });
            this.api.listDropdownFishingArts("Bearer " + this.userToken).subscribe(response => {
                //console.log('Fishing', response[0]);
                this._storeKeysDropdowns('sessionSelectFishing', response[0]);
            }, err => {
                //console.log('Error servicio Fishing: ', JSON.stringify(err));
            });
            this.api.listDropdownFishingArtsBoat("Bearer " + this.userToken).subscribe(response => {
                //console.log('Fishing Boat', response[0]);
                this._storeKeysDropdowns('sessionSelectFishingBoats', response[0]);
            }, err => {
                //console.log('Error servicio Fishing Boat: ', JSON.stringify(err));
            });
            this.api.listDropdownRegistrationPorts("Bearer " + this.userToken).subscribe(response => {
                //console.log('Ports', response[0]);
                this._storeKeysDropdowns('sessionSelectPorts', response[0]);
            }, err => {
                //console.log('Error servicio Ports: ', JSON.stringify(err));
            });
            this.api.listDropdownTypesOfFishery("Bearer " + this.userToken).subscribe(response => {
                //console.log('Types of fishery', response[0]);
                this._storeKeysDropdowns('sessionSelectFisheries', response[0]);
            }, err => {
                //console.log('Error servicio Types of fishery: ', JSON.stringify(err));
            });
            this.api.listDropdownCompanies("Bearer " + this.userToken).subscribe(response => {
                //console.log('Customers', response[0].data);
                this._storeKeysDropdowns('sessionSelectCustomers', response[0]);
            }, err => {
                //console.log('Error servicio Customers: ', JSON.stringify(err));
            });
            this.api.listDropdownOrganizations("Bearer " + this.userToken).subscribe(response => {
                ////console.log('Organizations', response[0].data);
                this._storeKeysDropdowns('sessionSelectOrganizations', response[0]);
            }, err => {
                //console.log('Error servicio Organizations: ', JSON.stringify(err));
            });
            setTimeout(() => {
                loading.dismiss();
                this.presentMessage('Confirmación', 'Sincronización de valores completa');
            }, 500);
        });
    }
    //store and session dropdowns
    _storeKeysDropdowns(keyName, data) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            let session = Object();
            session.data = data;
            yield _capacitor_preferences__WEBPACK_IMPORTED_MODULE_4__.Preferences.set({
                key: keyName,
                value: JSON.stringify(session),
            });
        });
    }
    //alert with warning
    presentMessage(title, message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: title,
                message: message,
                backdropDismiss: false,
                buttons: ['OK']
            });
            yield alert.present();
        });
    }
};
LoginPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder },
    { type: src_app_services_api_rest_service__WEBPACK_IMPORTED_MODULE_3__.ApiRestService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.NgZone },
    { type: src_app_config_events__WEBPACK_IMPORTED_MODULE_2__.Events }
];
LoginPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-login',
        template: _login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], LoginPage);



/***/ }),

/***/ 1346:
/*!****************************************************************!*\
  !*** ./src/app/components/menu/menu.component.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "ion-header ion-toolbar {\n  --background: #2f6da8; /* Old browsers */\n  --background: -moz-linear-gradient(left, #2f6da8 0%, #3192c8 76%, #73ad7d 100%); /* FF3.6-15 */\n  --background: -webkit-linear-gradient(left, #2f6da8 0%,#3192c8 76%,#73ad7d 100%); /* Chrome10-25,Safari5.1-6 */\n  --background: linear-gradient(to right, #2f6da8 0%,#3192c8 76%,#73ad7d 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  padding-top: 30px;\n  padding-bottom: 10px;\n}\nion-header ion-toolbar ion-title {\n  font-family: \"Poppins\", sans-serif;\n  color: #ffffff;\n  text-align: center;\n}\nion-header ion-toolbar ion-menu-button {\n  --color: #FFFFFF;\n}\nion-header ion-toolbar ion-back-button {\n  --color: #FFFFFF;\n}\nion-header ion-toolbar img {\n  width: 25px;\n  margin-right: 10px;\n}\nion-header ion-toolbar ion-icon {\n  color: #ffffff;\n  font-size: 24px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lbnUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDSSxxQkFBQSxFQUFBLGlCQUFBO0VBQ0EsK0VBQUEsRUFBQSxhQUFBO0VBQ0EsZ0ZBQUEsRUFBQSw0QkFBQTtFQUNBLDRFQUFBLEVBQUEscURBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0FBQVI7QUFDUTtFQUNJLGtDQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBQ1o7QUFDUTtFQUNJLGdCQUFBO0FBQ1o7QUFDUTtFQUNJLGdCQUFBO0FBQ1o7QUFDUTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtBQUNaO0FBQ1E7RUFDSSxjQUFBO0VBQ0EsZUFBQTtBQUNaIiwiZmlsZSI6Im1lbnUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVye1xyXG4gICAgaW9uLXRvb2xiYXJ7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjMmY2ZGE4OyAvKiBPbGQgYnJvd3NlcnMgKi9cclxuICAgICAgICAtLWJhY2tncm91bmQ6IC1tb3otbGluZWFyLWdyYWRpZW50KGxlZnQsICMyZjZkYTggMCUsICMzMTkyYzggNzYlLCAjNzNhZDdkIDEwMCUpOyAvKiBGRjMuNi0xNSAqL1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQobGVmdCwgIzJmNmRhOCAwJSwjMzE5MmM4IDc2JSwjNzNhZDdkIDEwMCUpOyAvKiBDaHJvbWUxMC0yNSxTYWZhcmk1LjEtNiAqL1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjMmY2ZGE4IDAlLCMzMTkyYzggNzYlLCM3M2FkN2QgMTAwJSk7IC8qIFczQywgSUUxMCssIEZGMTYrLCBDaHJvbWUyNissIE9wZXJhMTIrLCBTYWZhcmk3KyAqL1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAzMHB4O1xyXG4gICAgICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gICAgICAgIGlvbi10aXRsZXtcclxuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgICAgICAgICAgY29sb3I6ICNmZmZmZmY7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaW9uLW1lbnUtYnV0dG9ue1xyXG4gICAgICAgICAgICAtLWNvbG9yOiAjRkZGRkZGO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpb24tYmFjay1idXR0b257XHJcbiAgICAgICAgICAgIC0tY29sb3I6ICNGRkZGRkY7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGltZ3tcclxuICAgICAgICAgICAgd2lkdGg6IDI1cHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaW9uLWljb257XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il19 */";

/***/ }),

/***/ 8433:
/*!********************************************************!*\
  !*** ./src/app/pages/login/login.page.scss?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "ion-content ion-grid ion-row ion-col img.imgTop {\n  margin: 50px 0;\n  width: 300px;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid ion-row ion-col img.imgTop {\n    max-width: 70%;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid ion-row ion-col img.imgTop {\n    max-width: 80%;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid ion-row ion-col img.imgTop {\n    max-width: 100%;\n  }\n}\nion-content ion-grid ion-row ion-col ion-card {\n  margin: 0 auto;\n  padding: 0 0 30px;\n}\n@media (min-width: 319px) {\n  ion-content ion-grid ion-row ion-col ion-card {\n    max-width: 90%;\n  }\n}\n@media (min-width: 374px) {\n  ion-content ion-grid ion-row ion-col ion-card {\n    max-width: 90%;\n  }\n}\n@media (min-width: 415px) {\n  ion-content ion-grid ion-row ion-col ion-card {\n    max-width: 60%;\n  }\n}\nion-content ion-grid ion-row ion-col ion-card ion-item {\n  font-family: \"Poppins\", sans-serif;\n  margin: 20px 0;\n  border-bottom: 2px solid #E6E6E6;\n}\nion-content ion-grid ion-row ion-col ion-card ion-item ion-icon {\n  color: #bdbdbd;\n}\nion-content ion-grid ion-row ion-col ion-card ion-item ion-input {\n  color: #414141;\n  font-family: \"Poppins\", sans-serif;\n}\nion-content ion-grid ion-row ion-col ion-card ion-button {\n  font-family: \"Poppins\", sans-serif;\n  --border-radius: 50px;\n  --background: #2f6da8; /* Old browsers */\n  --background: -moz-linear-gradient(left, #2f6da8 0%, #3192c8 76%, #73ad7d 100%); /* FF3.6-15 */\n  --background: -webkit-linear-gradient(left, #2f6da8 0%,#3192c8 76%,#73ad7d 100%); /* Chrome10-25,Safari5.1-6 */\n  --background: linear-gradient(to right, #2f6da8 0%,#3192c8 76%,#73ad7d 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  --background-activated: #006fa6;\n  --background-focused: #006fa6;\n  --background-hover: #006fa6;\n  min-width: 100%;\n}\nion-content footer {\n  --background: none;\n  background-image: url('backion.png');\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-position: bottom;\n  min-height: 250px;\n  max-height: 250px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFLb0I7RUFDSSxjQUFBO0VBQ0EsWUFBQTtBQUp4QjtBQUt3QjtFQUhKO0lBSVEsY0FBQTtFQUYxQjtBQUNGO0FBR3dCO0VBTko7SUFPUSxjQUFBO0VBQTFCO0FBQ0Y7QUFDd0I7RUFUSjtJQVVRLGVBQUE7RUFFMUI7QUFDRjtBQUNnQjtFQUNJLGNBQUE7RUFDQSxpQkFBQTtBQUNwQjtBQUFvQjtFQUhKO0lBSVEsY0FBQTtFQUd0QjtBQUNGO0FBRm9CO0VBTko7SUFPUSxjQUFBO0VBS3RCO0FBQ0Y7QUFKb0I7RUFUSjtJQVVRLGNBQUE7RUFPdEI7QUFDRjtBQU5vQjtFQUNJLGtDQUFBO0VBQ0EsY0FBQTtFQUNBLGdDQUFBO0FBUXhCO0FBUHdCO0VBQ0ksY0FBQTtBQVM1QjtBQVB3QjtFQUNJLGNBQUE7RUFDQSxrQ0FBQTtBQVM1QjtBQU5vQjtFQUNJLGtDQUFBO0VBQ0EscUJBQUE7RUFDQSxxQkFBQSxFQUFBLGlCQUFBO0VBQ0EsK0VBQUEsRUFBQSxhQUFBO0VBQ0EsZ0ZBQUEsRUFBQSw0QkFBQTtFQUNBLDRFQUFBLEVBQUEscURBQUE7RUFDQSwrQkFBQTtFQUNBLDZCQUFBO0VBQ0EsMkJBQUE7RUFDQSxlQUFBO0FBUXhCO0FBRkk7RUFDSSxrQkFBQTtFQUNBLG9DQUFBO0VBQ0EsNEJBQUE7RUFDQSxzQkFBQTtFQUNBLDJCQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQUlSIiwiZmlsZSI6ImxvZ2luLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xyXG4gICAgaW9uLWdyaWR7XHJcbiAgICAgICAgaW9uLXJvd3tcclxuICAgICAgICAgICAgaW9uLWNvbHtcclxuICAgICAgICAgICAgICAgIGltZ3tcclxuICAgICAgICAgICAgICAgICAgICAmLmltZ1RvcHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiA1MHB4IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiAzMDBweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDMxOXB4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXgtd2lkdGg6IDcwJTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogMzc0cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heC13aWR0aDogODAlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiA0MTVweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4LXdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaW9uLWNhcmR7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwIGF1dG87XHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogMCAwIDMwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDMxOXB4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1heC13aWR0aDogOTAlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogMzc0cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWF4LXdpZHRoOiA5MCU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiA0MTVweCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXgtd2lkdGg6IDYwJTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaW9uLWl0ZW17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogMjBweCAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tOiAycHggc29saWQgI0U2RTZFNjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaW9uLWljb257XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogI2JkYmRiZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlvbi1pbnB1dHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjNDE0MTQxO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpb24tYnV0dG9ue1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDUwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZDogIzJmNmRhODsgLyogT2xkIGJyb3dzZXJzICovXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZDogLW1vei1saW5lYXItZ3JhZGllbnQobGVmdCwgIzJmNmRhOCAwJSwgIzMxOTJjOCA3NiUsICM3M2FkN2QgMTAwJSk7IC8qIEZGMy42LTE1ICovXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZDogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQobGVmdCwgIzJmNmRhOCAwJSwjMzE5MmM4IDc2JSwjNzNhZDdkIDEwMCUpOyAvKiBDaHJvbWUxMC0yNSxTYWZhcmk1LjEtNiAqL1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzJmNmRhOCAwJSwjMzE5MmM4IDc2JSwjNzNhZDdkIDEwMCUpOyAvKiBXM0MsIElFMTArLCBGRjE2KywgQ2hyb21lMjYrLCBPcGVyYTEyKywgU2FmYXJpNysgKi9cclxuICAgICAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogICMwMDZmYTY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZC1mb2N1c2VkOiAjMDA2ZmE2O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQtaG92ZXI6ICMwMDZmYTY7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1pbi13aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBmb290ZXJ7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiBub25lO1xyXG4gICAgICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCguLi8uLi8uLi9hc3NldHMvaW1hZ2VzL2JhY2tpb24ucG5nKTtcclxuICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogYm90dG9tO1xyXG4gICAgICAgIG1pbi1oZWlnaHQ6IDI1MHB4O1xyXG4gICAgICAgIG1heC1oZWlnaHQ6IDI1MHB4O1xyXG4gICAgfVxyXG59Il19 */";

/***/ }),

/***/ 2574:
/*!****************************************************************!*\
  !*** ./src/app/components/menu/menu.component.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\r\n    <ion-toolbar>\r\n        <img src=\"../../../assets/resources/ico-filter.png\" slot=\"end\" *ngIf=\"isFilterVisible=='true'\"> \r\n        <ion-buttons slot=\"start\" *ngIf=\"isBackVisible=='true'\">\r\n            <ion-back-button text=\"\" defaultHref=\"registers\"></ion-back-button>\r\n        </ion-buttons>\r\n        <ion-buttons slot=\"start\" *ngIf=\"isCloseVisible=='true'\">\r\n            <ion-icon name=\"close\" (click)=\"closeView()\"></ion-icon>\r\n        </ion-buttons>\r\n        <ion-buttons slot=\"start\" *ngIf=\"isBackItemVisible=='true'\">\r\n            <ion-back-button text=\"\" defaultHref=\"/\"></ion-back-button>\r\n        </ion-buttons>\r\n        <ion-buttons slot=\"end\" *ngIf=\"isMenuVisible=='true'\">\r\n            <ion-menu-button></ion-menu-button>\r\n        </ion-buttons>\r\n        <ion-title>\r\n            {{ TitleBar }}\r\n        </ion-title>\r\n    </ion-toolbar>\r\n</ion-header>";

/***/ }),

/***/ 6752:
/*!********************************************************!*\
  !*** ./src/app/pages/login/login.page.html?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "<app-menu TitleBar=\"Iniciar Sesión\" isMenuVisible=\"false\" isBackVisible=\"false\"></app-menu>\r\n\r\n<ion-content>\r\n    <ion-grid>\r\n        <ion-row align=\"center\">\r\n            <ion-col>\r\n                <img src=\"../../../assets/images/logo.png\" class=\"imgTop\">\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"justify-content-center align-items-center\">\r\n            <ion-col>\r\n                <ion-card>                  \r\n                    <ion-card-content>\r\n                        <form [formGroup]=\"loginForm\">\r\n                            <ion-list>\r\n                                <ion-item lines=\"none\">\r\n                                    <ion-input type=\"emal\" autofocus=\"on\" clearInput=\"true\" placeholder=\"Correo electónico\" required=\"true\" [(ngModel)]=\"emailField\" formControlName=\"emailField\"></ion-input>\r\n                                    <ion-icon name=\"mail-outline\" slot=\"start\"></ion-icon>\r\n                                </ion-item>\r\n                                <ion-item lines=\"none\">\r\n                                    <ion-input type=\"password\" clearInput=\"true\" placeholder=\"Contraseña\" required=\"true\" [(ngModel)]=\"passField\" formControlName=\"passField\"></ion-input>\r\n                                    <ion-icon name=\"lock-open-outline\" slot=\"start\"></ion-icon>\r\n                                </ion-item>\r\n                            </ion-list>\r\n                        </form>\r\n                        <ion-row align=\"center\">\r\n                            <ion-col>\r\n                                <ion-button (click)=\"getLogin()\" [disabled]=\"loginForm.invalid\">\r\n                                    Ingresar\r\n                                </ion-button>\r\n                            </ion-col>\r\n                        </ion-row>\r\n                    </ion-card-content>\r\n                </ion-card>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n    <footer></footer>\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_login_login_module_ts.js.map